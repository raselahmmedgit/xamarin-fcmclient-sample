﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FreeChat.Helpers
{
    public class Constants
    {
        public const string ScrollToItem = "ScrollToItem";
        public const string ShowKeyboard = "ShowKeyboard";
        public const string iOSKeyboardAppears = "KeyboardAppears";
        public const string iOSKeyboardDisappears = "KeyboardDisappears";
    }
}
