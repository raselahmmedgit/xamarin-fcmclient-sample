﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FreeChat.Helpers.MyEventArgs
{
    public class MyFocusEventArgs : EventArgs
    {
        public bool IsFocused { get; set; }
    }
}
