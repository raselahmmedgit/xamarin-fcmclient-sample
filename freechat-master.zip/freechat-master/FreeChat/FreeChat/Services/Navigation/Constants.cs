﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FreeChat.Services.Navigation
{
    public class Constants
    {
        public const string MessagesPageUrl = "MessagesPage";
    }
}
