﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace FreeChat.Views.Effects
{
    public class BorderlessEntryEffect : BaseFreechatEffect
    {
        public BorderlessEntryEffect() : 
            base(nameof(BorderlessEntryEffect))
        {
        }
    }
}
