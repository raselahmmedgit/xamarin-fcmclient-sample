﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FreeChat.Views.Effects
{
    public class iOSSafeAreaInsetEffect : BaseFreechatEffect
    {
        public iOSSafeAreaInsetEffect() : base(nameof(iOSSafeAreaInsetEffect))
        {
        }
    }
}
