﻿using System;
using Xamarin.Forms;

namespace FreeChat.Views.Effects
{
    public class BorderlessEditorEffect : BaseFreechatEffect
    {
        public BorderlessEditorEffect() :
            base(nameof(BorderlessEditorEffect))
        {
        }
    }
}
