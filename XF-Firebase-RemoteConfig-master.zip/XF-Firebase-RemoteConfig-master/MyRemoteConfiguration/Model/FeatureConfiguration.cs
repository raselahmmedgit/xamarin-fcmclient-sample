﻿namespace MyRemoteConfiguration.Model
{
    public class FeatureConfiguration
    {
        public bool ShowPlayerDetail { get; set; }
    }
}
