﻿namespace MyRemoteConfiguration.Model
{
    public class RemoteConfiguration
    {
        public string BackgroundColor { get; set; }
        public string Title { get; set; }
    }
}
