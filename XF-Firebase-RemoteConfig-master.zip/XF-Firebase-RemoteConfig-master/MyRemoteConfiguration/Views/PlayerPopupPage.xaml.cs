﻿using Rg.Plugins.Popup.Pages;

namespace MyRemoteConfiguration.Views
{
    public partial class PlayerPopupPage : PopupPage
    {
        public PlayerPopupPage()
        {
            InitializeComponent();
        }
    }
}
