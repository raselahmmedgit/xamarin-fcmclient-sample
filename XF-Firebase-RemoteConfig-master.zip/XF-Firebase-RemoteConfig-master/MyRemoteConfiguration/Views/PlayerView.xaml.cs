﻿using Xamarin.Forms;

namespace MyRemoteConfiguration.Views
{
    public partial class PlayerView : ContentView
    {
        public PlayerView()
        {
            InitializeComponent();
        }
    }
}
