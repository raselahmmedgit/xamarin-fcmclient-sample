# HealthBuddy Backend Services

## Table of Contents

* [Components](#components)
* [External components](#external)
* [Deployment](#deployment)

## Components

HealthBuddy backend is built from a number of interconnected components.

![Components](img/hb-components.png)

### Front Door with WAF
Azure Front Door is an entry point to the whole Azure backend, it manages and routes mobile, HealthBuddy website and RapidPro requests to Azure API Management.
Default routing rule has enabled caching for every unique URL.
Front Door provides centralized protection to Azure backend, applies a Web Application Firewall (WAF) rules.

### API Management

Azure API Management (APIM) is the public interface to the backend services.

It has the following responsibilities:
* Filtering the incoming requests on header 'X-Azure-FDID', this field is populated by Front Door service;
* Providing a public interface to the private services;
* Applying changes to inbound requests via APIM policies;
* Applying changes to outbound responses via APIM policies: combining and translating responses and status codes.

APIs are added to the API Management instance via importing OpenAPI specifications.
They can be found in [open-api](deployment/open-api) folder:

"Mobile endpoints" are used by HealthBuddy mobile app.
"CMS endpoints" are used by HealthBuddy website.
"Integration endpoints" are used by RapidPro.

APIM policies are a collection of statements that are executed sequentially on the request or response of an API.
The policy definition is a simple XML document with policy expressions syntax in C# 7.
Each expression has access to the implicitly provided context variable and an allowed subset of .NET Framework types.

APIM policies can be found in [apim-policies](deployment/apim-policies) folder.

### Identity Server

App Service is responsible for user authentication and authorization. Manages user names, passwords and roles.
Implemented with IdentityServer4; it is backed by an Azure Database for PostgreSQL server.

[User.IdentityServer](src/Services/User/User.IdentityServer)

### User Service

App Service is responsible for user management from business domain point of view:
* Returning user profile

It is backed by a CosmosDB table with Cassandra API and has the only table 'user' there.

[User](src/Services/User)

### Notification Service

App Service is responsible for managing push notification tokens:
* Setting up notification tokens (token value, target platform, language) for registered/logged in users
* Clearing notification tokens (for example, if user logged out)
* Broadcasting push notifications to users

[Notification](src/Services/Notification)

### Notifications Service Bus

Azure Service Bus transfers messages per user who is going to receive push notification on his mobile phone.

### Notifications Function

Azure Function App is triggered by message in Notifications Service Bus and sends notification invoking Notification Hub client.

[Notification.FnApp](src/Services/Notification/Notification.FnApp)

### Notification Hub

Azure Notification Hub is a mobile push notification engine and used for sending notifications to iOS and Android devices.

### HealthBuddy website

App Service hosted on a separate App Service plan. Calls CMS through Front Door/API Management.

### App for RapidPro Integration

SPA hosted in Azure Blob Storage.

## External

### RapidPro

RapidPro is a software product that allows you to visually build the workflow logic for running mobile-based services.
In HealthBuddy RapidPro is used to provide chatbot and polls functionality, as far as reporting fake news and rumors.
In addition, an administrator of RapidPro can initiate sending push notifications to HealthBuddy app users via calling webhook action.

### CMS (Drupal)

Drupal is a content management system (CMS) which is hosted on Acquia cloud platform.
Drupal content is used by HealthBuddy website on the landing page, and by mobile application to show newsfeed articles and images, Privacy Policy and About Us. 

### Configurations and Secrets

Configurations are stored in the App Configuration service, which is used by multiple services.
Secrets (like connection strings and database passwords) are stored in a Key Vault, and they
are linked to the App Configuration.

## Deployment


### Configuration files

Before deploying environment two config files should be created.

####  [Performance settings file](deployment/infrastructure/settings/env.psd1.template)

The performance settings file contains pricing plans and other performance settings for Azure resources.

This file is stored in the Azure Devops repository under this path 

./deployment/infrastructure/settings/{filename}.psd1

where {filename} has to match the backend environment name (up to 4 symbols)

#### [Secured settings file](deployment/infrastructure/settings/env_secure.psd1.template)

The secured settings file contains sensitive information (secrets, passwords, subscription keys, etc).

This file must be placed in a safe place.


### Customization

Before deploying the application we recommend to supply your own
shared secret instead of the placeholder found in the code.

Please follow the next steps:
* Generate a secure password-like secret
* Replace the "secret" placeholder when assigning it to the `$secret` variable in the [DeployEnvironment.ps1](deployment/Infrastructure/DeployEnvironment.ps1)
* Replace the "secret" placeholders in [Config.cs](src/Services/User/User.IdentityServer/Config.cs)



### Prerequisites

* Install [Azure CLI](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli?view=azure-cli-latest)
* Install [Azure Powershell](https://docs.microsoft.com/en-us/powershell/azure/install-az-ps)

### Authentication

```bash
# Go to the infrastructure subfolder
cd deployment/Infrastructure

# Login to Azure CLI
az login

# Select your subscription
az account list # observe the id of the proper subscription
az account set --subscription ${id}

# Login to Azure Powershell
Connect-AzAccount

# Select your subscription
Select-AzSubscription -SubscriptionId ${id}
```

### Deploy Infrastructure

When deploying a new infrastructure, the following parameters should be specified:
* product: The name of the product, it will appear in all resource names (up to 8 symbols).
* environment: The name of the environment (up to 4 symbols).
* configSecuredPath: Secured settings file name location
* configPricingPlansPath: Optional, default to {environment}.psd1 [Performance settings file name](deployment/Infrastructure/settings).


```bash
# Deploy service components
./DeployEnvironment.ps1 -product epmcovi -environment mvp2 -configSecuredPath %userprofile%/.hbcovid/mvp2_secure.psd1

# Update API Management policies
./Import-APIMgmtPolicies -product epmcovi -environment mvp2 -configSecuredPath %userprofile%/.hbcovid/mvp2_secure.psd1
```

### Build and Deploy Artifacts (CI/CD)

This step is about setting up the CI/CD pipelines that deploy the code changes to the previously created environments.

Configuring a CI/CD pipeline depends on the specifics of the infrastructure and branching strategies.
Az example pipeline for [Azure DevOps](https://azure.microsoft.com/en-us/services/devops/) is available in the
[deployment/azure-devops](deployment/azure-devops) folder. 
