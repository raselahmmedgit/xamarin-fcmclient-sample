# https://docs.microsoft.com/en-us/cli/azure/reference-index?view=azure-cli-latest

# Only two manadatory parameters:
# -product	any string up to 8 symbols
# -environment 	any string up to 4 symbols

param (
    [Parameter(Mandatory=$true)] [ValidateLength(1, 8)] [string]$product, # examples: epmcovi, homecovi
    [Parameter(Mandatory=$true)] [ValidateLength(1, 4)] [string]$environment, # examples: tst1, tst2, dev1, mvp1
    [string]$resourceGroup, 
    [string]$settingsFolder, 
    [string]$configPricingPlansPath,
    [string]$configSecuredPath,
    [bool]$isAzurePipeline = $false
)

if ([string]::IsNullOrEmpty($settingsFolder)) {
     $settingsFolder = "."
}
else {
    $settingsFolder = $settingsFolder.ToString() + "/deployment/Infrastructure"
}

function Get-Settings([string]$settingsFile, [string]$type) {
    if ([string]::IsNullOrEmpty($settingsFile)) {
        switch ($type)  {
            'pricingPlans' {
                $settingsFile = $settingsFolder + "/settings/" + $environment + ".psd1"
                break;
            }
            'securedConfig' {
                $settingsFile = "~/.hbcovid/" + $environment + "_secure.psd1"
                break;
            }
        }
    }
    else {
        if  (-Not (Test-Path -PathType Leaf $settingsFile)) {
            $settingsFile = $settingsFile + "/" + $environment + ".psd1"
        }
    }

    if (-Not (Test-Path -PathType Leaf $settingsFile)) {
        throw "File '$settingsFile' does not exists" 
    }
    else {
        return Import-PowerShellDataFile $settingsFile
    }
}


$settings = Get-Settings -settingsFile $configPricingPlansPath -type "pricingPlans"
$settingsSecured = Get-Settings -settingsFile $configSecuredPath -type "securedConfig"

if ([string]::IsNullOrEmpty($resourceGroup)) {
    $resourceGroupName = "rg-$($settings.region.key)-$environment-$product-01"
}
else {
    $resourceGroupName = $resourceGroup
}


$APIManagementServiceName = "api-$($settings.region.key)-$environment-$product-01"

$apimContext = New-AzApiManagementContext -ResourceGroupName $resourceGroupName -ServiceName $APIManagementServiceName

New-AzApiManagementNamedValue -Context $apimContext `
    -NamedValueId "cmsUserPassword" -Name "cmsUserPassword" -Value $settingsSecured.apimgmt.cmsUserPassword -Secret
New-AzApiManagementNamedValue -Context $apimContext `
    -NamedValueId "rapidProUserPassword" -Name "rapidProUserPassword" -Value $settingsSecured.apimgmt.rapidProUserPassword -Secret


