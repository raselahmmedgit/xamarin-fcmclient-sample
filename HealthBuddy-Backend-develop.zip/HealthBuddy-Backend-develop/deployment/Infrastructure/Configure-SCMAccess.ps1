
param (
    [Parameter(Mandatory = $true)] [ValidateSet('DisableAccess', 'EnableAccess')]$operation,
    [Parameter(Mandatory = $true)] [string]$resourceGroup, 
    [Parameter(Mandatory = $true)] $webAppList,
    [Parameter(Mandatory = $true)] $funcAppList
)


function Set-SCMAccess {
    param (
        [Parameter(Mandatory = $true)] [string]$resourceGroup, 
        [Parameter(Mandatory = $true)] [string]$appName,
        [Parameter(Mandatory = $true)] [ValidateSet('webapp', 'functionapp')] $appType,
        [Parameter(Mandatory = $true)] [ValidateSet('DisableAccess', 'EnableAccess')]$operation
    )

    $rulePriority = 1000
    $ruleName = "DenyAll"
    $ruleAction = "Deny"
    $ruleIPAddress = "0.0.0.0/0"
    $ruleEnabled = $false

    $rules = $($(az webapp config access-restriction show --name $appName --resource-group $resourceGroup `
             | ConvertFrom-JSON)).scmIpSecurityRestrictions
    $Host.UI.RawUI.ForegroundColor = 'White'

    foreach ($rule in $rules) {
        if (($rule.name -eq $ruleName) -and ($rule.action -eq $ruleAction)) {
            if ($operation -eq "EnableAccess") {
              Write-Host "Remove 'DenyAll' rule"
              $rule

              $hideOutput = az $appType config access-restriction remove --name $appName --resource-group $resourceGroup `
                  --rule-name $rule.name `
                  --action $rule.action  `
                  --ip-address $rule.ip_address `
                  --scm-site true
              $Host.UI.RawUI.ForegroundColor = 'White'
            }
            else {
              $ruleEnabled = $true
              Write-Host "The rule 'DenyAll' has already exist"
            }
        }
    }

    if (($operation -eq "DisableAccess") -and ($ruleEnabled -eq $false)) {
        Write-Host "Create 'DenyAll' rule"

        az $appType config access-restriction add --name $appName --resource-group $resourceGroup `
            --rule-name $ruleName `
            --action $ruleAction  `
            --ip-address $ruleIPAddress `
            --priority $rulePriority `
            --scm-site true

        $Host.UI.RawUI.ForegroundColor = 'White'
    }
}


foreach ($webApp in $webAppList) {
    Write-Host Setting $operation for $webApp
    Set-SCMAccess -resourceGroup $resourceGroup -appName $webApp -appType webapp -operation $operation
}

foreach ($funcApp in $funcAppList) {
    Write-Host Setting $operation for $funcApp
    Set-SCMAccess -resourceGroup $resourceGroup -appName $funcApp -appType functionapp -operation $operation
}

