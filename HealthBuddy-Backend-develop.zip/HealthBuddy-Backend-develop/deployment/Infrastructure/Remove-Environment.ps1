# https://docs.microsoft.com/en-us/cli/azure/reference-index?view=azure-cli-latest

# Only two manadatory parameters:
# -product	any string up to 8 symbols
# -environment 	any string up to 4 symbols

param (
    [Parameter(Mandatory=$true)] [ValidateLength(1, 8)] [string]$product, 	# examples: epmcovi, hbcovid
    [Parameter(Mandatory=$true)] [ValidateLength(1, 4)] [string]$environment, 	# examples: dev1, qa1
    [string]$resourceGroup, 
    [string]$settingsFolder, 
    [string]$configPricingPlansPath,
    [string]$configSecuredPath,
    [bool]$removeAll = $false,
    [bool]$removePostgreSQL = $false,
    [bool]$removeCosmosDB = $false
)


if ([string]::IsNullOrEmpty($settingsFolder)) {
     $settingsFolder = "."
}
else {
    $settingsFolder = $settingsFolder.ToString() + "/deployment/Infrastructure"
}


function RemoveEnvironment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        $nc_Environment,
        [Parameter(Mandatory = $true)]
        $nc_Product,
        [Parameter(Mandatory = $false)]
        $nc_GenerateRandomNames = $false
    )

    $settings = Get-Settings -settingsFile $configPricingPlansPath -type "pricingPlans"
    $settingsSecured = Get-Settings -settingsFile $configSecuredPath -type "securedConfig"

# Generating names according to 'Naming convention. Azure Resources.docx)
    $nc_Instance = "01" 
    $nc_Region = $settings.region.key


    if ([string]::IsNullOrEmpty($resourceGroup)) {
        $resourceGroupName = "rg-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    }
    else {
       $resourceGroupName = $resourceGroup
   }

    $resourcesList = $null
    if ($nc_GenerateRandomNames -and $(az group exists --name $resourceGroupName) -eq "true") {
        $resourcesList = az resource list --resource-group $resourceGroupName --query []."name" | ConvertFrom-Json
    }

    $storageAccountChatbot = ("sa" + $nc_Region + $nc_Environment + $nc_Product + $nc_Instance + "mob").ToLower()
    if ($nc_GenerateRandomNames) {$storageAccountChatbot  = Get-ResourceName -resourceName $storageAccountChatbot -resourceList $resourcesList }

    $storageAccountWebJobsName = ("sa" + $nc_Region + $nc_Environment + $nc_Product + $nc_Instance + "app").ToLower()
    if ($nc_GenerateRandomNames) {$storageAccountWebJobsName = Get-ResourceName -resourceName $storageAccountWebJobsName -resourceList $resourcesList }

    $keyVaultName = "kv-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    if ($nc_GenerateRandomNames) {$keyVaultName = Get-ResourceName -resourceName $keyVaultName -resourceList $resourcesList }
    $keyVaultCertificateName = "cert-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"

    $appInsightsName = "ai-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    if ($nc_GenerateRandomNames) {$appInsightsName = Get-ResourceName -resourceName $appInsightsName -resourceList $resourcesList }

    $serviceBusNamespaceName = "sbus-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    if ($nc_GenerateRandomNames) {$serviceBusNamespaceName = Get-ResourceName -resourceName $serviceBusNamespaceName -resourceList $resourcesList }
    $serviceBusTopicName = "notifications"

    $appServicePlanName = "asp-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    if ($nc_GenerateRandomNames) {$appServicePlanName = Get-ResourceName -resourceName $appServicePlanName -resourceList $resourcesList }
    $webAppIsName = "wa-$nc_Region-$nc_Environment-$nc_Product-is-$nc_Instance"
    if ($nc_GenerateRandomNames) {$webAppIsName = Get-ResourceName -resourceName $webAppIsName -resourceList $resourcesList }
    $webAppUserName = "wa-$nc_Region-$nc_Environment-$nc_Product-user-$nc_Instance"
    if ($nc_GenerateRandomNames) {$webAppUserName = Get-ResourceName -resourceName $webAppUserName -resourceList $resourcesList }
    $webAppNotificationName = "wa-$nc_Region-$nc_Environment-$nc_Product-notification-$nc_Instance"
    if ($nc_GenerateRandomNames) {$webAppNotificationName = Get-ResourceName -resourceName $webAppInfectionName -resourceList $resourcesList }

    $cosmosDBaccountName = ("cassandra-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance").ToLower()
    if ($nc_GenerateRandomNames) {$cosmosDBaccountName = Get-ResourceName -resourceName $cosmosDBaccountName -resourceList $resourcesList }

    $appConfigName = "config-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    if ($nc_GenerateRandomNames) {$appConfigName = Get-ResourceName -resourceName $appConfigName -resourceList $resourcesList }

    $postgreSQLServerName = "sql-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    if ($nc_GenerateRandomNames) {$postgreSQLServerName = Get-ResourceName -resourceName $postgreSQLServerName -resourceList $resourcesList }

    $notificationHubsNamespaceName = "nhub-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
#    $notificationHubName = $settingsSecured.notificationHub.name

    $APIManagementServiceName = "api-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"

    $functionAppNotificationName = "func-$nc_Region-$nc_Environment-$nc_Product-notification-$nc_Instance"
    if ($nc_GenerateRandomNames) {$functionAppNotificationName = Get-ResourceName -resourceName $functionAppNotificationName -resourceList $resourcesList }

    $frontDoorName = "fd-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    $frontDoorWAFPolicyName = ("waf" + $nc_Region + $nc_Environment + $nc_Product + $nc_Instance).ToLower()


    Write-Host "#################################################################"
    Write-Host "#    All resources: "
    Write-Host "#################################################################"
    az resource list --resource-group $resourceGroupName --query []."name"


    if ($removeAll) {
        Write-Host "#################################################################"
        Write-Host "#    Removing Function App - Notification"
        Write-Host "#################################################################"

        az functionapp show --name $functionAppNotificationName --resource-group $resourceGroupName
        az functionapp delete --name $functionAppNotificationName --resource-group $resourceGroupName

        Write-Host "#################################################################"
        Write-Host "#    Removing Notification Hub"
        Write-Host "#################################################################"

        az notification-hub namespace show --name $notificationHubsNamespaceName --resource-group $resourceGroupName
        az notification-hub namespace delete --name $notificationHubsNamespaceName --resource-group $resourceGroupName --yes

        Write-Host "#################################################################"
        Write-Host "#    Removing FrontDoor"
        Write-Host "#################################################################"
        az network front-door show --name $frontDoorName --resource-group $resourceGroupName 
        az network front-door delete --name $frontDoorName --resource-group $resourceGroupName 

        Write-Host "#################################################################"
        Write-Host "#    Removing WAF policy"
        Write-Host "#################################################################"
        az network front-door waf-policy show --name $frontDoorWAFPolicyName --resource-group $resourceGroupName 
        az network front-door waf-policy delete --name $frontDoorWAFPolicyName --resource-group $resourceGroupName 

        Write-Host "#################################################################"
        Write-Host "#    Removing API Management Service"
        Write-Host "#################################################################"
        az apim show --name $APIManagementServiceName --resource-group $resourceGroupName
        az apim delete --name $APIManagementServiceName --resource-group $resourceGroupName --yes

        Write-Host "#################################################################" 
        Write-Host "#    Removing Net Core Application - Notification"
        Write-Host "#################################################################"
        az webapp show --name $webAppNotificationName --resource-group $resourceGroupName
        az webapp delete --name $webAppNotificationName --resource-group $resourceGroupName

        Write-Host "#################################################################"
        Write-Host "#    Removing Net Core Application - User"
        Write-Host "#################################################################"
        az webapp show --name $webAppUserName --resource-group $resourceGroupName
        az webapp delete --name $webAppUserName --resource-group $resourceGroupName

        Write-Host "#################################################################"
        Write-Host "#    Removing Net Core Application - Is"
        Write-Host "#################################################################"
        az webapp show --name $webAppIsName --resource-group $resourceGroupName
        az webapp delete --name $webAppIsName --resource-group $resourceGroupName

        Write-Host "#################################################################"
        Write-Host "#    Removing App Service Plan"
        Write-Host "#################################################################"
        az appservice plan show --name $appServicePlanName --resource-group $resourceGroupName
        az appservice plan delete --name $appServicePlanName --resource-group $resourceGroupName --yes
    }

    if ($removeAll -or $removePostgreSQL) {
        Write-Host "#################################################################"
        Write-Host "#    Removing PostgreSQL server"
        Write-Host "#################################################################"
        az postgres server show --name $postgreSQLServerName --resource-group $resourceGroupName
        az postgres server delete --name $postgreSQLServerName --resource-group $resourceGroupName --yes
    }

    if ($removeAll -or $removeCosmosDB) {
        Write-Host "#################################################################"
        Write-Host "#    Removing CosmosDB account"
        Write-Host "#################################################################"
        az cosmosdb show --name $cosmosDBaccountName --resource-group $resourceGroupName
        az cosmosdb delete --name $cosmosDBaccountName --resource-group $resourceGroupName --yes
    }

    if ($removeAll) {
         Write-Host "#################################################################"
         Write-Host "#    Removing Application Insight"
         Write-Host "#################################################################"
         az monitor app-insights component show --app $appInsightsName --resource-group $resourceGroupName 
         az monitor app-insights component delete --app $appInsightsName --resource-group $resourceGroupName 

         Write-Host "#################################################################"
         Write-Host "#    Removing Service Bus Namespace and Topics"
         Write-Host "#################################################################"
         az servicebus namespace show --name $serviceBusNamespaceName --resource-group $resourceGroupName
         az servicebus namespace delete --name $serviceBusNamespaceName --resource-group $resourceGroupName

         Write-Host "#################################################################"
         Write-Host "#    Removing App Configuration"
         Write-Host "#################################################################"
         az appconfig show --name $appConfigName --resource-group $resourceGroupName
         az appconfig delete --name $appConfigName --resource-group $resourceGroupName --yes

#        Write-Host "#################################################################"
#        Write-Host "#    Removing Key Vault"
#        Write-Host "#################################################################"
#        az keyvault show --name $keyVaultName --resource-group $resourceGroupName
#        az keyvault delete --name $keyVaultName --resource-group $resourceGroupName
#        az keyvault purge --name $keyVaultName --location westeurope

        Write-Host "#################################################################"
        Write-Host "#    Removing Storage Account 2 for Function App"
        Write-Host "#################################################################"
        az storage account show --name $storageAccountWebJobsName --resource-group $resourceGroupName
        az storage account delete --name $storageAccountWebJobsName --resource-group $resourceGroupName --yes

        Write-Host "#################################################################"
        Write-Host "#    Removing Storage Account for Mobile Team (Chatbot)"
        Write-Host "#################################################################"
        az storage account show --name $storageAccountChatbot --resource-group $resourceGroupName
        az storage account delete --name $storageAccountChatbot --resource-group $resourceGroupName --yes

        Write-Host "#################################################################"
        Write-Host "#    All resources: "
        Write-Host "#################################################################"
        az resource list --resource-group $resourceGroupName --query []."name"
    }
}


# Get-RandomCharacters function is used to generate password
function Get-RandomCharacters($length, $characters) { 
    $random = 1..$length | ForEach-Object { Get-Random -Maximum $characters.length } 
    $private:ofs="" 
    return [String]$characters[$random]
}


function Get-Settings([string]$settingsFile, [string]$type) {
    if ([string]::IsNullOrEmpty($settingsFile)) {
        switch ($type)  {
            'pricingPlans' {
                $settingsFile = $settingsFolder + "/settings/" + $environment + ".psd1"
                break;
            }
            'securedConfig' {
                $settingsFile = "~/.hbcovid/" + $environment + "_secure.psd1"
                break;
            }
        }
    }
    else {
        if  (-Not (Test-Path -PathType Leaf $settingsFile)) {
            $settingsFile = $settingsFile + "/" + $environment + ".psd1"
        }
    }

    if (-Not (Test-Path -PathType Leaf $settingsFile)) {
        throw "File '$settingsFile' does not exists" 
    }
    else {
        return Import-PowerShellDataFile $settingsFile
    }
}


function Get-ResourceName($resourceName, $resourceList)  {
    $resourceFound = $false

    if ($resourceList -ne $null) {
        foreach ($resource in $resourcesList) { 
            if ($resource -like "$resourceName*" ) { 
                $resourceName = $resource
                $resourceFound = $true
            } 
        }
    }

    if (!$resourceFound) {
        $resourcePostfix = Get-RandomCharacters -length 2 -characters 'abcdefghiklmnoprstuvwxyz1234567890'
        $resourceName = $resourceName + $resourcePostfix
    }

    Write-Host "Get-ResourceName: $resourceName" -ForegroundColor Cyan
    return $resourceName
}



$subscriptionId =  $(az account show --query id -otsv)
Write-Host "Subscription ID: $subscriptionId " -ForegroundColor Green

az extension add --name notification-hub
az extension add --name db-up
az extension add --name application-insights
az extension add --name front-door

RemoveEnvironment -nc_Environment $environment -nc_Product $product -nc_GenerateRandomNames $false

