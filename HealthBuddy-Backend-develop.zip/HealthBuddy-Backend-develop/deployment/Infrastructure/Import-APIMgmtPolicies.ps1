﻿param (
    [Parameter(Mandatory=$true)] [ValidateLength(1, 8)] [string]$product, 
    [Parameter(Mandatory=$true)] [ValidateLength(1, 4)] [string]$environment, 
    [string]$resourceGroup, 
    [string]$settingsFolder, 
    [string]$configPricingPlansPath,
    [string]$configSecuredPath
)


if ([string]::IsNullOrEmpty($settingsFolder)) {
    $settingsFolder = "."
    $configsFolder =  (Get-Item ($settingsFolder).ToString()).Parent.FullName
}
else {
    $configsFolder =  $settingsFolder.ToString() + "/deployment"
    $settingsFolder = $settingsFolder.ToString() + "/deployment/Infrastructure"
}

if ([string]::IsNullOrEmpty($resourceGroup)) {
    $resourceGroupName = "rg-$($settings.region.key)-$environment-$product-01"
}
else {
    $resourceGroupName = $resourceGroup
}
Write-Host "Resource group name: $resourceGroupName"


function DeployAPIManagement {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        $resourceGroupName,
        [Parameter(Mandatory = $true)]
        [ValidateSet('Mobile endpoints', 'Maintenance endpoints', 'Integration endpoints', 'CMS endpoints')]
        $apiVersionSetName,
        [Parameter(Mandatory = $true)]
        [bool]$useSubscriptionKeys
    )

    $settings = Get-Settings -settingsFile $configPricingPlansPath -type "pricingPlans"
    $settingsSecured = Get-Settings -settingsFile $configSecuredPath -type "securedConfig"

    switch ($apiVersionSetName)  {
        'Mobile endpoints' {
            $apiSpecificationPath = $configsFolder + "/open-api/mobile_endpoints.yaml"
            $apiAllOperationsPolicyPath = $configsFolder + "/apim-policies/All operations.xml"
            $apiPoliciesPath = $configsFolder + "/apim-policies"
            break;
         }
         'Maintenance endpoints' {
            $apiSpecificationPath = $configsFolder + "/open-api/maintenance_endpoints.yaml"
            $apiAllOperationsPolicyPath = $configsFolder + "/apim-policies/All operations.xml"
            $apiPoliciesPath = $configsFolder + "/apim-policies"
            break;
         }
         'Integration endpoints' {
            $apiSpecificationPath = $configsFolder + "/open-api/integration_endpoints.yaml"
            $apiAllOperationsPolicyPath = $configsFolder + "/apim-policies/All operations.xml"
            $apiPoliciesPath = $configsFolder + "/apim-policies"
            break;
         }
         'CMS endpoints' {
            $apiSpecificationPath = $configsFolder + "/open-api/cms_endpoints.yaml"
            $apiAllOperationsPolicyPath = $configsFolder + "/apim-policies/All operations.xml"
            $apiPoliciesPath = $configsFolder + "/apim-policies"
            break;
         }
    }

    Write-Host  ""
    Write-Host "Specification path: $apiSpecificationPath"
    Write-Host "All operations policy path: $apiAllOperationsPolicyPath"
    Write-Host "Policies path: $apiPoliciesPath"

    $apiServiceName = "api-$($settings.region.key)-$environment-$product-01"

    $ApiMgmtContext = New-AzApiManagementContext -ResourceGroupName $resourceGroupName -ServiceName $apiServiceName
    Write-Host  "API Management Context: $($ApiMgmtContext.ResourceGroupName)/$($ApiMgmtContext.ServiceName)"

    Write-Host  ""
    Write-Host "####################################################################"
    Write-Host "# STEP 1. Removing an API Version Set '$apiVersionSetName'"
    Write-Host "####################################################################"

    $apiVersionSet = Get-AzApiManagementApiVersionSet -Context $ApiMgmtContext | where { $_.DisplayName -eq $apiVersionSetName }

    if ($apiVersionSet -ne $null) {
        Write-Host "API Version Set '$apiVersionSetName' has already exist."
        $apiManagementAPI = Get-AzApiManagementApi -Context $ApiMgmtContext -Name $apiVersionSetName

        if ($apiManagementAPI -ne $null) {
            foreach ($api in $apiManagementAPI) {
                $apiManagementSubscription = Get-AzApiManagementSubscription -Context $ApiMgmtContext -Scope "/apis/$($api.ApiId)"

                Write-Host "Removing API Management specification '$($api.Name)' id: '$($api.ApiId)'"
                Remove-AzApiManagementApi -Context $ApiMgmtContext -ApiId $api.ApiId

                if ($apiManagementSubscription -ne $null) {
                    Write-Host "Removing API Management subscriptions for scope '/apis/$($api.ApiId)'"

                    foreach ($subscr in $apiManagementSubscription) {
                        Write-Host "Removing API Management subscription $($subscr.Subscriptionid)'"
                        Remove-AzApiManagementSubscription -Context $ApiMgmtContext -SubscriptionId $subscr.Subscriptionid
                    }
                }
            }
        }
        Write-Host "Removing API Version Set '$apiVersionSetName'"
        Remove-AzApiManagementApiVersionSet -Context $ApiMgmtContext -ApiVersionSetId $apiVersionSet.ApiVersionSetId
    }

    Write-Host  ""
    Write-Host "####################################################################"
    Write-Host "# STEP 2. Creating an API Version Set '$apiVersionSetName'"
    Write-Host "####################################################################"

    $apiVersionSet = Get-AzApiManagementApiVersionSet -Context $ApiMgmtContext | where { $_.DisplayName -eq $apiVersionSetName }

    if ($apiVersionSet -eq $null) {
        $apiVersionSet = New-AzApiManagementApiVersionSet -Context $ApiMgmtContext -Name $apiVersionSetName -Scheme Segment
        $apiVersionSet
    }
    else {
        Write-Host "API Version Set '$apiVersionSetName' has already exist." -Foreground Yellow
        Write-Host "If you want to update it, please remove manually and rerun the script." -Foreground Yellow
    }

    Write-Host  ""
    Write-Host "####################################################################"
    Write-Host "# STEP 3. Importing an API specification from OpenApi"
    Write-Host "####################################################################"

    $apiVersionSetId = $apiVersionSet.ApiVersionSetId
    $apiManagementAPI = Get-AzApiManagementApi -Context $ApiMgmtContext -Name $apiVersionSetName

    if ($null -eq $apiManagementAPI) {
        Write-Host "Importing an API specification from $apiSpecificationPath ..."

        switch ($apiVersionSetName)  {
          'Mobile endpoints' {
             Import-AzApiManagementApi -Context $ApiMgmtContext `
               -SpecificationFormat "OpenApi" `
               -SpecificationPath $apiSpecificationPath `
               -Path "" `
               -ApiVersion "v1" `
               -ApiVersionSetId $apiVersionSetId
            break;
           }
           'Maintenance endpoints' {
             Import-AzApiManagementApi -Context $ApiMgmtContext `
                -SpecificationFormat "OpenApi" `
                -SpecificationPath $apiSpecificationPath `
                -Path "utils" `
                -ApiVersion "v1" `
                -ApiVersionSetId $apiVersionSetId
             break;
           }
           'Integration endpoints' {
             Import-AzApiManagementApi -Context $ApiMgmtContext `
                -SpecificationFormat "OpenApi" `
                -SpecificationPath $apiSpecificationPath `
                -Path "api" `
                -ApiVersion "v1" `
                -ApiVersionSetId $apiVersionSetId
             break;
           }
           'CMS endpoints' {
             Import-AzApiManagementApi -Context $ApiMgmtContext `
                -SpecificationFormat "OpenApi" `
                -SpecificationPath $apiSpecificationPath `
                -Path "cms-api" `
                -ApiVersion "v1" `
                -ApiVersionSetId $apiVersionSetId
             break;
           }
        }
    }
    else {
        Write-Host "API specification has alredy exist."
        Write-Host "If you want to update it, please remove manually and rerun the script."
    }

    Write-Host  ""
    Write-Host "####################################################################"
    Write-Host "# STEP 4. Importing an API policy for 'All operations'"
    Write-Host "####################################################################"

    $apiManagementAPI = Get-AzApiManagementApi -Context $ApiMgmtContext -Name $apiVersionSetName
    Write-Host "Importing an API policy for 'All operations' from $apiAllOperationsPolicyPath"
    Set-AzApiManagementPolicy -Context $ApiMgmtContext -ApiId $apiManagementAPI.ApiId -PolicyFilePath $apiAllOperationsPolicyPath `
                -Format "application/vnd.ms-azure-apim.policy.raw+xml"

    Write-Host  ""
    Write-Host "####################################################################"
    Write-Host "# STEP 5. Importing policies for API Management"
    Write-Host "####################################################################"

    $operations = Get-AzApiManagementOperation -Context $ApiMgmtContext -ApiId $apiManagementAPI.ApiId

    foreach($op in $operations) {
        $fileName = "$apiPoliciesPath/" + $op.Name + "xml"
        if (Test-Path $fileName -PathType leaf)  {
            Write-Host "Importing policy $fileName"
            $oId = $op.OperationId
            Set-AzApiManagementPolicy -Context $ApiMgmtContext -ApiId $apiManagementAPI.ApiId -OperationId $oId -PolicyFilePath $fileName `
                -Format "application/vnd.ms-azure-apim.policy.raw+xml"
        }
        else {
            Write-Host "Policy '$fileName' does not exist"  -Foreground Yellow
        }
    }

    Write-Host  ""
    Write-Host "####################################################################"
    Write-Host "# STEP 6. Configure Subscription keys utilization "
    Write-Host "####################################################################"

    if ($useSubscriptionKeys -eq $true) {
        if ($apiManagementAPI.SubscriptionRequired -eq $false) {
            Write-Host "Enabling 'Subscription required' parameter ..."
            $apiManagementAPI.SubscriptionRequired = $true
            Set-AzApiManagementApi -InputObject $apiManagementAPI -Name $apiManagementAPI.Name -ServiceUrl $apiManagementAPI.ServiceUrl -Protocols $apiManagementAPI.Protocols
        }

        switch ($apiVersionSetName)  {
          'Mobile endpoints' {
               $primaryKey = $settingsSecured.apimgmt.subscription.PublicEndpointsPrimaryKey
               $secondaryKey = $settingsSecured.apimgmt.subscription.PublicEndpointsSecondaryKey
            break;
           }
           'Maintenance endpoints' {
               $primaryKey = $settingsSecured.apimgmt.subscription.MaintenanceEndpointsPrimaryKey
               $secondaryKey = $settingsSecured.apimgmt.subscription.MaintenanceEndpointsSecondaryKey
             break;
           }
           'Integration endpoints' {
               $primaryKey = $settingsSecured.apimgmt.subscription.IntegrationEndpointsPrimaryKey
               $secondaryKey = $settingsSecured.apimgmt.subscription.IntegrationEndpointsSecondaryKey
             break;
           }
           'CMS endpoints' {
               $primaryKey = ""
               $secondaryKey = ""
               Write-Error "Such configuration is not supported."
             break;
           }
        }

        New-AzApiManagementSubscription -Context $ApiMgmtContext `
            -Scope "/apis/$($apiManagementAPI.ApiId)" `
            -Name "API: $apiVersionSetName" `
            -PrimaryKey $primaryKey `
            -SecondaryKey $secondaryKey
    }
    else {
        if ($apiManagementAPI.SubscriptionRequired -eq $true) {
            Write-Host "Removing 'Subscription required' parameter ..."
            $apiManagementAPI.SubscriptionRequired = $false
            Set-AzApiManagementApi -InputObject $apiManagementAPI -Name $apiManagementAPI.Name -ServiceUrl $apiManagementAPI.ServiceUrl -Protocols $apiManagementAPI.Protocols
        }
    }

}

function Get-Settings([string]$settingsFile, [string]$type) {
    if ([string]::IsNullOrEmpty($settingsFile)) {
        switch ($type)  {
            'pricingPlans' {
                $settingsFile = $settingsFolder + "/settings/" + $environment + ".psd1"
                break;
            }
            'securedConfig' {
                $settingsFile = "~/.hbcovid/" + $environment + "_secure.psd1"
                break;
            }
        }
    }
    else {
        if  (-Not (Test-Path -PathType Leaf $settingsFile)) {
            $settingsFile = $settingsFile + "/" + $environment + ".psd1"
        }
    }

    if (-Not (Test-Path -PathType Leaf $settingsFile)) {
        throw "File '$settingsFile' does not exists" 
    }
    else {
        return Import-PowerShellDataFile $settingsFile
    }
}


DeployAPIManagement -resourceGroupName $resourceGroupName -apiVersionSetName "Mobile endpoints" -useSubscriptionKeys $true
#DeployAPIManagement -resourceGroupName $resourceGroupName -apiVersionSetName "Maintenance endpoints" -useSubscriptionKeys $false
DeployAPIManagement -resourceGroupName $resourceGroupName -apiVersionSetName "Integration endpoints" -useSubscriptionKeys $true
DeployAPIManagement -resourceGroupName $resourceGroupName -apiVersionSetName "CMS endpoints" -useSubscriptionKeys $false
