# https://docs.microsoft.com/en-us/cli/azure/reference-index?view=azure-cli-latest

# Only two manadatory parameters:
# -product	any string up to 8 symbols
# -environment 	any string up to 4 symbols

param (
    [Parameter(Mandatory=$true)] [ValidateLength(1, 8)] [string]$product, 	# examples: epmcovi, hbcovid
    [Parameter(Mandatory=$true)] [ValidateLength(1, 4)] [string]$environment, 	# examples: dev1, qa1
    [string]$resourceGroup, 
    [string]$settingsFolder, 
    [string]$configPricingPlansPath,
    [string]$configSecuredPath,
    [string]$appleCertificateFile, 						# This setting is used only for Azure Devops pipelines
    [bool]$isAzurePipeline = $false
)


if ([string]::IsNullOrEmpty($settingsFolder)) {
     $settingsFolder = "."
}
else {
    $settingsFolder = $settingsFolder.ToString() + "/deployment/Infrastructure"
}


function DeployEnvironment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        $nc_Environment,
        [Parameter(Mandatory = $true)]
        $nc_Product,
        [Parameter(Mandatory = $false)]
        $nc_SecureAppServices = $false,
        [Parameter(Mandatory = $false)]
        $nc_GenerateRandomNames = $false
    )

    $settings = Get-Settings -settingsFile $configPricingPlansPath -type "pricingPlans"
    $settingsSecured = Get-Settings -settingsFile $configSecuredPath -type "securedConfig"

# Generating names according to 'Naming convention. Azure Resources.docx)
    $nc_Instance = "01" 
    $nc_Region = $settings.region.key

    $location = $settings.region.name
    $locationPostgreSQL = $settings.region.name
    $locationCosmosDB = $settings.region.name

    if ([string]::IsNullOrEmpty($resourceGroup)) {
        $resourceGroupName = "rg-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    }
    else {
       $resourceGroupName = $resourceGroup
   }

    $resourcesList = $null
    if ($nc_GenerateRandomNames -and $(az group exists --name $resourceGroupName) -eq "true") {
        $resourcesList = az resource list --resource-group $resourceGroupName --query []."name" | ConvertFrom-Json
    }

    $storageAccountChatbot = ("sa" + $nc_Region + $nc_Environment + $nc_Product + $nc_Instance + "mob").ToLower()
    if ($nc_GenerateRandomNames) {$storageAccountChatbot  = Get-ResourceName -resourceName $storageAccountChatbot -resourceList $resourcesList }

    $storageAccountWebJobsName = ("sa" + $nc_Region + $nc_Environment + $nc_Product + $nc_Instance + "app").ToLower()
    if ($nc_GenerateRandomNames) {$storageAccountWebJobsName = Get-ResourceName -resourceName $storageAccountWebJobsName -resourceList $resourcesList }

    $keyVaultName = "kv-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    if ($nc_GenerateRandomNames) {$keyVaultName = Get-ResourceName -resourceName $keyVaultName -resourceList $resourcesList }
    $keyVaultCertificateName = "cert-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"

    $appInsightsName = "ai-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    if ($nc_GenerateRandomNames) {$appInsightsName = Get-ResourceName -resourceName $appInsightsName -resourceList $resourcesList }

    $serviceBusNamespaceName = "sbus-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    if ($nc_GenerateRandomNames) {$serviceBusNamespaceName = Get-ResourceName -resourceName $serviceBusNamespaceName -resourceList $resourcesList }
    $serviceBusTopicName = "notifications"

    $appServicePlanName = "asp-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    if ($nc_GenerateRandomNames) {$appServicePlanName = Get-ResourceName -resourceName $appServicePlanName -resourceList $resourcesList }
    $webAppIsName = "wa-$nc_Region-$nc_Environment-$nc_Product-is-$nc_Instance"
    if ($nc_GenerateRandomNames) {$webAppIsName = Get-ResourceName -resourceName $webAppIsName -resourceList $resourcesList }
    $webAppUserName = "wa-$nc_Region-$nc_Environment-$nc_Product-user-$nc_Instance"
    if ($nc_GenerateRandomNames) {$webAppUserName = Get-ResourceName -resourceName $webAppUserName -resourceList $resourcesList }
    $webAppNotificationName = "wa-$nc_Region-$nc_Environment-$nc_Product-notification-$nc_Instance"
    if ($nc_GenerateRandomNames) {$webAppNotificationName = Get-ResourceName -resourceName $webAppInfectionName -resourceList $resourcesList }

    $cosmosDBaccountName = ("cassandra-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance").ToLower()
    if ($nc_GenerateRandomNames) {$cosmosDBaccountName = Get-ResourceName -resourceName $cosmosDBaccountName -resourceList $resourcesList }

    $appConfigName = "config-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    if ($nc_GenerateRandomNames) {$appConfigName = Get-ResourceName -resourceName $appConfigName -resourceList $resourcesList }

    $postgreSQLServerName = $settings.postgres.serverName
    if ([string]::IsNullOrEmpty($postgreSQLServerName)) {
        $postgreSQLServerName = "sql-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
        if ($nc_GenerateRandomNames) {$postgreSQLServerName = Get-ResourceName -resourceName $postgreSQLServerName -resourceList $resourcesList }
    }

    $notificationHubsNamespaceName = "nhub-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    $notificationHubName = $settingsSecured.notificationHub.name

    $APIManagementServiceName = "api-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"

    $functionAppNotificationName = "func-$nc_Region-$nc_Environment-$nc_Product-notification-$nc_Instance"
    if ($nc_GenerateRandomNames) {$functionAppNotificationName = Get-ResourceName -resourceName $functionAppNotificationName -resourceList $resourcesList }

    $frontDoorName = "fd-$nc_Region-$nc_Environment-$nc_Product-$nc_Instance"
    $frontDoorWAFPolicyName = ("waf" + $nc_Region + $nc_Environment + $nc_Product + $nc_Instance).ToLower()


# Other variables
    $clientId = "ed82e190-d95e-403e-bc8f-ca0d932b02c1"
    $scope = "openid offline_access userApi notificationApi apim"
    $secret = $settingsSecured.apimgmt.apiClientSecret

    Write-Host "#################################################################"
    Write-Host "#    Creating Resource Group"
    Write-Host "#################################################################"

    az group create --location $location --name $resourceGroupName

    $webAppList = az webapp list --resource-group $resourceGroupName --query "[].id" | ConvertFrom-JSON

    Write-Host "#################################################################"
    Write-Host "#    Creating Storage Account for Mobile Team (Chatbot)"
    Write-Host "#################################################################"

    az storage account create --name $storageAccountChatbot --resource-group $resourceGroupName --location $location `
        --access-tier  $settings.storageAccount.accessTier `
        --sku $settings.storageAccount.sku `
        --kind StorageV2 `
        --https-only true

    $storageAccountChatBotConnectionString = $(az storage account show-connection-string --name $storageAccountChatbot --resource-group $resourceGroupName --query "connectionString")

    az storage blob service-properties update --account-name $storageAccountChatbot `
        --connection-string $storageAccountChatBotConnectionString `
        --static-website --404-document 404.html `
        --index-document index.html


    Write-Host "#################################################################"
    Write-Host "#    Creating Storage Account 2 for Function App"
    Write-Host "#################################################################"

    az storage account create --name $storageAccountWebJobsName --resource-group $resourceGroupName --location $location `
        --access-tier  $settings.storageAccount.accessTier `
        --sku $settings.storageAccount.sku `
        --kind StorageV2 `
        --https-only true


    Write-Host "#################################################################"
    Write-Host "#    Creating Key Vault"
    Write-Host "#################################################################"

    az keyvault create --name $keyVaultName --resource-group $resourceGroupName --location $location `
       --sku $settings.keyvault.sku `
       --enable-soft-delete true

    # Attach self-signed certificate to key vault. Cert will be regenerated every run
    az keyvault certificate get-default-policy > policy.json
    az keyvault certificate create --name $keyVaultCertificateName --vault-name $keyVaultName --policy `@policy.json


    Write-Host "#################################################################"
    Write-Host "#    Creating App Configuration"
    Write-Host "#################################################################"

    az appconfig create --name $appConfigName --sku $settings.appconfig.sku --resource-group $resourceGroupName --location $location

    # import backend.json
    az appconfig kv import --yes --name $appConfigName `
        --source file --path $settingsFolder/Configs/backend.json --format json --separator ":"

    az appconfig kv import --yes --name $appConfigName `
        --source file --path $settingsFolder/Configs/statuses.json --format json --separator ":"

    az appconfig kv import --yes --name $appConfigName `
        --source file --path $settingsFolder/Configs/filters.json --format json --separator ":"

    az appconfig kv import --yes --name $appConfigName `
        --source file --path $settingsFolder/Configs/featureManagement.json --format json --separator ":"

    $appConfigConnectionString =  $(az appconfig credential list --name $appConfigName --resource-group $resourceGroupName --query [0]."connectionString")
    $appConfigUrl = "https://" + $appConfigName + ".azconfig.io"
    Write-Host "App Configuration Connection String: $appConfigConnectionString" -ForegroundColor Green


    Write-Host "#################################################################"
    Write-Host "#    Creating Service Bus Namespace and Topics"
    Write-Host "#################################################################"

    az servicebus namespace create --name $serviceBusNamespaceName --resource-group $resourceGroupName --location $location `
        --sku $settings.serviceBus.sku

    az servicebus topic create --namespace-name $serviceBusNamespaceName --resource-group $resourceGroupName `
        --name $serviceBusTopicName
    az servicebus topic authorization-rule create --topic-name $serviceBusTopicName --namespace-name $serviceBusNamespaceName --resource-group $resourceGroupName `
        --name "Send" `
        --rights Send
    az servicebus topic authorization-rule create --topic-name $serviceBusTopicName --namespace-name $serviceBusNamespaceName --resource-group $resourceGroupName `
        --name "Listen" `
        --rights Listen
    az servicebus topic subscription create --topic-name $serviceBusTopicName --namespace-name $serviceBusNamespaceName --resource-group $resourceGroupName `
        --name "StatusNotification"

    $notificationTopicListenConnection = $(az servicebus topic authorization-rule keys list --name Listen --topic-name $serviceBusTopicName --namespace-name $serviceBusNamespaceName --resource-group $resourceGroupName `
          --query primaryConnectionString) -replace ";EntityPath=notifications", ""

    $notificationTopicSendConnection = $(az servicebus topic authorization-rule keys list --name Send --topic-name $serviceBusTopicName --namespace-name $serviceBusNamespaceName --resource-group $resourceGroupName `
          --query primaryConnectionString) -replace ";EntityPath=notifications", ""

    az appconfig kv set --name $appConfigName --yes `
        --key ServiceBus:NotificationsTopic:SendConnection `
        --value $notificationTopicSendConnection

    az appconfig kv set --name $appConfigName --yes `
        --key ServiceBus:NotificationsTopic:TopicName `
        --value $serviceBusTopicName


    Write-Host "#################################################################"
    Write-Host "#    Creating Application Insight"
    Write-Host "#################################################################"

    az monitor app-insights component create --resource-group $resourceGroupName --location $location `
        --app $appInsightsName `

    $appInsightsKey = az resource show --name $appInsightsName --resource-group $resourceGroupName `
        --resource-type "Microsoft.Insights/components" `
        --query "properties.InstrumentationKey" -o tsv

    az appconfig kv set --name $appConfigName --yes `
        --key ApplicationInsights:InstrumentationKey `
        --value $appInsightsKey


    Write-Host "#################################################################"
    Write-Host "#    Creating CosmosDB account"
    Write-Host "#################################################################"

    az cosmosdb create --name $cosmosDBaccountName --resource-group $resourceGroupName `
        --locations regionName=$locationCosmosDB failoverPriority=0 isZoneRedundant=False `
        --capabilities EnableCassandra

    # Store password in key vault
    az keyvault secret set `
        --vault-name $keyVaultName `
        --name Cassandra-Credentials-Password `
        --value $(az cosmosdb keys list --name $cosmosDBaccountName --resource-group $resourceGroupName --query "primaryMasterKey")

    # Create keyvault reference in app config   
    az appconfig kv set-keyvault --yes `
        --name $appConfigName `
        --key "Cassandra:Credentials:Password" `
        --secret-identifier $(az keyvault secret show --vault-name $keyVaultName --name Cassandra-Credentials-Password --query "id") `

    # Store connection in app config 
    az appconfig kv import --yes --name $appConfigName `
        --source file --path $settingsFolder/Configs/cassandra-config.json --format json --separator ":"

    az appconfig kv set --name $appConfigName --yes `
        --key Cassandra:ContactPoints:0 `
        --value "$cosmosDBaccountName.cassandra.cosmos.azure.com"

    az appconfig kv set --name $appConfigName --yes `
        --key Cassandra:Credentials:UserName `
        --value $cosmosDBaccountName


    Write-Host "#################################################################"
    Write-Host "#    Creating PostgreSQL server"
    Write-Host "#################################################################"

    $postgreSQLServerAdminName = $settingsSecured.postgres.adminName
    $postgreSQLServerMinPoolSize = $settings.postgres.minPoolSize
    $postgreSQLServerMaxPoolSize = $settings.postgres.maxPoolSize

    $postgreSQLServerAdminPassword = Get-RandomCharacters -length 32 -characters 'ABCDEFGHKLMNOPRSTUVWXYZabcdefghiklmnoprstuvwxyz1234567890'

    az postgres up --server-name $postgreSQLServerName --resource-group $resourceGroupName --location $locationPostgreSQL `
        --database-name coronaresistance `
        --admin-user $postgreSQLServerAdminName `
        --admin-password $postgreSQLServerAdminPassword `
        --backup-retention 35 `
        --sku-name $settings.postgres.sku `
        --version 10 `
        --ssl-enforcement Enabled

    $postgreSQLServerConnectionString = "Server=$postgreSQLServerName.postgres.database.azure.com;Database=coronaresistance;Port=5432;User Id=$postgreSQLServerAdminName@$postgreSQLServerName;Password=$postgreSQLServerAdminPassword;Ssl Mode=Require;Pooling=true;Minimum Pool Size=$postgreSQLServerMinPoolSize;Maximum Pool Size=$postgreSQLServerMaxPoolSize;Timeout=300;Tcp Keepalive=true;"

    az postgres server configuration set --resource-group $resourceGroupName --server-name $postgreSQLServerName --name tcp_keepalives_count --value $settings.postgres.tcp_keepalives_count
    az postgres server configuration set --resource-group $resourceGroupName --server-name $postgreSQLServerName --name tcp_keepalives_idle --value $settings.postgres.tcp_keepalives_idle
    az postgres server configuration set --resource-group $resourceGroupName --server-name $postgreSQLServerName --name tcp_keepalives_interval --value $settings.postgres.tcp_keepalives_interval
    
    az keyvault secret set `
        --vault-name $keyVaultName `
        --name Identity-Connection-String `
        --value $postgreSQLServerConnectionString


    Write-Host "#################################################################"
    Write-Host "#    Creating Net Core Application - Is"
    Write-Host "#################################################################"

    $appServiceSku = $settings.appservice.sku.Tostring()
    $appServiceCapacity = $settings.appservice.capacity.Tostring()

    $webAppExist = $false
    foreach ($wa in $webAppList) { if ($wa -like "*/sites/$webAppIsName" ) { $webAppExist = $true } }
    
    if (!$webAppExist) {
#    Issue with netcore for Azure CLI:  az webapp create --name $webAppIsName --resource-group $resourceGroupName --plan $appServicePlanName 
        az deployment group create --resource-group $resourceGroupName `
            --name DeployNetCoreApp-Is `
            --template-file $settingsFolder/Templates/NetCoreApp.json `
            --parameters webAppName=$webAppIsName AppServicePlanName=$appServicePlanName AppServiceSKU=$appServiceSku
    }

    # scope should be restricted (only App Configuration resource)
    az webapp identity assign --name $webAppIsName --resource-group $resourceGroupName `
        --role "App Configuration Data Reader" `
        --scope /subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.AppConfiguration/configurationStores/$appConfigName

    az keyvault set-policy --name $keyVaultName `
         --object-id $(az webapp identity show --name $webAppIsName --resource-group $resourceGroupName --query principalId) `
         --secret-permissions get

    # App settings
    az webapp config appsettings set --name $webAppIsName --resource-group $resourceGroupName `
        --settings KeyVault:BaseUrl=$(az keyvault show --name $keyVaultName --query properties.vaultUri)

    az webapp config appsettings set --name $webAppIsName --resource-group $resourceGroupName `
        --settings KeyVault:SecretName=$keyVaultCertificateName

    az webapp config appsettings set --name $webAppIsName --resource-group $resourceGroupName `
        --settings AppConfig:BaseUrl=$appConfigUrl

    # App connection strings
    az webapp config connection-string set --name $webAppIsName --resource-group $resourceGroupName `
        --connection-string-type PostgreSQL `
        --settings ConnectionStrings:IdentityConnectionString=$postgreSQLServerConnectionString

    az webapp config connection-string set --name $webAppIsName --resource-group $resourceGroupName `
        --connection-string-type PostgreSQL `
        --settings ConnectionStrings:IdentityServerConnectionString=$postgreSQLServerConnectionString

    az webapp config connection-string set --name $webAppIsName --resource-group $resourceGroupName `
        --connection-string-type Custom `
        --settings AppConfig=$appConfigConnectionString

    $webAppIsURL = "https://" + $(az webapp show --name $webAppIsName --resource-group $resourceGroupName --query hostNames[0])
    Write-Host "App Service 'IS' Connection String: $webAppIsURL" -ForegroundColor Cyan


    Write-Host "#################################################################"
    Write-Host "#    Creating Net Core Application - User"
    Write-Host "#################################################################"

    $appServiceSku = $settings.appservice.sku.Tostring()

    $webAppExist = $false
    foreach ($wa in $webAppList) { if ($wa -like "*/sites/$webAppUserName" ) { $webAppExist = $true } }

    if (!$webAppExist) {
        az deployment group create --resource-group $resourceGroupName `
            --name DeployNetCoreApp-User `
            --template-file $settingsFolder/Templates/NetCoreApp.json `
            --parameters webAppName=$webAppUserName  AppServicePlanName=$appServicePlanName AppServiceSKU=$appServiceSku
    }

    # scope should be restricted (only App Configuration resource)
    az webapp identity assign --name $webAppUserName --resource-group $resourceGroupName `
        --role "App Configuration Data Reader" `
        --scope /subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.AppConfiguration/configurationStores/$appConfigName

    az keyvault set-policy --name $keyVaultName `
         --object-id $(az webapp identity show --name $webAppUserName --resource-group $resourceGroupName --query principalId) `
         --secret-permissions get

    # App settings
    az webapp config appsettings set --name $webAppUserName --resource-group $resourceGroupName `
        --settings ApiIdentity:Authority=$webAppIsURL

    az webapp config appsettings set --name $webAppUserName --resource-group $resourceGroupName `
        --settings ApiIdentity:ClientId="userApi"

    az webapp config appsettings set --name $webAppUserName --resource-group $resourceGroupName `
        --settings ApiIdentity:ClientSecret=$secret

    az webapp config appsettings set --name $webAppUserName --resource-group $resourceGroupName `
        --settings ClientIdentity:Authority=$webAppIsURL

    az webapp config appsettings set --name $webAppUserName --resource-group $resourceGroupName `
        --settings ClientIdentity:ClientId=$clientId

    az webapp config appsettings set --name $webAppUserName --resource-group $resourceGroupName `
        --settings ClientIdentity:Scope=$scope

    az webapp config appsettings set --name $webAppUserName --resource-group $resourceGroupName `
        --settings AppConfig:BaseUrl=$appConfigUrl

    # App connection strings
    az webapp config connection-string set --name $webAppUserName --resource-group $resourceGroupName `
        --connection-string-type Custom `
        --settings AppConfig=$appConfigConnectionString

    az webapp config connection-string set --name $webAppUserName --resource-group $resourceGroupName `
        --connection-string-type PostgreSQL `
        --settings ConnectionStrings:IdentityConnectionString=$postgreSQLServerConnectionString


    Write-Host "#################################################################" 
    Write-Host "#    Deployment Net Core Application - Notification"
    Write-Host "#################################################################"

    $appServiceSku = $settings.appservice.sku.Tostring()

    $webAppExist = $false
    foreach ($wa in $webAppList) { if ($wa -like "*/sites/$webAppNotificationName" ) { $webAppExist = $true } }

    if (!$webAppExist) {
        az deployment group create --resource-group $resourceGroupName `
            --name DeployNetCoreApp-Notification `
            --template-file $settingsFolder/Templates/NetCoreApp.json `
            --parameters webAppName=$webAppNotificationName  AppServicePlanName=$appServicePlanName AppServiceSKU=$appServiceSku
    }

    # scope should be restricted (only App Configuration resource)
    az webapp identity assign --name $webAppNotificationName --resource-group $resourceGroupName `
        --role "App Configuration Data Reader" `
        --scope /subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.AppConfiguration/configurationStores/$appConfigName

    az keyvault set-policy --name $keyVaultName `
         --object-id $(az webapp identity show --name $webAppNotificationName --resource-group $resourceGroupName --query principalId) `
         --secret-permissions get

    # App settings
    az webapp config appsettings set --name $webAppNotificationName --resource-group $resourceGroupName `
        --settings ApiIdentity:Authority=$webAppIsURL

    az webapp config appsettings set --name $webAppNotificationName --resource-group $resourceGroupName `
        --settings ApiIdentity:ClientId="notificationApi"

    az webapp config appsettings set --name $webAppNotificationName --resource-group $resourceGroupName `
        --settings ApiIdentity:ClientSecret=$secret

    az webapp config appsettings set --name $webAppNotificationName --resource-group $resourceGroupName `
        --settings AppConfig:BaseUrl=$appConfigUrl

    az webapp config appsettings set --name $webAppNotificationName --resource-group $resourceGroupName `
        --settings ClientIdentity:Authority=$webAppIsURL

    az webapp config appsettings set --name $webAppNotificationName --resource-group $resourceGroupName `
        --settings ClientIdentity:ClientId=$clientId

    az webapp config appsettings set --name $webAppNotificationName --resource-group $resourceGroupName `
        --settings ClientIdentity:Scope=$scope

    az webapp config appsettings set --name $webAppNotificationName --resource-group $resourceGroupName `
        --settings ServiceBus:ConnectionString=$notificationTopicListenConnection

    az webapp config appsettings set --name $webAppNotificationName --resource-group $resourceGroupName `
        --settings ServiceBus:NotificationsTopicName=$serviceBusTopicName

    # App connection strings
    az webapp config connection-string set --name $webAppNotificationName --resource-group $resourceGroupName `
        --connection-string-type Custom `
        --settings AppConfig=$appConfigConnectionString


    Write-Host "#################################################################" 
    Write-Host "#    Creating FrontDoor and WAF policy - Step 1 of 2"
    Write-Host "#################################################################"

    $tempHostNameWillBeReplaced =  $webAppUserName + ".azurewebsites.net"

    az network front-door create --name $frontDoorName --resource-group $resourceGroupName `
        --backend-address $tempHostNameWillBeReplaced `
        --accepted-protocols Https `

    $frontDoorId = az network front-door show --name $frontDoorName --resource-group $resourceGroupName --query "frontdoorId"
    Write-Host "Front Door id = $frontDoorId"


    Write-Host "#################################################################"
    Write-Host "#    Creating API Management Service"
    Write-Host "#################################################################"

    $identityServerBaseUrl = "https://" + $webAppIsName + ".azurewebsites.net"
    $userApiBaseUrl = "https://" + $webAppUserName + ".azurewebsites.net"
    $notificationApiBaseUrl = "https://" + $webAppNotificationName + ".azurewebsites.net"
    $apimBaseUrl = "https://" + $APIManagementServiceName + ".azure-api.net"
    $englishLanguageCode = "en"
    $imagesFrontDoorCacheTtlSeconds = $settings.apimgmt.imagesFrontDoorCacheTtlSeconds.ToString()
    $articlesFrontDoorCacheTtlSeconds = $settings.apimgmt.articlesFrontDoorCacheTtlSeconds.ToString()
    $metadataFrontDoorCacheTtlSeconds = $settings.apimgmt.metadataFrontDoorCacheTtlSeconds.ToString()
    $filtersCacheTtlSeconds = $settings.apimgmt.filtersCacheTtlSeconds.ToString()
    $frontDoorBaseUrl = "https://" + $frontDoorName + ".azurefd.net"
    $apiMgmtSku = $settings.apimgmt.sku.ToString()
    $cmsBaseUrl = $settingsSecured.apimgmt.cmsBaseUrl.ToString()
    $cmsUserName = $settingsSecured.apimgmt.cmsUserName.ToString()
    $rapidProUserName = $settingsSecured.apimgmt.rapidProUserName
    $webSiteBaseUrl = $settingsSecured.apimgmt.webSiteBaseUrl.ToString()
 
    if ($apiMgmtSku -eq "Consumption") { $apiMgmtSkuCount = "0"  }
    else { $apiMgmtSkuCount = "1"  }

    az deployment group create --resource-group $resourceGroupName `
        --name DeployAPIManagementService `
        --template-file $settingsFolder/Templates/APIManagementService.json `
        --parameters `
             APIManagementServiceName=$APIManagementServiceName `
             publisherEmail=test@epam.com `
             publisherName=EPAM `
             apimBaseUrl=$apimBaseUrl `
             apiClientId="apim" `
             apiClientSecret=$secret `
             clientId=$clientId `
             cmsBaseUrl=$cmsBaseUrl `
             cmsUserName=$cmsUserName `
             englishLanguageCode=$englishLanguageCode `
             imagesFrontDoorCacheTtlSeconds=$imagesFrontDoorCacheTtlSeconds `
             articlesFrontDoorCacheTtlSeconds=$articlesFrontDoorCacheTtlSeconds `
             metadataFrontDoorCacheTtlSeconds=$metadataFrontDoorCacheTtlSeconds `
             filtersCacheTtlSeconds=$filtersCacheTtlSeconds `
             frontDoorBaseUrl=$frontDoorBaseUrl `
             frontDoorId=$frontDoorId `
             identityServerBaseUrl=$identityServerBaseUrl `
             notificationApiBaseUrl=$notificationApiBaseUrl `
             scope=$scope `
             rapidProUserName=$rapidProUserName `
             userApiBaseUrl=$userApiBaseUrl `
             webSiteBaseUrl=$webSiteBaseUrl `
             sku=$apiMgmtSku `
             skuCount=$apiMgmtSkuCount 

    if ($isAzurePipeline) { 

    }
    else {
        $apimContext = New-AzApiManagementContext -ResourceGroupName $resourceGroupName -ServiceName $APIManagementServiceName

        New-AzApiManagementNamedValue -Context $apimContext `
            -NamedValueId "cmsUserPassword" -Name "cmsUserPassword" -Value $settingsSecured.apimgmt.cmsUserPassword -Secret
        New-AzApiManagementNamedValue -Context $apimContext `
            -NamedValueId "rapidProUserPassword" -Name "rapidProUserPassword" -Value $settingsSecured.apimgmt.rapidProUserPassword -Secret
    }


    Write-Host "#################################################################"
    Write-Host "#    Creating FrontDoor and WAF policy - Step 2 of 2"
    Write-Host "#################################################################"

    $APIManagementServiceHostName = az apim show --name $APIManagementServiceName --resource-group $resourceGroupName --query "hostnameConfigurations[0].hostName"
    $Host.UI.RawUI.ForegroundColor = 'White'

    # Creating default WAF policy
    az network front-door waf-policy create --name $frontDoorWAFPolicyName --resource-group $resourceGroupName `
        --mode Prevention

    az network front-door waf-policy managed-rules add --policy-name $frontDoorWAFPolicyName --resource-group $resourceGroupName `
        --type DefaultRuleSet `
        --version 1.0

    $frontDoorWAFPolicyId = az network front-door waf-policy show --name $frontDoorWAFPolicyName --resource-group $resourceGroupName --query id 

    $frontDoorFrontendConfig = az network front-door show --name $frontDoorName --resource-group $resourceGroupName `
        --query frontendEndpoints[0] | ConvertFrom-JSON

    $frontDoorBackendPoolName = "DefaultBackendPool"
    $frontDoorBackendPoolConfig = az network front-door backend-pool show --resource-group $resourceGroupName --front-door-name $frontDoorName `
        --name $frontDoorBackendPoolName | ConvertFrom-JSON

    # Bind WAF policy to Front Door
    az network front-door frontend-endpoint create --front-door-name $frontDoorName --resource-group $resourceGroupName `
       --name $frontDoorFrontendConfig.name `
       --host-name $frontDoorFrontendConfig.hostName `
       --waf-policy $frontDoorWAFPolicyId

    # Update backend name to point out on API managment
    az network front-door backend-pool create --front-door-name $frontDoorName --resource-group $resourceGroupName `
       --name $frontDoorBackendPoolName `
       --address $APIManagementServiceHostName `
       --load-balancing $frontDoorBackendPoolConfig.loadBalancingSettings.id `
       --probe $frontDoorBackendPoolConfig.healthProbeSettings.id `

    # Disable probes
    az network front-door probe update --front-door-name $frontDoorName --resource-group $resourceGroupName `
       --name DefaultProbeSettings `
       --enabled Disabled

    # Enable caching
    az network front-door routing-rule update --front-door-name $frontDoorName --resource-group $resourceGroupName `
       --name DefaultRoutingRule `
       --caching Enabled


    Write-Host "#################################################################"
    Write-Host "#    Creating Notification Hub"
    Write-Host "#################################################################"

    az notification-hub namespace create --resource-group $resourceGroupName --location $location `
        --name $notificationHubsNamespaceName `
        --sku $settings.notificationHub.sku

    # Delay to avoid messages 'Notification Hub Namespace is not ready or not found"
    Write-Host "Delay 60 seconds" -ForegroundColor Cyan
    Start-Sleep -Seconds 60
    Write-Host "Creating Notification Hub:" -ForegroundColor Green

    az notification-hub create --namespace-name $notificationHubsNamespaceName --resource-group $resourceGroupName --location $location `
        --name $notificationHubName

    $Host.UI.RawUI.ForegroundColor = 'White'

    # Update Google (GCM/FCM) key
    az notification-hub credential gcm update --namespace-name $notificationHubsNamespaceName --resource-group $resourceGroupName `
        --notification-hub-name $notificationHubName `
        --google-api-key $settingsSecured.notificationHub.credentials.googleAPIKey

    $Host.UI.RawUI.ForegroundColor = 'White'

    $notificationHubConnection =  $(az notification-hub authorization-rule list-keys --namespace-name $notificationHubsNamespaceName --resource-group $resourceGroupName `
        --notification-hub-name $notificationHubName --name DefaultFullSharedAccessSignature --query primaryConnectionString)

    $Host.UI.RawUI.ForegroundColor = 'White'

    # Update Apple (APNS) certificate
    # https://docs.microsoft.com/en-us/cli/azure/ext/notification-hub/notification-hub/credential/apns?view=azure-cli-latest#ext-notification-hub-az-notification-hub-credential-apns-update

    if ($isAzurePipeline -eq $true) { $apnsCertificate = $appleCertificateFile }
    else { $apnsCertificate = $settingsSecured.notificationHub.credentials.appleCertificateFile }

    az notification-hub credential apns update --namespace-name $notificationHubsNamespaceName --resource-group $resourceGroupName `
        --notification-hub-name $notificationHubName `
        --apns-certificate $apnsCertificate `
        --certificate-key $settingsSecured.notificationHub.credentials.appleCertificateKey


    Write-Host "#################################################################"
    Write-Host "#    Creating Function App - Notification"
    Write-Host "#################################################################"

    # Checks if function exists. Command 'az functionapp create' is not idempotent
    $funcExist = $false
    $funcList = az functionapp list --resource-group $resourceGroupName --query "[].id" | ConvertFrom-JSON
    foreach ($func in $funcList) { if ($func -like "*/sites/$functionAppNotificationName" ) { $funcExist = $true } }
    
    if (!$funcExist) {
        az functionapp create --resource-group $resourceGroupName  --storage-account $storageAccountWebJobsName `
            --name $functionAppNotificationName `
            --os-type Windows `
            --runtime dotnet `
            --functions-version 3 `
            --plan $appServicePlanName `
            --app-insights $appInsightsName
    }

    az functionapp update --name $functionAppNotificationName --resource-group $resourceGroupName `
        --set httpsOnly=true

    az functionapp identity assign --name $functionAppNotificationName --resource-group $resourceGroupName `
        --role "App Configuration Data Reader" `
        --scope /subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.AppConfiguration/configurationStores/$appConfigName

    az keyvault set-policy --name $keyVaultName `
         --object-id $(az functionapp identity show --name $functionAppNotificationName --resource-group $resourceGroupName --query principalId) `
         --secret-permissions get

    # AppConfig setting
    az functionapp config appsettings set --name $functionAppNotificationName --resource-group $resourceGroupName `
        --settings AppConfig:BaseUrl=$appConfigUrl

    az functionapp config appsettings set --name $functionAppNotificationName --resource-group $resourceGroupName `
        --settings NotificationHub:Connection=$notificationHubConnection

    az functionapp config appsettings set --name $functionAppNotificationName --resource-group $resourceGroupName `
        --settings NotificationHub:Name=$notificationHubName

    az functionapp config appsettings set --name $functionAppNotificationName --resource-group $resourceGroupName `
        --settings NotificationsTopicListenConnection=$notificationTopicListenConnection

    az functionapp config appsettings set --name $functionAppNotificationName --resource-group $resourceGroupName `
        --settings NotificationsTopicName="notifications"

    az functionapp config appsettings set --name $functionAppNotificationName --resource-group $resourceGroupName `
        --settings StatusNotificationSubscription="StatusNotification"

    az functionapp config appsettings set --name $functionAppNotificationName --resource-group $resourceGroupName `
        --settings RetryPolicy:MaxRetryCount=3


    Write-Host "#################################################################"
    Write-Host "#    App Service plan checking/updating"
    Write-Host "#################################################################"

    $appServicePlanSettings = az appservice plan show --name $appServicePlanName --resource-group $resourceGroupName | ConvertFrom-JSON

    if (($appServiceSku -ne $appServicePlanSettings.sku.size) -or ($appServiceCapacity -ne $appServicePlanSettings.sku.capacity)) {
        az appservice plan update --name $appServicePlanName --resource-group $resourceGroupName `
            --sku $appServiceSku --number-of-workers $appServiceCapacity
    }

    if ($nc_SecureAppServices -eq $true) {

        Write-Host "#################################################################"
        Write-Host "#    Updating security access rules for App services"
        Write-Host "#################################################################"

        #https://azure.microsoft.com/en-us/global-infrastructure/geographies/
        #https://docs.microsoft.com/en-us/azure/devops/pipelines/agents/hosted?view=azure-devops&tabs=yaml#agent-ip-ranges
        #$AzureDevopsIPList1 = $($serviceTags | where name -like $serviceTagsRegion).properties.addressPrefixes
        #$AzureDevopsIPList2 = $($serviceTags | where name -like "AzureCloud.NorthEurope").properties.addressPrefixes
        #$AzureDevopsIPList = $AzureDevopsIPList1 + $AzureDevopsIPList2

        if ($apiMgmtSku -eq "Consumption") { 
            # For API Management Consumption tier all Azure Datacenters ip ranges in the region should be selected
            $serviceTags = (Get-Content $settingsFolder/Configs/ServiceTags.json | ConvertFrom-Json).values
            $serviceTagsRegion = "AzureCloud." + $settings.region.name

            $APIManagementIPList = $($serviceTags | where name -like $serviceTagsRegion).properties.addressPrefixes
        }
        else { 
            #$Allow all: APIManagementIPList = @("0.0.0.0/0")
            $APIManagementIPList = $(az apim show --name $APIManagementServiceName --resource-group $resourceGroupName | ConvertFrom-JSON).publicIpAddresses.foreach({$_ + "/32"})
        }

        $webAppIsIPList = $($($(az webapp show --name $webAppIsName --resource-group $resourceGroupName | ConvertFrom-JSON).possibleOutboundIpAddresses).split(",")).foreach({$_ + "/32"})
        $webAppUserIPList = $($($(az webapp show --name $webAppUserName --resource-group $resourceGroupName | ConvertFrom-JSON).possibleOutboundIpAddresses).split(",")).foreach({$_ + "/32"})
        $webAppNotificationIPList = $($($(az webapp show --name $webAppNotificationName --resource-group $resourceGroupName | ConvertFrom-JSON).possibleOutboundIpAddresses).split(",")).foreach({$_ + "/32"})
        $functionAppNotificationIPList = $($($(az functionapp show --name $functionAppNotificationName --resource-group $resourceGroupName | ConvertFrom-JSON).possibleOutboundIpAddresses).split(",")).foreach({$_ + "/32"})

        $webAppIsIPAccessList = $APIManagementIPList + $webAppUserIPList + $webAppNotificationIPList
        $webAppUserIPAccessList = $APIManagementIPList
        $webAppNotificationIPAccessList = $APIManagementIPList

        # If necessary to disable custom access rules create empty array variables, example: $webAppIsIPAccessList = @()
        Update-AccessList -webAppName $webAppIsName -resourceGroupName $resourceGroupName -scmSite $false -newACL $webAppIsIPAccessList
        Update-AccessList -webAppName $webAppUserName -resourceGroupName $resourceGroupName -scmSite $false -newACL $webAppUserIPAccessList
        Update-AccessList -webAppName $webAppNotificationName -resourceGroupName $resourceGroupName -scmSite $false -newACL $webAppNotificationIPAccessList
    }

}


# Get-RandomCharacters function is used to generate password
function Get-RandomCharacters($length, $characters) { 
    $random = 1..$length | ForEach-Object { Get-Random -Maximum $characters.length } 
    $private:ofs="" 
    return [String]$characters[$random]
}


function Get-Settings([string]$settingsFile, [string]$type) {
    if ([string]::IsNullOrEmpty($settingsFile)) {
        switch ($type)  {
            'pricingPlans' {
                $settingsFile = $settingsFolder + "/settings/" + $environment + ".psd1"
                break;
            }
            'securedConfig' {
                $settingsFile = "~/.hbcovid/" + $environment + "_secure.psd1"
                break;
            }
        }
    }
    else {
        if  (-Not (Test-Path -PathType Leaf $settingsFile)) {
            $settingsFile = $settingsFile + "/" + $environment + ".psd1"
        }
    }

    if (-Not (Test-Path -PathType Leaf $settingsFile)) {
        throw "File '$settingsFile' does not exists" 
    }
    else {
        return Import-PowerShellDataFile $settingsFile
    }
}


function Get-ResourceName($resourceName, $resourceList)  {
    $resourceFound = $false

    if ($resourceList -ne $null) {
        foreach ($resource in $resourcesList) { 
            if ($resource -like "$resourceName*" ) { 
                $resourceName = $resource
                $resourceFound = $true
            } 
        }
    }

    if (!$resourceFound) {
        $resourcePostfix = Get-RandomCharacters -length 2 -characters 'abcdefghiklmnoprstuvwxyz1234567890'
        $resourceName = $resourceName + $resourcePostfix
    }

    Write-Host "Get-ResourceName: $resourceName" -ForegroundColor Cyan
    return $resourceName
}

function Update-AccessList($webAppName, $resourceGroupName, $scmSite, $newACL) { 
    $aclRulePriority = 1000

    Write-Host
    Write-Host "Updating access rules for $webAppName"

    if ($scmSite) {
        $webAppAccessList = $(az webapp config access-restriction show --name $webAppName --resource-group $resourceGroupName `
                                | ConvertFrom-JSON).scmIpSecurityRestrictions | where {($_.action -eq 'Allow') -and ($_.priority -gt $aclRulePriority)}
        $scmFlag = "true"
        $ruleName = "AzureDevops"
    }
    else {
        $webAppAccessList = $(az webapp config access-restriction show --name $webAppName --resource-group $resourceGroupName `
                                | ConvertFrom-JSON).ipSecurityRestrictions | where {($_.action -eq 'Allow') -and ($_.priority -gt $aclRulePriority)}
        $scmFlag = "false"
        $ruleName = "Backend"
    }
    
    $Host.UI.RawUI.ForegroundColor = 'White'

    if ($webAppAccessList) {
        $aclRulePriority = $($webAppAccessList | sort priority -descending)[0].priority
        $webAppIPAccessList = $webAppAccessList.ip_address
    }
    else { 
        $webAppAccessList = @()
        $webAppIPAccessList = @()
    }

    Write-Host "Checking new IP ranges..."

    $i = 0
    foreach ($ipRange in $newACL) { if ((!$webAppIPAccessList) -or (!$webAppIPAccessList.Contains($ipRange))) { $i++ } }
    Write-Host "$i IP ranges have been found for appending"


    foreach ($ipRange in $newACL) {
        if ((!$webAppIPAccessList) -or (!$webAppIPAccessList.Contains($ipRange))) {
            $aclRulePriority++
            Write-Host "$aclRulePriority Adding new IP Range: $ipRange"
            $webAppIPAccessList += $ipRange
            $hideOutput = az webapp config access-restriction add --name $webAppName --resource-group $resourceGroupName `
                              --rule-name $ruleName `
                              --action Allow `
                              --ip-address $ipRange `
                              --priority $aclRulePriority `
                              --scm-site $scmFlag
            $Host.UI.RawUI.ForegroundColor = 'White'
        }
    }

    if ($aclRulePriority -eq 1000) { Write-Host "No updates" }

    Write-Host "Checking old IP ranges..."

    $i = 0
    foreach ($ipRange in $webAppIPAccessList) { if (!$newACL.Contains($ipRange)) { $i++ } }
    Write-Host "$i IP ranges have been found for deletion"

    $i = 0
    foreach ($ipRange in $webAppIPAccessList) {
        if (!$newACL.Contains($ipRange)) {
            $i++
            Write-Host "$i Removing IP Range: $ipRange"
            $ruleNames = $($webAppAccessList | where ip_address -eq $ipRange).name

            foreach ($ruleName in $ruleNames) {
#                Write-Host "az webapp config access-restriction remove --name $webAppName --resource-group $resourceGroupName --rule-name $ruleName --action Allow --ip-address $ipRange --scm-site $scmFlag"
                $hideOutput = az webapp config access-restriction remove --name $webAppName --resource-group $resourceGroupName `
                    --rule-name $ruleName `
                    --action Allow  `
                    --ip-address $ipRange `
                    --scm-site $scmFlag
                $Host.UI.RawUI.ForegroundColor = 'White'
            }
        }
    }
    if ($i -eq 0) { Write-Host "No updates" }

    $Host.UI.RawUI.ForegroundColor = 'White'
    Write-Host "Active rules list: "
    if ($scmSite) {
        $($(az webapp config access-restriction show --name $webAppName --resource-group $resourceGroupName `
            | ConvertFrom-JSON).scmIpSecurityRestrictions).ip_address
    }
    else {
        $($(az webapp config access-restriction show --name $webAppName --resource-group $resourceGroupName `
            | ConvertFrom-JSON).ipSecurityRestrictions).ip_address
    }

}



$subscriptionId =  $(az account show --query id -otsv)
Write-Host "Subscription ID: $subscriptionId " -ForegroundColor Green

az extension add --name notification-hub
az extension add --name db-up
az extension add --name application-insights
az extension add --name front-door

DeployEnvironment -nc_Environment $environment -nc_Product $product -nc_GenerateRandomNames $false -nc_SecureAppServices $true

