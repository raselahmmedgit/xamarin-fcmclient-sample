// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Options;
using Epam.CovidResistance.Shared.Configuration.Interfaces;
using Epam.CovidResistance.Shared.Configuration.Services;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.Extensions.Caching.Memory;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Threading.Tasks;

namespace Configuration.UnitTests.Services
{
    public class FiltersServiceDecoratorTests
    {
        #region Test_Setup

        private const string LangCode = "en";
        private const string Url = "https://foo.bar";
        private const string AuthInfo = "Basic <token>";

        private Filters filters;
        private IFiltersService filtersService;
        private IMemoryCache memoryCache;
        private CachingFiltersService cachingFiltersService;

        [SetUp]
        public void Setup()
        {
            memoryCache = Substitute.For<IMemoryCache>();

            filtersService = Substitute.For<IFiltersService>();
            filters = new Filters
            {
                Items = new[]
                {
                    new Filter
                    {
                        DisplayName = "Filter",
                        ParameterName = "Parameter",
                        IsMultiSelect = false
                    } 
                }
            };
            
            cachingFiltersService = new CachingFiltersService(filtersService, memoryCache);
        }

        #endregion

        #region GetAsync (with caching)
        
        [Test]
        public async Task GetAsync_Should_ReturnCachedFilters()
        {
            // Arrange
            memoryCache.TryGetValue(LangCode, out Arg.Any<Filters>()).Returns(x =>
            {
                x[1] = filters;
                return true;
            });

            // Act
            Filters actualFilters = await cachingFiltersService.GetAsync(LangCode, default, default, default);

            // Assert
            memoryCache.Received().TryGetValue(LangCode, out Arg.Any<Filters>());
            actualFilters.Should().BeEquivalentTo(filters);
        }
        
        [TestCase(null)]
        [TestCase("")]
        public async Task GetAsync_Should_NotReturnCachedFilters_When_LanguageCodeIsNullOrEmpty(string langCode)
        {
            // Arrange
            memoryCache.TryGetValue(langCode, out Arg.Any<Filters>()).Returns(x =>
            {
                x[1] = filters;
                return true;
            });

            // Act
            Filters actualFilters = await cachingFiltersService.GetAsync(langCode, default, default, default);

            // Assert
            memoryCache.DidNotReceive().TryGetValue(langCode, out Arg.Any<Filters>());
            actualFilters.Should().NotBeEquivalentTo(filters);
        }
        
        [Test]
        public async Task GetAsync_Should_GetFiltersFromFiltersService_When_FiltersAreNotCached()
        {
            // Arrange
            memoryCache.TryGetValue(LangCode, out Arg.Any<Filters>()).Returns(false);
            filtersService.GetAsync(LangCode, Url, AuthInfo).Returns(filters);

            // Act
            Filters actualFilters = await cachingFiltersService.GetAsync(LangCode, Url, AuthInfo, 0);

            // Assert
            memoryCache.DidNotReceiveWithAnyArgs().TryGetValue(default, out Arg.Any<Filters>());
            await filtersService.Received().GetAsync(LangCode, Url, AuthInfo);
            actualFilters.Should().BeEquivalentTo(filters);
        }
        
        [TestCase(0, LangCode)]
        [TestCase(120, null)]
        [TestCase(120, "")]
        [TestCase(120, " ")]
        public async Task GetAsync_Should_NotCacheReceivedFilters_When_CacheTtlIsNotPositiveOrLanguageCodeIsNullOrWhiteSpace(int cacheTtl, string langCode)
        {
            // Arrange
            memoryCache.TryGetValue(LangCode, out Arg.Any<Filters>()).Returns(false);
            filtersService.GetAsync(langCode, Url, AuthInfo).Returns(filters);

            // Act
            await cachingFiltersService.GetAsync(langCode, Url, AuthInfo, cacheTtl);

            // Assert
            await filtersService.ReceivedWithAnyArgs().GetAsync(default, default, default);
            memoryCache.DidNotReceiveWithAnyArgs().CreateEntry(default);
        }
        
        [Test]
        public async Task GetAsync_Should_CacheReceivedFilters_When_CacheTtlIsPositiveAndLanguageCodeIsNotNullOrWhiteSpace()
        {
            // Arrange
            const int cacheTtl = 60;
            
            memoryCache.TryGetValue(LangCode, out Arg.Any<Filters>()).Returns(false);
            filtersService.GetAsync(LangCode, Url, AuthInfo).Returns(filters);
            
            var actualCacheEntry = Substitute.For<ICacheEntry>();
                
            memoryCache.CreateEntry(Arg.Any<object>()).Returns(actualCacheEntry);

            TimeSpan expectedCacheExpiration = TimeSpan.FromSeconds(cacheTtl);

            // Act
            await cachingFiltersService.GetAsync(LangCode, Url, AuthInfo, cacheTtl);

            // Assert
            memoryCache.Received().CreateEntry(LangCode);
            using (new AssertionScope())
            {
                actualCacheEntry.Value.Should().BeEquivalentTo(filters);
                actualCacheEntry.AbsoluteExpirationRelativeToNow.Should().Be(expectedCacheExpiration);
            }
        }
         
        #endregion
        
        #region GetAsync (without caching)

        [Test]
        public async Task GetAsync_Should_NotUseCache_When_CacheTtlIsNotSpecified()
        {
            // Act
            await cachingFiltersService.GetAsync(LangCode, Url, AuthInfo);

            // Assert
            await filtersService.Received().GetAsync(LangCode, Url, AuthInfo);
            memoryCache.DidNotReceiveWithAnyArgs().TryGetValue(default, out Arg.Any<Filters>());
            memoryCache.DidNotReceiveWithAnyArgs().CreateEntry(default);
        }
        
        #endregion
    }
}