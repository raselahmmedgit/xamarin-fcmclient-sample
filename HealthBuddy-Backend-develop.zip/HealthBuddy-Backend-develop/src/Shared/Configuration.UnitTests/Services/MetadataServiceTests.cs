// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Application.Core.Options;
using Epam.CovidResistance.Shared.Configuration.Interfaces;
using Epam.CovidResistance.Shared.Configuration.Services;
using FluentAssertions;
using Microsoft.Extensions.Options;
using NSubstitute;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Configuration.UnitTests.Services
{
    public class MetadataServiceTests
    {
        #region Test_Setup
        
        private const string LangCode = "en";
        private const string Url = "https://foo.bar";
        private const string AuthInfo = "Basic <token>";
        private const int CacheTtlSeconds = 120;

        private IOptions<Statuses> statusesOptions;
        private IFeatureService featureService;
        private ICachingFiltersService cachingFiltersService;
        private MetadataService metadataService;

        [SetUp]
        public void Setup()
        {
            statusesOptions = Substitute.For<IOptions<Statuses>>();
            statusesOptions.Value.Returns(new Statuses
            {
                Values = new[] { new Status { Id = 1, Name = "Status" } },
                Default = 1,
                OnExposure = 2 
            });
            
            featureService = Substitute.For<IFeatureService>();
            cachingFiltersService = Substitute.For<ICachingFiltersService>();

            metadataService = new MetadataService(statusesOptions, featureService, cachingFiltersService);
        }

        #endregion

        #region GetAsync
        
        [Test]
        public async Task GetAsync_Should_ReturnAggregatedMetadata()
        {
            // Arrange
            var expectedFeatures = new Dictionary<string, string>
            {
                ["Feature1"] = "enabled",
                ["Feature2"] = "disabled"
            };
            featureService.GetFeaturesAsync().Returns(expectedFeatures);

            var expectedFilters = new Filters
            {
                Items = new[]
                {
                    new Filter
                    {
                        DisplayName = "Filter",
                        ParameterName = "Parameter",
                        IsMultiSelect = false
                    } 
                }
            };
            
            cachingFiltersService
                .GetAsync(default, default, default, default)
                .ReturnsForAnyArgs(expectedFilters);

            var expectedMetadata = new Metadata
            {
                Statuses = statusesOptions.Value,
                Features = expectedFeatures,
                Filters = expectedFilters.Items
            };

            // Act
            Metadata actualMetadata = await metadataService.GetAsync(LangCode, Url, AuthInfo, CacheTtlSeconds);

            // Assert
            actualMetadata.Should().BeEquivalentTo(expectedMetadata);
            await featureService.Received().GetFeaturesAsync();
            await cachingFiltersService.Received().GetAsync(LangCode, Url, AuthInfo, CacheTtlSeconds);
        }
        
        #endregion
    }
}