// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Options;
using Epam.CovidResistance.Shared.Configuration.Interfaces;
using Epam.CovidResistance.Shared.Configuration.Services;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using NUnit.Framework;
using System;
using System.Threading.Tasks;

namespace Configuration.UnitTests.Services
{
    public class FiltersServiceTests
    {
        #region Test_Setup
        
        private const string LangCode = "en";
        private const string Url = "https://foo.bar";
        private const string AuthInfo = "Basic <token>";

        private IOptions<Filters> filtersOptions;
        private Filters filtersFromOptions;
        private IFiltersService filtersService;
        private IFiltersHttpRepository filtersHttpRepository;

        [SetUp]
        public void Setup()
        {
            var logger = Substitute.For<ILogger<FiltersService>>();
            
            filtersOptions = Substitute.For<IOptions<Filters>>();
            filtersFromOptions = new Filters
            {
                Items = new[]
                {
                    new Filter
                    {
                        DisplayName = "FilterFromOptions",
                        ParameterName = "ParameterFromOptions",
                        IsMultiSelect = true,
                        Values = new[]
                        {
                            new FilterValue
                            {
                                DisplayName = "FilterValueFromOptions",
                                ParameterName = "ParameterFromOptions",
                                IsDefault = true
                            }
                        }
                    } 
                }
            };
            filtersOptions.Value.Returns(filtersFromOptions);
            
            filtersHttpRepository = Substitute.For<IFiltersHttpRepository>();

            filtersService = new FiltersService(filtersOptions, logger, filtersHttpRepository);
        }

        #endregion

        #region GetAsync
        
        [Test]
        public async Task GetAsync_Should_ReturnFiltersFromOptions_When_ExceptionIsThrownWhileUsingRepository()
        {
            // Arrange
            filtersHttpRepository.GetAsync(default, default).ThrowsForAnyArgs(new Exception());

            // Act
            Filters actualFilters = await filtersService.GetAsync(LangCode, Url, AuthInfo);

            // Assert
            actualFilters.Should().BeEquivalentTo(filtersFromOptions);
            await filtersHttpRepository.ReceivedWithAnyArgs().GetAsync(default, default);
        }

        [Test]
        public async Task GetAsync_Should_ReturnFiltersFromCmsResponseAdjustedWithOptionsValues()
        {
            // Arrange
            var cmsFilters = new[]
            {
                new Filter
                {
                    DisplayName = filtersOptions.Value.Items[0].DisplayName,
                    ParameterName = filtersOptions.Value.Items[0].ParameterName,
                    IsMultiSelect = false, // should be ignored and taken from filters from options
                    Values = new[]
                    {
                        new FilterValue
                        {
                            DisplayName = filtersOptions.Value.Items[0].Values[0].DisplayName,
                            ParameterName = filtersOptions.Value.Items[0].Values[0].ParameterName,
                            IsDefault = false // should be ignored and taken from filter values from options
                        }
                    }
                },
                new Filter
                {
                    DisplayName = "FilterFromCms",
                    ParameterName = "ParameterFromCms",
                    IsMultiSelect = true, // should be false as parameter does not exist in filters from options
                    Values = new[]
                    {
                        new FilterValue
                        {
                            DisplayName = "FilterValueFromCms",
                            ParameterName = "ParameterFromCms",
                            IsDefault = true // should be false as parameter does not exist in filters from options
                        }
                    }
                }
            };

            filtersHttpRepository.GetAsync(default, default).ReturnsForAnyArgs(cmsFilters);

            var expectedFilters = new Filters
            {
                Items = new[]
                {
                    new Filter
                    {
                        DisplayName = cmsFilters[0].DisplayName,
                        ParameterName = cmsFilters[0].ParameterName,
                        IsMultiSelect = filtersOptions.Value.Items[0].IsMultiSelect, // should be ignored and taken from filters from options
                        Values = new[]
                        {
                            new FilterValue
                            {
                                DisplayName = cmsFilters[0].Values[0].DisplayName,
                                ParameterName = cmsFilters[0].Values[0].ParameterName,
                                IsDefault = filtersOptions.Value.Items[0].Values[0].IsDefault // should be ignored and taken from filter values from options
                            }
                        }
                    },
                    new Filter
                    {
                        DisplayName = cmsFilters[1].DisplayName,
                        ParameterName = cmsFilters[1].ParameterName,
                        IsMultiSelect = false, // should be false as does not exist in filters from options
                        Values = new[]
                        {
                            new FilterValue
                            {
                                DisplayName = cmsFilters[1].Values[0].DisplayName,
                                ParameterName = cmsFilters[1].Values[0].ParameterName,
                                IsDefault = false // should be false as does not exist in filters from options
                            }
                        }
                    }
                }
            };

            // Act
            Filters actualFilters = await filtersService.GetAsync(LangCode, Url, AuthInfo);

            // Assert
            actualFilters.Should().BeEquivalentTo(expectedFilters);
            await filtersHttpRepository.Received().GetAsync(Url, AuthInfo);
        }
        
        #endregion
    }
}