﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

//using Cassandra.Data.Linq;
//using Epam.CovidResistance.Shared.Application.Core.Entities;
//using Epam.CovidResistance.Shared.Application.Core.Interfaces;
//using Epam.CovidResistance.Shared.Domain.Model;
//using Microsoft.Extensions.DependencyInjection;
//using NUnit.Framework;
//using System;

//namespace Epam.CovidResistance.Shared.Infrastructure.Persistence.IntegrationTests
//{
    //DO NOT CREATE CONTACT TRACING RELATED TABLES
    //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
    //[TestFixture]
    //public class MedicalCodeRepositoryTests : TestsBase
    //{
    //    [Test]
    //    public void MarkAsAccepted_Valid_ChangeAcceptAtDate()
    //    {
    //        var medicalCodeValue = "ABC123";
    //        var infectedStatusId = 1;
    //        var repository = ServiceProvider.GetService<IMedicalCodeRepository>();
    //        var changeRequest = new StatusChangeRequest(infectedStatusId, new DateTime(2020, 4, 1), "Comment");

    //        Assert.That(repository.TryCreate(medicalCodeValue, changeRequest, "medicalUserToken"),
    //            Is.True,
    //            "Creating a new code is successful");

    //        repository.MarkAsAccepted(medicalCodeValue);

    //        // verify that AcceptedAt is set
    //        MedicalCode medicalCode = new Table<MedicalCode>(CassandraSession.Session)
    //            .FirstOrDefault(row => row.Value == medicalCodeValue)
    //            .Execute();

    //        Assert.That(medicalCode.AcceptedAt, Is.Not.Null);
    //    }

    //    [Test]
    //    public void TryCreate_MultipleTimes_SaveOnlySingle()
    //    {
    //        var medicalCodeValue = "XYZ123";
    //        var infectedStatusId = 1;
    //        var repository = ServiceProvider.GetService<IMedicalCodeRepository>();
    //        var changeRequest = new StatusChangeRequest(infectedStatusId, new DateTime(2020, 4, 1), "Comment");

    //        var firstRequestSuccessful = repository.TryCreate(medicalCodeValue, changeRequest, "medicalUserToken");
    //        Assert.That(firstRequestSuccessful, Is.True);

    //        var secondRequestSuccessful = repository.TryCreate(medicalCodeValue, changeRequest, "otherDoctor");
    //        Assert.That(secondRequestSuccessful, Is.False);

    //        MedicalCode medicalCode = new Table<MedicalCode>(CassandraSession.Session)
    //            .FirstOrDefault(row => row.Value == medicalCodeValue)
    //            .Execute();

    //        Assert.That(medicalCode, Is.Not.Null);
    //        Assert.That(medicalCode.AcceptedAt, Is.Null);
    //        Assert.That(medicalCode.Comment, Is.EqualTo(changeRequest.Comment));
    //        Assert.That(medicalCode.CreatedAt, Is.Not.Null);
    //        Assert.That(medicalCode.RequestedBy, Is.EqualTo("medicalUserToken"));
    //        Assert.That(medicalCode.StatusId, Is.EqualTo(changeRequest.StatusId));
    //        Assert.That(medicalCode.StatusChangedOn, Is.EqualTo(changeRequest.StatusChangedOn));
    //    }
    //}
//}