﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Domain.Model;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using System;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Shared.Infrastructure.Persistence.IntegrationTests
{
    [TestFixture]
    public class UserRepositoryTests : TestsBase
    {
        [Test]
        public async Task TestPushNotifications()
        {
            // Arrange
            var repository = ServiceProvider.GetService<IUserRepository>();

            var pushNotification = new UserPushNotification
            {
                UserId = "userTokenForPushNotification",
                NotificationToken = "pushToken",
                NotificationTarget = "pushTarget"
            };

            // Act
            await repository.SetPushNotificationAsync(pushNotification);
            UserPushNotification missingPushNotification = await repository.GetPushNotificationAsync("missing");
            UserPushNotification actualPushNotification = await repository.GetPushNotificationAsync(pushNotification.UserId);

            // Assert
            using (new AssertionScope())
            {
                missingPushNotification.Should().BeNull();
                actualPushNotification.NotificationToken.Should().Be(pushNotification.NotificationToken);
                actualPushNotification.NotificationTarget.Should().Be(pushNotification.NotificationTarget);
            }
        }

        [Test]
        public async Task TestRegistration()
        {
            // Arrange
            var repository = ServiceProvider.GetService<IUserRepository>();
            var userInfo = new UserInfo(
                userId: "registrationToken1",
                userName: "joe",
                statusId: 1,
                statusChangedOn: new DateTime(2020, 4, 1)
            );

            // Act
            await repository.RegisterUserAsync(userInfo);
            UserInfo registeredUserInfo = await repository.GetUserInfoAsync(userInfo.UserId);

            // Assert
            registeredUserInfo.Should().BeEquivalentTo(userInfo);

            //DO NOT CREATE CONTACT TRACING RELATED TABLES
            //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
            //UserStatusHistory userStatusHistory = new Table<UserStatusHistory>(CassandraSession.Session)
            //    .FirstOrDefault(row => row.UserId == userInfo.UserId && row.StatusChangedOn == userInfo.StatusChangedOn)
            //    .Execute();

            //Assert.That(userStatusHistory, Is.Not.Null);
            //Assert.That(userStatusHistory.StatusId, Is.EqualTo(userInfo.StatusId));
            //Assert.That(userStatusHistory.StatusChangedOn, Is.EqualTo(userInfo.StatusChangedOn));
        }

        [Test]
        public async Task TestUserInfo()
        {
            // Arrange
            var repository = ServiceProvider.GetService<IUserRepository>();
            var user = new UserInfo("userInfoToken1", "userInfoName1", 1, new DateTime(2020, 4, 1));

            // Act
            await repository.RegisterUserAsync(user);
            UserInfo registeredUserInfo = await repository.GetUserInfoAsync(user.UserId);
            UserInfo missingUserInfo = await repository.GetUserInfoAsync("missingToken");

            // Assert
            using (new AssertionScope())
            {
                registeredUserInfo.Should().BeEquivalentTo(user);
                missingUserInfo.Should().BeNull();
            }
        }

        [Test]
        public async Task TestUserStatus()
        {
            // Arrange
            var repository = ServiceProvider.GetService<IUserRepository>();
            
            var userInfo = new UserInfo(
                userId: "registrationToken1",
                userName: "joe",
                statusId: 1,
                statusChangedOn: new DateTime(2020, 4, 1)
            );
            
            var userStatus = new UserStatus
            {
                UserId = userInfo.UserId,
                StatusId = 2,
                StatusChangedOn = new DateTime(2020, 4, 4)
            };

            // Act
            await repository.RegisterUserAsync(userInfo);
            await repository.SetUserStatusAsync(userStatus);

            UserInfo newUserInfo = await repository.GetUserInfoAsync(userInfo.UserId);

            // Assert
            using (new AssertionScope())
            {
                newUserInfo.Should().NotBeEquivalentTo(userInfo);
                newUserInfo.StatusId.Should().Be(userStatus.StatusId);
                newUserInfo.StatusChangedOn.Should().Be(userStatus.StatusChangedOn);
            }

            //DO NOT CREATE CONTACT TRACING RELATED TABLES
            //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
            //UserStatusHistory userStatusHistory = new Table<UserStatusHistory>(CassandraSession.Session)
            //    .FirstOrDefault(row => row.UserId == userStatus.UserId && row.StatusChangedOn == userStatus.StatusChangedOn)
            //    .Execute();

            //Assert.That(userStatusHistory, Is.Not.Null);
            //Assert.That(userStatusHistory.StatusId, Is.EqualTo(userStatus.StatusId));
            //Assert.That(userStatusHistory.StatusChangedOn, Is.EqualTo(userStatus.StatusChangedOn));
        }
    }
}