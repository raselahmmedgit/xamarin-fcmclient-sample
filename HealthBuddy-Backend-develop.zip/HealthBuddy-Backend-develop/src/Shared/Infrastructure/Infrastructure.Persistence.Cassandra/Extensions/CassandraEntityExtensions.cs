﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Entities;

namespace Epam.CovidResistance.Shared.Infrastructure.Persistence.Cassandra.Extensions
{
    /// <summary>
    /// Extension methods for <see cref="Application.Core.Entities"/> allowing to represent null properties in Cassandra
    /// and return nulls instead of value absence indicators when retrieving data from database. 
    /// Using value absence indicators is required for filtering by null, as Cassandra support for nulls is limited.
    /// </summary>
    public static class CassandraEntityExtensions
    {
        public static T ResolveNulls<T>(this T settings) where T : IUserNotificationSettings
        {
            settings.NotificationLanguage = EmptyIfNull(settings.NotificationLanguage);
            settings.NotificationToken = EmptyIfNull(settings.NotificationToken);
            settings.NotificationTarget = EmptyIfNull(settings.NotificationTarget);
            
            return settings;
        }

        public static T ResolveAbsenceIndicators<T>(this T settings) where T : IUserNotificationSettings
        {
            settings.NotificationLanguage = NullIfEmpty(settings.NotificationLanguage);
            settings.NotificationToken = NullIfEmpty(settings.NotificationToken);
            settings.NotificationTarget = NullIfEmpty(settings.NotificationTarget);

            return settings;
        }

        private static string EmptyIfNull(string value)
            => string.IsNullOrWhiteSpace(value)
                   ? string.Empty
                   : value;

        private static string NullIfEmpty(string value)
            => value == string.Empty
                ? null
                : value;
    }
}