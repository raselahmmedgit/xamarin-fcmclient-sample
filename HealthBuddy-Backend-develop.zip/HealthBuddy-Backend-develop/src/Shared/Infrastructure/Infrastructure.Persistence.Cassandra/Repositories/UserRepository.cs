﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Cassandra;
using Cassandra.Data.Linq;
using Cassandra.Mapping;
using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Domain.Model;
using Epam.CovidResistance.Shared.Infrastructure.Persistence.Cassandra.Extensions;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Shared.Infrastructure.Persistence.Cassandra.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly Mapper mapper;
        private readonly ISession session;

        public UserRepository(ICassandraSession session)
        {
            this.session = session.Session;
            mapper = new Mapper(this.session);
        }

        public Task RegisterUserAsync(UserInfo userInfo)
        {
            var user = new User
            {
                UserId = userInfo.UserId,
                UserName = userInfo.UserName,
                StatusId = userInfo.StatusId,
                StatusChangedOn = userInfo.StatusChangedOn,
            };
            return mapper.InsertAsync(user.ResolveNulls());

            //DO NOT CREATE CONTACT TRACING RELATED TABLES
            //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
            //var userStatusHistory = new UserStatusHistory
            //{
            //    UserId = userInfo.UserId,
            //    StatusChangedOn = userInfo.StatusChangedOn,
            //    StatusId = userInfo.StatusId
            //};
            //mapper.Insert(userStatusHistory);
        }

        public Task RegisterUsersAsync(IEnumerable<UserInfo> usersInfo)
        {
            var users = usersInfo.Select(x => new User
                {
                    UserId = x.UserId,
                    UserName = x.UserName,
                    StatusId = x.StatusId,
                    StatusChangedOn = x.StatusChangedOn
                });

            var batch = mapper.CreateBatch(BatchType.Unlogged);

            foreach (var registeredUser in users)
                batch.Insert(registeredUser);

            return mapper.ExecuteAsync(batch);
        }

        public Task SetUserStatusAsync(UserStatus userStatus)
        {
            return mapper.InsertAsync(userStatus);

            //DO NOT CREATE CONTACT TRACING RELATED TABLES
            //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
            //var statusHistory = new UserStatusHistory
            //{
            //    UserId = userStatus.UserId,
            //    StatusChangedOn = userStatus.StatusChangedOn,
            //    StatusId = userStatus.StatusId
            //};
            //mapper.Insert(statusHistory);
        }

        public Task SetPushNotificationAsync(UserPushNotification pushNotification)
            => mapper.InsertAsync(pushNotification.ResolveNulls());

        public async Task<UserPushNotification> GetPushNotificationAsync(string userId)
        {
            var notification = await new Table<UserPushNotification>(session)
                .FirstOrDefault(token => token.UserId == userId)
                .ExecuteAsync();
            
            return notification.ResolveAbsenceIndicators();
        }

        public async Task<IEnumerable<UserPushNotification>> ListPushNotificationsAsync()
        {
            IEnumerable<UserPushNotification> allNotifications = await new Table<UserPushNotification>(session)
                .Where(x => x.NotificationToken.CompareTo(string.Empty) > 0)
                .AllowFiltering()
                .ExecuteAsync();

            return allNotifications.Select(x => x.ResolveAbsenceIndicators());
        }

        public async Task<User> GetUserAsync(string userId)
        {
            var user = await new Table<User>(session)
                .FirstOrDefault(u => u.UserId == userId)
                .ExecuteAsync();

            return user.ResolveAbsenceIndicators();
        }

        public async Task<UserInfo> GetUserInfoAsync(string userId)
        {
            User user = await GetUserAsync(userId);

            return user == null
                       ? null
                       : new UserInfo(
                           userId: user.UserId,
                           userName: user.UserName,
                           statusId: user.StatusId,
                           statusChangedOn: user.StatusChangedOn
                       );
        }

        public Task DeleteUserAsync(string userId)
            => new Table<User>(session)
                .Where(x => x.UserId == userId)
                .Delete()
                .ExecuteAsync();

        public Task ClearNotificationTokenAsync(string userId)
            => mapper.InsertAsync(new UserPushNotification { UserId = userId }.ResolveNulls());

        //DO NOT CREATE CONTACT TRACING RELATED TABLES
        //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
        //public async Task DeleteUserStatusHistoryAsync(string userId)
        //{
        //    await new Table<UserStatusHistory>(session)
        //        .Where(x => x.UserId == userId)
        //        .Delete()
        //        .ExecuteAsync();
        //}
    }
}