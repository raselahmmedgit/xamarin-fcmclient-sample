﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Cassandra;
using Cassandra.Data.Linq;
using Cassandra.Mapping;
using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Domain.Model;
using System;

namespace Epam.CovidResistance.Shared.Infrastructure.Persistence.Cassandra.Repositories
{
    public class MedicalCodeRepository : IMedicalCodeRepository
    {
        private readonly Mapper mapper;
        private readonly ISession session;

        public MedicalCodeRepository(ICassandraSession session)
        {
            this.session = session.Session;
            mapper = new Mapper(this.session);
        }

        public bool TryCreate(string medicalCodeValue, StatusChangeRequest statusChangeRequest, string medicalUserId)
        {
            var medicalCode = new MedicalCode
            {
                Value = medicalCodeValue,
                StatusId = statusChangeRequest.StatusId,
                StatusChangedOn = statusChangeRequest.StatusChangedOn,
                Comment = statusChangeRequest.Comment,
                CreatedAt = DateTime.UtcNow,
                RequestedBy = medicalUserId
            };

            return mapper.InsertIfNotExists(medicalCode).Applied;
        }

        public void MarkAsAccepted(string medicalCodeValue)
        {
            // CosmosDB doesn't support this Lightweight Transaction
            //return new Table<MedicalCodeAccepted>(session)
            //    .Where(row => row.Value == medicalCodeValue)
            //    .Select(row => new MedicalCodeAccepted { AcceptedAt = DateTime.UtcNow })
            //    .UpdateIf(row => row.AcceptedAt == null)
            //    .Execute()
            //    .Applied;

            new Table<MedicalCodeAccepted>(session)
                .Where(row => row.Value == medicalCodeValue)
                .Select(row => new MedicalCodeAccepted { AcceptedAt = DateTime.UtcNow })
                .Update()
                .Execute();
        }

        public MedicalCode GetByValue(string medicalCodeValue)
        {
            return new Table<MedicalCode>(session)
                .FirstOrDefault(row => row.Value == medicalCodeValue)
                .Execute();
        }
    }
}