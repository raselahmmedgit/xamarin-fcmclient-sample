// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Cassandra;
using Cassandra.Data.Linq;
using Cassandra.Mapping;
using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Infrastructure.Persistence.Cassandra.Entities;
using Microsoft.Extensions.Options;
using System;
using System.Linq;
using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;

namespace Epam.CovidResistance.Shared.Infrastructure.Persistence.Cassandra
{
    public interface ICassandraCluster : IDisposable
    {
        Cluster Cluster { get; }
    }

    public class CassandraCluster : ICassandraCluster
    {
        static CassandraCluster()
        {
            MappingConfiguration.Global.Define<UserMappings>();
            //DO NOT CREATE CONTACT TRACING RELATED TABLES
            //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
            //MappingConfiguration.Global.Define<UserStatusHistoryMappings>();
            //MappingConfiguration.Global.Define<MedicalCodeMappings>();
            //MappingConfiguration.Global.Define<MedicalRegistrationMappings>();
        }

        public CassandraCluster(IOptions<CassandraOptions> options)
        {
            CassandraOptions config = options.Value;
            Builder clusterBuilder = Cluster.Builder()
                .AddContactPoints(config.ContactPoints)
                .WithDefaultKeyspace(config.Keyspace);

            if (config.Credentials != null)
            {
                clusterBuilder.WithCredentials(config.Credentials.UserName, config.Credentials.Password);
            }

            if (config.Port.HasValue)
            {
                clusterBuilder.WithPort(config.Port.Value);
            }

            if (config.Ssl != null && Enum.TryParse(config.Ssl.Protocol, out SslProtocols sslProtocol))
            {
                var checkCertificationRevocation =
                    config.Ssl.CheckCertificateRevocation.GetValueOrDefault();
                var sslOptions = new SSLOptions(sslProtocol, checkCertificationRevocation, ValidateServerCertificate);
                sslOptions.SetHostNameResolver(ipAddress => config.ContactPoints.FirstOrDefault());
                clusterBuilder.WithSSL(sslOptions);
            }

            clusterBuilder.WithRetryPolicy(new CustomCassandraRetryPolicy(
                config.RetryPolicy?.ReadAttempts,
                config.RetryPolicy?.WriteAttempts,
                config.RetryPolicy?.UnavailableAttempts,
                config.RetryPolicy?.RequestErrorAttempts));

            Cluster = clusterBuilder.Build();
            CreateTablesIfNeeded();
        }

        public Cluster Cluster { get; }

        public void Dispose()
        {
            Cluster?.Dispose();
        }

        private void CreateTablesIfNeeded()
        {
            using ISession session = Cluster.ConnectAndCreateDefaultKeyspaceIfNotExists();
            new Table<User>(session).CreateIfNotExists();
            //DO NOT CREATE CONTACT TRACING RELATED TABLES
            //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
            //new Table<UserStatusHistory>(session).CreateIfNotExists();
            //new Table<MedicalCode>(session).CreateIfNotExists();
            //new Table<MedicalRegistration>(session).CreateIfNotExists();
        }

        private static bool ValidateServerCertificate(
            object sender,
            X509Certificate certificate,
            X509Chain chain,
            SslPolicyErrors sslPolicyErrors)
        {
            if (sslPolicyErrors == SslPolicyErrors.None)
            {
                return true;
            }

            Console.WriteLine("Certificate error: {0}", sslPolicyErrors);

            // Do not allow this client to communicate with unauthenticated servers.
            return false;
        }
    }
}