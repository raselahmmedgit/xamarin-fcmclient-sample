# Cassandra Persistence Layer

## Cassandra Basics

### Data Modeling

Cassandra is a NoSQL Column Storage that offers linear scalability and high availability.
Its primary query language is CQL (almost standard Ansi SQL).

Looks like a relational [table](https://portal.azure.com/#@dev4unigvagmail.onmicrosoft.com/resource/subscriptions/973ea665-13d5-485a-87f1-72b28fffa950/resourceGroups/rg-euw-dev1-hbcovid-01/providers/Microsoft.DocumentDB/databaseAccounts/cassandra-euw-dev1-hbcovid-01/dataExplorer).

Key design elements:
* Partition Key: The field(s) the data is partitioned by. Mandatory.
* Clustering Key: The field(s) the data is sorted by (within partition). Optional.

Primary key = Partition key + Clustering Key
* Ensures uniqueness

Example:
```sql
CREATE TABLE movies (
  id int,
  name text,
  runtime int,
  year int,
  PRIMARY KEY (year, name)
);
```
* Partition key: `year`
* Clustering key: `name`

![Cassandra keys](img/keys.png)

[Cassandra keys video (34 min)](https://www.youtube.com/watch?v=L0XqRF8C6D0)

### Features and Limitations

Designed with performance in mind:
* Filtering (WHERE) only by keys and secondary indexes.
* Always need to filter by partition key
* Ordering only by clustering key
* Inserts and Updates are identical (no read before write)
* Only Lightweight Transactions (on the same partition)

## Implementation details

### Csharp Driver

ORM framework, [lightweight object mapper](https://docs.datastax.com/en/developer/csharp-driver/3.15/features/components/mapper/).
* [Simple entity classes (POCO)](../Infrastructure.Persistence/Entities)
* [Mapper classes](Entities)

Entity classes have no reference to Cassandra.

### Tips and Tricks

* **More entities are mapped to the same table:** [User](../Infrastructure.Persistence/Entities/User.cs) and [UserMappings](Entities/UserMappings.cs).
* **Lightweight transactions:** [MedicalCodeRepository](Repositories/MedicalCodeRepository.cs)
* **Lightweigth transaction not supported by CosmosDB:** [MedicalRegistration.TryRegistration](Repositories/MedicalRegistrationRepository.cs) - commented out

### Project structure

* [CassandraOptions](CassandraOptions.cs) - configuration
* [CassandraCluster](CassandraCluster.cs) - connection & table creation
    * configuration in constructor
    * mapping configuration in static constructor
    * create tables if needed
* [CassandraSession](CassandraSession.cs) - open session
* [Repositories](Repositories) - mapping and ORM
* [Integration Tests](../Infrastructure.Persistence.IntegrationTests)
* [Cassandra sandbox](../../../../sandbox/cassandra) - dockerized environment, not 100% compatible
