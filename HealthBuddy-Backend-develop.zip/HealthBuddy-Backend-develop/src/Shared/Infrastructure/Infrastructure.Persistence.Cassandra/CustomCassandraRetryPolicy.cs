﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Cassandra;
using System;

namespace Epam.CovidResistance.Shared.Infrastructure.Persistence.Cassandra
{
    /// <summary>
    /// Retry strategy that provides ability to set a maximal number of retry attempts.
    /// </summary>
    /// <remarks>
    /// Mimics behavior of <see cref="DefaultRetryPolicy"/>.
    /// See its implementation for better understanding of retry magic.
    /// </remarks>
    public class CustomCassandraRetryPolicy : IExtendedRetryPolicy
    {
        private readonly int readAttempts;
        private readonly int writeAttempts;
        private readonly int unavailableAttempts;
        private readonly int requestErrorAttempts;

        /// <summary>
        /// Creates a new instance of <see cref="CustomCassandraRetryPolicy"/>
        /// </summary>
        /// <param name="readAttempts">Maximal number of attempts of retrying requests failed with read timeout</param>
        /// <param name="writeAttempts">Maximal number of attempts of retrying requests failed with write timeout</param>
        /// <param name="unavailableAttempts">Maximal number of attempts of retrying requests failed with unavailable exception</param>
        /// <param name="requestErrorAttempts">Maximal number of attempts of retrying requests which received response with an error code</param>
        public CustomCassandraRetryPolicy(
            int? readAttempts = 1, 
            int? writeAttempts = 1,
            int? unavailableAttempts = 1,
            int? requestErrorAttempts = 1)
        {
            this.readAttempts = readAttempts ?? 1;
            this.writeAttempts = writeAttempts ?? 1;
            this.unavailableAttempts = unavailableAttempts ?? 1;
            this.requestErrorAttempts = requestErrorAttempts ?? 1;
        }

        public RetryDecision OnReadTimeout(IStatement query, ConsistencyLevel cl, int requiredResponses, int receivedResponses, bool dataRetrieved, int nbRetry)
        {
            if (nbRetry >= readAttempts)
            {
                return RetryDecision.Rethrow();
            }

            return receivedResponses >= requiredResponses && !dataRetrieved 
                ? RetryDecision.Retry(cl)
                : RetryDecision.Rethrow();
        }

        public RetryDecision OnUnavailable(IStatement query, ConsistencyLevel cl, int requiredReplica, int aliveReplica, int nbRetry)
            => nbRetry < unavailableAttempts
                ? RetryDecision.Retry(ConsistencyLevel.One)
                : RetryDecision.Rethrow();

        public RetryDecision OnWriteTimeout(IStatement query, ConsistencyLevel cl, string writeType, int requiredAcks, int receivedAcks, int nbRetry)
        {
            if (nbRetry >= writeAttempts)
            {
                return RetryDecision.Rethrow();
            }

            // If the batch log write failed, retry the operation as this might just be we were unlucky at picking candidates
            return writeType == "BATCH_LOG" ? RetryDecision.Retry(cl) : RetryDecision.Rethrow();
        }
        
        public RetryDecision OnRequestError(
            IStatement statement,
            Configuration config,
            Exception ex,
            int nbRetry)
        {
            if (nbRetry >= requestErrorAttempts
                || ex is OperationTimedOutException && !config.QueryOptions.RetryOnTimeout)
            {
                return RetryDecision.Rethrow();
            }
            
            return RetryDecision.Retry(null, false);
        }
    }
}