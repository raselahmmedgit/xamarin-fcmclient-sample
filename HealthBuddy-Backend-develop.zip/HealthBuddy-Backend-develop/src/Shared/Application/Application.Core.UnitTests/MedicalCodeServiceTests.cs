// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core;
using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Application.Core.Response;
using FluentAssertions;
using Microsoft.Extensions.Options;
using NSubstitute;
using NUnit.Framework;
using System;
using MedicalCodeOptions = Epam.CovidResistance.Shared.Application.Core.Options.MedicalCode;

namespace Application.Core.UnitTests
{
    public class MedicalCodeServiceTests
    {
        #region Accept
        
        [Test]
        public void Accept_Should_MarkMedicalCodeAsAccepted()
        {
            // Arrange
            const string medicalCodeValue = "ABC123";
            const int infectedStatusId = 1;
            var changeOnDate = new DateTime(2020, 4, 1);

            var medicalCodeRepository = Substitute.For<IMedicalCodeRepository>();
            medicalCodeRepository.GetByValue(medicalCodeValue)
                .Returns(new MedicalCode
                {
                    Value = medicalCodeValue,
                    StatusId = infectedStatusId,
                    StatusChangedOn = changeOnDate,
                    CreatedAt = changeOnDate.AddDays(1)
                });

            var options = Substitute.For<IOptions<MedicalCodeOptions>>();
            options.Value.Returns(new MedicalCodeOptions
                { ExpirationHours = 24 });

            var dateTime = Substitute.For<IDateTimeService>();

            dateTime.UtcNow.Returns(changeOnDate.AddDays(1.5));

            var service = new MedicalCodeService(medicalCodeRepository, options, dateTime);

            AcceptMedicalCodeResponse expectedResult = AcceptMedicalCodeResponse.Success(infectedStatusId, changeOnDate);

            // Act
            AcceptMedicalCodeResponse result = service.Accept(medicalCodeValue);

            // Assert
            medicalCodeRepository.Received(1).MarkAsAccepted(medicalCodeValue);
            result.Should().BeEquivalentTo(expectedResult, because: "accepting should succeed");
        }

        [Test]
        public void Accept_Should_ReturnError_When_CodeIsExpired()
        {
            // Arrange
            const string medicalCodeValue = "ABC123";
            const int infectedStatusId = 1;
            var changeOnDate = new DateTime(2020, 4, 1);

            var medicalCodeRepository = Substitute.For<IMedicalCodeRepository>();
            medicalCodeRepository.GetByValue(medicalCodeValue)
                .Returns(new MedicalCode
                {
                    Value = medicalCodeValue,
                    StatusId = infectedStatusId,
                    StatusChangedOn = changeOnDate,
                    CreatedAt = changeOnDate.AddDays(1)
                });

            var options = Substitute.For<IOptions<MedicalCodeOptions>>();
            options.Value.Returns(new MedicalCodeOptions
                { ExpirationHours = 0 });

            var dateTime = Substitute.For<IDateTimeService>();

            dateTime.UtcNow.Returns(changeOnDate.AddDays(1.5));

            var service = new MedicalCodeService(medicalCodeRepository, options, dateTime);

            AcceptMedicalCodeResponse expectedResult = AcceptMedicalCodeResponse.Error(AcceptChangeResult.ExpiredCode);

            // Act
            AcceptMedicalCodeResponse result = service.Accept(medicalCodeValue);

            // Assert
            medicalCodeRepository.DidNotReceive().MarkAsAccepted(medicalCodeValue);
            result.Should().BeEquivalentTo(expectedResult, because: "accepting after expiration should fail");
        }

        [Test]
        public void Accept_Should_ReturnError_When_MedicalCodeIsMissing()
        {
            // Arrange
            const string medicalCodeValue = "ABC123";

            var changeOnDate = new DateTime(2020, 4, 1);

            var medicalCodeRepository = Substitute.For<IMedicalCodeRepository>();
            medicalCodeRepository.GetByValue(medicalCodeValue).Returns((MedicalCode) null);

            var options = Substitute.For<IOptions<MedicalCodeOptions>>();
            options.Value.Returns(new MedicalCodeOptions
                { ExpirationHours = 24 });

            var dateTime = Substitute.For<IDateTimeService>();

            dateTime.UtcNow.Returns(changeOnDate.AddDays(1.5));

            var service = new MedicalCodeService(medicalCodeRepository, options, dateTime);
            
            AcceptMedicalCodeResponse expectedResult = AcceptMedicalCodeResponse.Error(AcceptChangeResult.MissingCode);

            // Act
            AcceptMedicalCodeResponse result = service.Accept(medicalCodeValue);

            // Assert
            medicalCodeRepository.DidNotReceive().MarkAsAccepted(medicalCodeValue);
            result.Should().BeEquivalentTo(expectedResult, because: "accepting with missing code should fail");
        }
        
        #endregion
    }
}