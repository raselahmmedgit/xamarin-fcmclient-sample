﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Constants;
using System;
using System.Linq;

namespace Epam.CovidResistance.Shared.Application.Core.Options
{
    public class Filters
    {
        public Filter[] Items { get; set; }

        public void SetDefaultLanguage(string languageCode)
        {
            Filter languageFilter = Items.FirstOrDefault(i => i.ParameterName == FilterNames.LanguageFilterName);
            
            if (languageFilter == null)
            {
                return;
            }

            languageFilter.Values = languageFilter.Values.Select(i => new FilterValue
                                    {
                                        IsDefault = string.Equals(i.ParameterName, languageCode, 
                                                                            StringComparison.OrdinalIgnoreCase),
                                        DisplayName = i.DisplayName,
                                        ParameterName = i.ParameterName
                                    }).ToArray();
        }
    }

    public class Filter
    {
        public string DisplayName { get; set; }

        public string ParameterName { get; set; }

        public bool IsMultiSelect { get; set; }

        public FilterValue[] Values { get; set; }
    }

    public class FilterValue
    {
        public string DisplayName { get; set; }

        public string ParameterName { get; set; }

        public bool IsDefault { get; set; }
    }
}