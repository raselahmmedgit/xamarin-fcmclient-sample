﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Application.Core.Response;
using Microsoft.Extensions.Options;
using MedicalCodeOptions = Epam.CovidResistance.Shared.Application.Core.Options.MedicalCode;

namespace Epam.CovidResistance.Shared.Application.Core
{
    public class MedicalCodeService : IMedicalCodeService
    {
        private readonly IDateTimeService dateTimeService;
        private readonly int expirationHours;
        private readonly IMedicalCodeRepository medicalCodeRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="MedicalCodeService"></see> class.
        /// </summary>
        public MedicalCodeService(IMedicalCodeRepository medicalCodeRepository,
            IOptions<MedicalCodeOptions> options,
            IDateTimeService dateTimeService)
        {
            this.medicalCodeRepository = medicalCodeRepository;
            expirationHours = options.Value.ExpirationHours;
            this.dateTimeService = dateTimeService;
        }

        public AcceptMedicalCodeResponse Accept(string medicalCodeValue)
        {
            MedicalCode medicalCode = medicalCodeRepository.GetByValue(medicalCodeValue);
            MedicalCodeValidationResult validationResult = Validate(medicalCode).Result;

            switch (validationResult)
            {
                case MedicalCodeValidationResult.ExpiredCode:
                    return AcceptMedicalCodeResponse.Error(AcceptChangeResult.ExpiredCode);
                case MedicalCodeValidationResult.ReusedCode:
                    return AcceptMedicalCodeResponse.Error(AcceptChangeResult.ReusedCode);
                case MedicalCodeValidationResult.MissingCode:
                    return AcceptMedicalCodeResponse.Error(AcceptChangeResult.MissingCode);
            }

            medicalCodeRepository.MarkAsAccepted(medicalCodeValue);

            return AcceptMedicalCodeResponse.Success(medicalCode.StatusId, medicalCode.StatusChangedOn);
        }

        public ValidateMedicalCodeResponse Validate(string medicalCodeValue)
        {
            MedicalCode medicalCode = medicalCodeRepository.GetByValue(medicalCodeValue);

            return Validate(medicalCode);
        }

        private ValidateMedicalCodeResponse Validate(MedicalCode medicalCode)
        {
            if (medicalCode == null)
            {
                return ValidateMedicalCodeResponse.Error(MedicalCodeValidationResult.MissingCode);
            }

            if (medicalCode.AcceptedAt != null)
            {
                return ValidateMedicalCodeResponse.Error(MedicalCodeValidationResult.ReusedCode);
            }

            if (medicalCode.CreatedAt.AddHours(expirationHours) < dateTimeService.UtcNow)
            {
                return ValidateMedicalCodeResponse.Error(MedicalCodeValidationResult.ExpiredCode);
            }

            return ValidateMedicalCodeResponse.Success();
        }
    }
}