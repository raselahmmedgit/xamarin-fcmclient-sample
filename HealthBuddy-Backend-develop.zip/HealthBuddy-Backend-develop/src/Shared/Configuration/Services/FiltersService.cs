﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Options;
using Epam.CovidResistance.Shared.Configuration.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Shared.Configuration.Services
{
    public class FiltersService : IFiltersService
    {
        private readonly ILogger<FiltersService> logger;
        private readonly Dictionary<string, Filter> filtersConfig;
        private readonly IFiltersHttpRepository filtersHttpRepository;

        public FiltersService(IOptions<Filters> filtersOptions, ILogger<FiltersService> logger, IFiltersHttpRepository filtersHttpRepository)
        {
            filtersConfig = filtersOptions.Value.Items.ToDictionary(f => f.ParameterName);
            this.logger = logger;
            this.filtersHttpRepository = filtersHttpRepository;
        }

        public async Task<Filters> GetAsync(string languageCode, string url, string authInfo)
        {
            Filter[] cmsItems;
            try
            {
                cmsItems = await filtersHttpRepository.GetAsync(url, authInfo);
            }
            catch (Exception exception)
            {
                logger.LogError($"CMS communication error: {exception}");
                return new Filters
                {
                    Items = filtersConfig.Values.ToArray()
                }; 
            }

            return BuildFilters(languageCode, cmsItems);
        }

        private Filters BuildFilters(string languageCode, IEnumerable<Filter> cmsItems)
        {
            var filters = new Filters
            {
                Items = cmsItems
                    .Select(f => new Filter
                    {
                        DisplayName = f.DisplayName,
                        ParameterName = f.ParameterName,
                        IsMultiSelect = filtersConfig.TryGetValue(f.ParameterName, out Filter filterFromConfig)
                            && filterFromConfig.IsMultiSelect,
                        Values = BuildFiltersValues(
                            f.Values,
                            filterFromConfig is null ? Array.Empty<FilterValue>() : filterFromConfig.Values)
                    }).ToArray()
            };

            filters.SetDefaultLanguage(languageCode);
            return filters;
        }

        private static FilterValue[] BuildFiltersValues(IEnumerable<FilterValue> filterValues, IEnumerable<FilterValue> filterConfigValues)
        {
            Dictionary<string, FilterValue> valuesDictionary = filterConfigValues.ToDictionary(x => x.ParameterName);
            FilterValue[] newValues = filterValues
                .Select(v => new FilterValue
                {
                    DisplayName = v.DisplayName,
                    IsDefault = valuesDictionary.TryGetValue(v.ParameterName, out FilterValue filterValueFromConfig)
                        && filterValueFromConfig.IsDefault,
                    ParameterName = v.ParameterName
                }).ToArray();
            
            return newValues;
        }
    }
}
