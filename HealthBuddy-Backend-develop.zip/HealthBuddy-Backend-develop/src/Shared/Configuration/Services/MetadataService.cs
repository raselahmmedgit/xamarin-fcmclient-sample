﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Application.Core.Options;
using Epam.CovidResistance.Shared.Configuration.Interfaces;
using Microsoft.Extensions.Options;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Shared.Configuration.Services
{
    public class MetadataService : IMetadataService
    {
        private readonly IFeatureService featureService;
        private readonly Statuses statuses;
        private readonly ICachingFiltersService cachingFiltersService;

        /// <summary>
        /// Initializes a new instance of the <see cref="MetadataService"></see> class.
        /// </summary>
        public MetadataService(IOptions<Statuses> statusesOptions,
            IFeatureService featureService,
            ICachingFiltersService cachingFiltersService)
        {
            this.featureService = featureService;
            statuses = statusesOptions.Value;
            this.cachingFiltersService = cachingFiltersService;
        }

        public async Task<Metadata> GetAsync(string languageCode, string cmsUrl, string authInfo, int filtersCacheTtl)
        {
            Dictionary<string, string> features = await featureService.GetFeaturesAsync();
            Filters filters = await cachingFiltersService.GetAsync(languageCode, cmsUrl, authInfo, filtersCacheTtl);

            var metadata = new Metadata
            {
                Statuses = statuses,
                Features = features,
                Filters = filters.Items
            };

            return metadata;
        }
    }
}