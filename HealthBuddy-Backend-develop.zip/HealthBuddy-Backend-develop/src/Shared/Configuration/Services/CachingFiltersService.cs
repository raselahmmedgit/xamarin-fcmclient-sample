﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Options;
using Epam.CovidResistance.Shared.Configuration.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Shared.Configuration.Services
{
    public class CachingFiltersService : ICachingFiltersService
    {
        private readonly IFiltersService decoratedFiltersService;
        private readonly IMemoryCache cache;

        public CachingFiltersService(IFiltersService decoratedFiltersService, IMemoryCache cache)
        {
            this.decoratedFiltersService = decoratedFiltersService;
            this.cache = cache;
        }
        
        public async Task<Filters> GetAsync(string languageCode, string url, string authInfo, int cacheTtlSeconds)
        {
            Filters filters = null;
            if (!string.IsNullOrEmpty(languageCode))
            {
                filters = cache.Get<Filters>(languageCode);
            }

            if (filters != null)
            {
                return filters;
            }

            filters = await decoratedFiltersService.GetAsync(languageCode, url, authInfo);
            if (cacheTtlSeconds > 0 && !string.IsNullOrWhiteSpace(languageCode))
            {
                MemoryCacheEntryOptions memoryCacheEntryOptions = 
                    new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromSeconds(cacheTtlSeconds));
                cache.Set(languageCode, filters, memoryCacheEntryOptions);
            }

            return filters;
        }

        public async Task<Filters> GetAsync(string languageCode, string url, string authInfo)
            => await decoratedFiltersService.GetAsync(languageCode, url, authInfo);
    }
}
