﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Domain.Model.Errors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Shared.API.Common
{
    /// <summary>
    /// Global exception handler for wrapping uncaught exceptions into <see cref="Result"/> objects.
    /// </summary>
    public class ExceptionHandler : IExceptionHandler
    {
        private readonly ILogger<ExceptionHandler> logger;
        
        /// <summary>
        /// Initializes a new instance of the <see cref="ExceptionHandler"></see> class.
        /// </summary>
        public ExceptionHandler(ILogger<ExceptionHandler> logger)
        {
            this.logger = logger;
        }
        
        public async Task HandleAsync(HttpContext context)
        {
            var exceptionHandlerPathFeature = context.Features.Get<IExceptionHandlerPathFeature>();
            Exception exception = exceptionHandlerPathFeature.Error;
            
            logger.LogError(exception, "An unexpected exception has occurred.");
            
            var response = new Error(
                StatusCodes.Status500InternalServerError.ToString(),
                new [] { new InnerError(ErrorTarget.InternalServerError, "An unexpected exception has occurred.") });
            var responseJson = JsonConvert.SerializeObject(response);

            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsync(responseJson);
        }
    }
}