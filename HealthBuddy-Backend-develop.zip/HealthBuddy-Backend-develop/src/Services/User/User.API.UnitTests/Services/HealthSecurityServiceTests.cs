// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Services;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NUnit.Framework;
using System;

namespace Epam.CovidResistance.Services.User.API.UnitTests.Services
{
    public class HealthSecurityServiceTests
    {
        #region Test_Setup
        
        private IMedicalRegistrationRepository repository;
        private ILogger<HealthSecurityService> logger;
        private HealthSecurityService service;

        [SetUp]
        public void Setup()
        {
            repository = Substitute.For<IMedicalRegistrationRepository>();
            logger = Substitute.For<ILogger<HealthSecurityService>>();
            service = new HealthSecurityService(repository, logger);
        }
        
        #endregion
        
        #region GenerateSecurityIds

        [TestCase(0)]
        [TestCase(5)]
        [TestCase(50)]
        public void GenerateSecurityIds_Should_GenerateSpecifiedNumberOfIds(int expectedNumberOfSecurityIds)
        {
            // Arrange
            repository
                .TryCreateSecurityId(default, default)
                .ReturnsForAnyArgs(true);
            
            const int codeLength = 8;
            const string comment = "comment";

            // Act
            string[] result = service.GenerateSecurityIds(expectedNumberOfSecurityIds, codeLength, comment);

            // Assert
            result.Should().HaveCount(expectedNumberOfSecurityIds);
            logger.DidNotReceiveWithAnyArgs().LogError("", default);
        }

        [TestCase(0)]
        [TestCase(5)]
        [TestCase(50)]
        public void GenerateSecurityIds_Should_GenerateIdsWithSpecifiedNumberOfCharacters(int expectedCodeLength)
        {
            // Arrange
            repository
                .TryCreateSecurityId(default, default)
                .ReturnsForAnyArgs(true);
            
            const int numberOfSecurityIds = 3;
            const string comment = "comment";
            
            // Act
            string[] result = service.GenerateSecurityIds(numberOfSecurityIds, expectedCodeLength, comment);

            // Assert
            result.Should().OnlyContain(x => x.Length == expectedCodeLength);
            logger.DidNotReceiveWithAnyArgs().LogError("", default);
        }

        [Test]
        public void GenerateSecurityIds_Should_GenerateNewSecurityId_When_GeneratedIdAlreadyExists()
        {
            // Arrange
            repository
                .TryCreateSecurityId(default, default)
                .ReturnsForAnyArgs(false, false, true);
            
            const int numberOfSecurityIds = 1;
            const int codeLength = 8;
            const string comment = "comment";

            // Act
            string[] result = service.GenerateSecurityIds(numberOfSecurityIds, codeLength, comment);

            // Assert
            using (new AssertionScope())
            {
                result.Should().ContainSingle(x => x.Length == codeLength);
                result.Should().ContainSingle();
            }
            
            logger.DidNotReceiveWithAnyArgs().LogError("", default);
            repository.ReceivedWithAnyArgs(3).TryCreateSecurityId(default, default);
        }

        [Test]
        public void GenerateSecurityIds_Should_ThrowApplicationException_When_ExceedsAllTrials()
        {
            // Arrange
            repository
                .TryCreateSecurityId(default, default)
                .ReturnsForAnyArgs(false);

            // Act
            Action act = () => service.GenerateSecurityIds(1, 8, "comment");

            // Assert
            act.Should().Throw<ApplicationException>();
            logger.ReceivedWithAnyArgs().LogError("", default);
        }
        
        #endregion
    }
}