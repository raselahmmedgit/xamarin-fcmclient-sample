// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Services;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Application.Core.Options;
using Epam.CovidResistance.Shared.Domain.Model;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.UnitTests.Services
{
    public class UserServiceTests
    {
        #region Test_Setup
        
        private IOptions<Statuses> statusesOptions;
        private Statuses statuses;
        private IUserRepository repository;
        private ILogger<UserService> logger;
        private DateTime dateTimeNow;
        private IDateTimeService dateTimeService;
        private UserService service;

        [SetUp]
        public void Setup()
        {
            statuses = new Statuses { Default = 1, OnExposure = 2, Values = Array.Empty<Status>() };
            statusesOptions = Substitute.For<IOptions<Statuses>>();
            statusesOptions.Value.Returns(statuses);
            repository = Substitute.For<IUserRepository>();
            logger = Substitute.For<ILogger<UserService>>();

            dateTimeNow = new DateTime(2020, 6, 30);
            dateTimeService = Substitute.For<IDateTimeService>();

            service = new UserService(repository, statusesOptions, logger, dateTimeService);
        }
        
        #endregion
        
        #region RegisterUserAsync

        [Test]
        public async Task RegisterUserAsync_Should_RegisterUserWithDefaultStatus()
        {
            // Arrange
            dateTimeService.UtcNow.Returns(dateTimeNow);

            // Act
            await service.RegisterUserAsync("userId", "userName");

            // Assert
            await repository.Received()
                .RegisterUserAsync(new UserInfo("userId", "userName", 1, dateTimeNow));
        }
        
        #endregion
        
        #region GetUserInformationAsync

        [Test]
        public async Task GetUserInformationAsync_Should_ReturnUserInfo()
        {
            // Arrange
            statusesOptions.Value.Returns(statuses);
            dateTimeService.UtcNow.Returns(dateTimeNow);

            // Act
            await service.GetUserInformationAsync("userId");

            // Assert
            await repository.Received().GetUserInfoAsync("userId");
        }
        
        #endregion
        
        #region DeleteUserInformationAsync

        [Test]
        public async Task DeleteUserInformationAsync_Should_DeleteUser()
        {
            // Arrange
            statusesOptions.Value.Returns(statuses);
            dateTimeService.UtcNow.Returns(dateTimeNow);

            // Act
            await service.DeleteUserInformationAsync("userId");

            // Assert
            await repository.Received().DeleteUserAsync("userId");
        }
        
        #endregion

        //DO NOT CREATE CONTACT TRACING RELATED TABLES
        //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
        //[Test]
        //public async Task DeleteUserInformation_Valid_DeletesUserStatusHistory()
        //{
        //    statusesOptions.Value.Returns(statuses);
        //    dateTimeService.UtcNow.Returns(dateTimeNow);

        //    await service.DeleteUserInformationAsync("userId");

        //    await repository.Received().DeleteUserStatusHistoryAsync("userId");
        //}
    }
}