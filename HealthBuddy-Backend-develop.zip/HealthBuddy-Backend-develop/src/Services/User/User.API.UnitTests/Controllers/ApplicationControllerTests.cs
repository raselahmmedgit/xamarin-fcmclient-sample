﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Controllers;
using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Application.Core.Options;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Routing;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.UnitTests.Controllers
{
    public class ApplicationControllerTests
    {
        #region Test_Setup
        
        private IMetadataService service;
        private Metadata metadata;
        private ApplicationController controller;

        [SetUp]
        public void Setup()
        {
            service = Substitute.For<IMetadataService>();
            metadata = new Metadata
            {
                Features = new Dictionary<string, string>(),
                Filters = Array.Empty<Filter>(),
                Statuses = new Statuses
                {
                    Default = 1,
                    OnExposure = 2,
                    Values = Array.Empty<Status>()
                }
            };
            
            var httpContext = Substitute.For<HttpContext>();
            var headerDictionary = Substitute.For<IHeaderDictionary>();
            var routeData = Substitute.For<RouteData>();
            var controllerActionDescriptor = Substitute.For<ControllerActionDescriptor>();

            httpContext.Request.Headers.Returns(headerDictionary);
            var actionContext = new ActionContext()
            {
                HttpContext = httpContext,
                RouteData = routeData,
                ActionDescriptor = controllerActionDescriptor
            };
            var controllerContext = new ControllerContext(actionContext);

            controller = new ApplicationController(service)
            {
                ControllerContext = controllerContext
            };
        }

        #endregion

        #region GetMetadata

        [Test]
        public async Task GetMetadata_Should_ReturnOkObjectResult()
        {
            // Arrange
            service.GetAsync("someLangCode", "someUrl", "someAuthInfo", 30).Returns(Task.FromResult(metadata));

            // Act
            IActionResult result = await controller.GetMetadata();

            // Assert
            result.Should().BeOfType<OkObjectResult>();
        }
        
        #endregion
    }
}