﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

//using Epam.CovidResistance.Services.User.API.Controllers;
//using Epam.CovidResistance.Services.User.API.Interfaces;
//using Epam.CovidResistance.Services.User.API.Models;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using NSubstitute;
//using NSubstitute.ExceptionExtensions;
//using NUnit.Framework;
//using System;

//namespace Epam.CovidResistance.Services.User.API.UnitTests.Controllers
//{
    //DO NOT CREATE CONTACT TRACING RELATED TABLES
    //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
    //public class AdminControllerTests
    //{
    //    private IHealthSecurityService service;
    //    private AdminController controller;

    //    [SetUp]
    //    public void Setup()
    //    {
    //        service = Substitute.For<IHealthSecurityService>();
    //        controller = new AdminController(service);
    //    }

    //    [Test]
    //    public void GenerateHealthSecurityIds_ValidRequest_ReturnsOkObjectResult()
    //    {
    //        var expectedCodes = new[] { "code1", "code2", "code3" };
    //        service
    //            .GenerateSecurityIds(3, 5, "someComment")
    //            .Returns(expectedCodes);

    //        var healthSecurityRequest = new HealthSecurityRequest
    //        {
    //            CodeLength = 5,
    //            Comment = "someComment",
    //            NumberOfCodes = 3
    //        };

    //        IActionResult result = controller.GenerateHealthSecurityIds(healthSecurityRequest);

    //        Assert.IsInstanceOf<OkObjectResult>(result);
    //    }

    //    [Test]
    //    public void GenerateHealthSecurityIds_ValidRequest_ContentIsHealthSecurityResponse()
    //    {
    //        var expectedCodes = new[] { "code1", "code2", "code3" };
    //        service
    //            .GenerateSecurityIds(3, 5, "someComment")
    //            .Returns(expectedCodes);

    //        var healthSecurityRequest = new HealthSecurityRequest
    //        {
    //            CodeLength = 5,
    //            Comment = "someComment",
    //            NumberOfCodes = 3
    //        };

    //        IActionResult result = controller.GenerateHealthSecurityIds(healthSecurityRequest);

    //        object response = (result as OkObjectResult)?.Value;

    //        Assert.IsInstanceOf<HealthSecurityResponse>(response);
    //    }

    //    [Test]
    //    public void GenerateHealthSecurityIds_ValidRequest_ReturnsCorrectCodes()
    //    {
    //        var expectedCodes = new[] { "code1", "code2", "code3" };
    //        service
    //            .GenerateSecurityIds(3, 5, "someComment")
    //            .Returns(expectedCodes);

    //        var healthSecurityRequest = new HealthSecurityRequest
    //        {
    //            CodeLength = 5,
    //            Comment = "someComment",
    //            NumberOfCodes = 3
    //        };

    //        IActionResult result = controller.GenerateHealthSecurityIds(healthSecurityRequest);

    //        object response = (result as OkObjectResult)?.Value;
    //        string[] generatedCodes = (response as HealthSecurityResponse)?.HealthSecurityIds;
    //        CollectionAssert.AreEquivalent(expectedCodes, generatedCodes);
    //    }

    //    [Test]
    //    public void GenerateHealthSecurityIds_InvalidRequest_ReturnsBadRequestObjectResult()
    //    {
    //        controller.ModelState.TryAddModelError("modelError", "Request model is null");
    //        IActionResult result = controller.GenerateHealthSecurityIds(null);

    //        Assert.Multiple(() =>
    //        {
    //            Assert.IsInstanceOf<BadRequestObjectResult>(result);
    //            service.DidNotReceiveWithAnyArgs().GenerateSecurityIds(default, default, "someComment");
    //        });
    //    }

    //    [Test]
    //    public void GenerateHealthSecurityIds_HealthSecurityServiceThrows_ReturnsInternalServerErrorObjectResult()
    //    {
    //        service.GenerateSecurityIds(3, 0, "someComment").Throws(new ApplicationException());

    //        var healthSecurityRequest = new HealthSecurityRequest
    //        {
    //            CodeLength = 0,
    //            Comment = "someComment",
    //            NumberOfCodes = 3
    //        };

    //        IActionResult result = controller.GenerateHealthSecurityIds(healthSecurityRequest);

    //        Assert.AreEqual(StatusCodes.Status500InternalServerError, (result as ObjectResult)?.StatusCode);
    //    }
    //}
//}