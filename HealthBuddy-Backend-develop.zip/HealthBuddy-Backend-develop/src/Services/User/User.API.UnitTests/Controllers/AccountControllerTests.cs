﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Controllers;
using Epam.CovidResistance.Services.User.API.Interfaces;
using Epam.CovidResistance.Services.User.API.Models;
using Epam.CovidResistance.Services.User.Application.Common.Interfaces;
using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Domain.Model.Errors;
using Epam.CovidResistance.Shared.Test.Common.Builders;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using NUnit.Framework;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.UnitTests.Controllers
{
    public class AccountControllerTests
    {
        #region Test_Setup
        
        private const string UserId = "userId";
        private const string HealthSecurityId = "healthSecurityId";

        private IIdentityService identityService;
        private IUserService userService;
        private ILogger<AccountController> logger;
        private AccountController controller;

        [SetUp]
        public void Setup()
        {
            identityService = Substitute.For<IIdentityService>();
            userService = Substitute.For<IUserService>();
            logger = Substitute.For<ILogger<AccountController>>();
            controller = new AccountController(identityService, userService, logger);
        }
        
        #endregion
        
        #region AddToRole
        
        [Test]
        public async Task AddToRole_Should_ReturnOkObjectResult_When_RequestIsValid()
        {
            // Arrange
            identityService
                .AddToMedicalRoleAsync(default, default)
                .ReturnsForAnyArgs(Task.FromResult(Result.Success()));
            var validMedicalNominationRequest = new MedicalNominationRequest
            {
                HealthSecurityId = HealthSecurityId
            };
            controller.ControllerContext = new ControllerContextBuilder().WithUser(UserId).Build();

            // Act
            IActionResult result = await controller.AddToRole(validMedicalNominationRequest);

            // Assert
            result.Should().BeOfType<OkResult>();
        }

        [Test]
        public async Task AddToRole_Should_AddMedicalRoleToUser_When_RequestIsValid()
        {
            // Arrange
            identityService
                .AddToMedicalRoleAsync(default, default)
                .ReturnsForAnyArgs(Task.FromResult(Result.Success()));
            var validMedicalNominationRequest = new MedicalNominationRequest
            {
                HealthSecurityId = HealthSecurityId
            };
            controller.ControllerContext = new ControllerContextBuilder().WithUser(UserId).Build();

            // Act
            await controller.AddToRole(validMedicalNominationRequest);

            // Assert
            await identityService.Received().AddToMedicalRoleAsync(UserId, HealthSecurityId);
        }
        
        #endregion
        
        #region Delete

        [Test]
        public async Task Delete_Should_ReturnNoContentObjectResult_When_UserDataIsSuccessfullyDeleted()
        {
            // Arrange
            identityService.DeleteUserIdentityAsync(UserId).Returns(Task.FromResult(Result.Success()));
            userService.DeleteUserInformationAsync(UserId).Returns(Task.FromResult(Result.Success()));

            controller.ControllerContext = new ControllerContextBuilder().WithUser(UserId).Build();

            // Act
            IActionResult result = await controller.Delete();

            // Assert
            result.Should().BeOfType<NoContentResult>();
        }

        [Test]
        public async Task Delete_Should_DeleteUserAndUserInformation()
        {
            // Arrange
            identityService.DeleteUserIdentityAsync(UserId).Returns(Task.FromResult(Result.Success()));
            userService.DeleteUserInformationAsync(UserId).Returns(Task.FromResult(Result.Success()));

            controller.ControllerContext = new ControllerContextBuilder().WithUser(UserId).Build();

            // Act
            await controller.Delete();

            // Assert
            await userService.Received().DeleteUserInformationAsync(UserId);
        }

        [Test]
        public async Task Delete_Should_DeleteUser()
        {
            // Arrange
            identityService.DeleteUserIdentityAsync(UserId).Returns(Task.FromResult(Result.Success()));
            userService.DeleteUserInformationAsync(UserId).Returns(Task.FromResult(Result.Success()));

            controller.ControllerContext = new ControllerContextBuilder().WithUser(UserId).Build();

            // Act
            await controller.Delete();

            // Assert
            await identityService.Received().DeleteUserIdentityAsync(UserId);
        }

        [Test]
        public async Task Delete_Should_ReturnInternalServerError_When_FailsToDeleteUserInformation()
        {
            // Arrange
            userService.DeleteUserInformationAsync(UserId).ThrowsForAnyArgs(new Exception());

            controller.ControllerContext = new ControllerContextBuilder().WithUser(UserId).Build();

            // Act
            IActionResult result = await controller.Delete();
            int? resultStatusCode = (result as ObjectResult)?.StatusCode;

            // Assert
            resultStatusCode.Should().Be(StatusCodes.Status500InternalServerError);
            await identityService.DidNotReceive().DeleteUserIdentityAsync(UserId);
        }

        [Test]
        public async Task Delete_Should_ReturnInternalServerError_When_FailsToDeleteUser()
        {
            // Arrange
            identityService.DeleteUserIdentityAsync(UserId).Returns(Result.Failure(Enumerable.Empty<InnerError>()));
            userService.DeleteUserInformationAsync(UserId).Returns(Task.CompletedTask);

            controller.ControllerContext = new ControllerContextBuilder().WithUser(UserId).Build();

            // Act
            IActionResult result = await controller.Delete();
            int? resultStatusCode = (result as ObjectResult)?.StatusCode;

            // Assert
            resultStatusCode.Should().Be(StatusCodes.Status500InternalServerError);
            await userService.Received().DeleteUserInformationAsync(UserId);
            await identityService.Received().DeleteUserIdentityAsync(UserId);
        }
        
        #endregion
    }
}