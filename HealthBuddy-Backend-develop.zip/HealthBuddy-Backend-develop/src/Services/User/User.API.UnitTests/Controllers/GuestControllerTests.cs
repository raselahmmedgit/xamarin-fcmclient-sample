﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Controllers;
using Epam.CovidResistance.Services.User.API.Interfaces;
using Epam.CovidResistance.Services.User.API.Models;
using Epam.CovidResistance.Services.User.Application.Common.Interfaces;
using Epam.CovidResistance.Services.User.Application.Common.Models;
using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Domain.Model.Errors;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NUnit.Framework;
using System.Threading;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.UnitTests.Controllers
{
    public class GuestControllerTests
    {
        #region Test_Setup
        
        private const string Username = "username";
        private const string Password = "password";
        private const string UserId = "userId";

        private IIdentityService identityService;
        private IUserService userService;
        private ILogger<GuestController> logger;
        private GuestController controller;

        [SetUp]
        public void Setup()
        {
            identityService = Substitute.For<IIdentityService>();
            userService = Substitute.For<IUserService>();
            logger = Substitute.For<ILogger<GuestController>>();
            controller = new GuestController(identityService, userService, logger);
        }
        
        #endregion
        
        #region Register

        [Test]
        public async Task Register_Should_ReturnOkObjectResult_When_RequestIsValid()
        {
            // Arrange
            identityService
                .CreateUserIdentityAsync(default, default)
                .ReturnsForAnyArgs(Task.FromResult((Result.Success(), userId: UserId)));

            identityService
                .PostRegisterLoginAsync(default, default, default)
                .ReturnsForAnyArgs(Task.FromResult((Result.Success(), new Token(default, default, default))));

            var validRegisterRequestModel = new RegisterRequest
            {
                Username = Username,
                Password = Password
            };

            // Act
            IActionResult result = await controller.Register(validRegisterRequestModel, new CancellationToken());
            object resultValue = (result as OkObjectResult)?.Value;

            // Assert
            using (new AssertionScope())
            {
                result.Should().BeOfType<OkObjectResult>();
                resultValue.Should().BeOfType<Token>();
            }
        }

        [Test]
        public async Task Register_Should_CreateUser_When_RequestIsValid()
        {
            // Arrange
            RegisterRequest registerRequest = ArrangeValidRequestForRegisterMethod();

            var cancellationToken = new CancellationToken();

            // Act
            await controller.Register(registerRequest, cancellationToken);

            // Assert
            await identityService.Received().CreateUserIdentityAsync(Username, Password);
        }

        [Test]
        public async Task Register_Should_RegisterUser_When_RequestIsValid()
        {
            // Arrange
            RegisterRequest registerRequest = ArrangeValidRequestForRegisterMethod();

            var cancellationToken = new CancellationToken();

            // Act
            await controller.Register(registerRequest, cancellationToken);

            // Assert
            await userService.Received().RegisterUserAsync(UserId, Username);
        }

        [Test]
        public async Task Register_Should_LoginUser_When_RequestIsValid()
        {
            // Arrange
            RegisterRequest registerRequest = ArrangeValidRequestForRegisterMethod();

            var cancellationToken = new CancellationToken();

            // Act
            await controller.Register(registerRequest, cancellationToken);

            // Assert
            await identityService.Received().PostRegisterLoginAsync(Username, Password, cancellationToken);
        }

        [Test]
        public async Task Register_Should_ReturnBadRequestObjectResult_When_RequestIsInvalid()
        {
            // Arrange
            var invalidRegisterRequestModel = new RegisterRequest
            {
                Username = Username
            };

            controller.ModelState.AddModelError("TestError", "TestError");

            // Act
            IActionResult result = await controller.Register(invalidRegisterRequestModel, default);
            object resultValue = (result as BadRequestObjectResult)?.Value;

            // Assert
            using (new AssertionScope())
            {
                result.Should().BeOfType<BadRequestObjectResult>();
                resultValue.Should().BeOfType<Error>();
            }
        }

        private RegisterRequest ArrangeValidRequestForRegisterMethod()
        {
            identityService
                .CreateUserIdentityAsync(default, default)
                .ReturnsForAnyArgs(Task.FromResult((Result.Success(), userId: UserId)));

            identityService
                .PostRegisterLoginAsync(default, default, default)
                .ReturnsForAnyArgs(Task.FromResult((Result.Success(), new Token(default, default, default))));

            var registerRequest = new RegisterRequest
            {
                Username = Username,
                Password = Password
            };

            return registerRequest;
        }
        
        #endregion
    }
}