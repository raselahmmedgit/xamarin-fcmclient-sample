﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Controllers;
using Epam.CovidResistance.Services.User.API.Interfaces;
using Epam.CovidResistance.Services.User.API.Models;
using Epam.CovidResistance.Services.User.Application.Common.Interfaces;
using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Domain.Model;
using Epam.CovidResistance.Shared.Domain.Model.Errors;
using Epam.CovidResistance.Shared.IdentityDbContext.Identity;
using Epam.CovidResistance.Shared.Test.Common.Builders;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.UnitTests.Controllers
{
    public class UserControllerTests
    {
        #region Test_Setup
        
        private IUserService userService;
        private IIdentityService identityService;
        private ILogger<UserController> logger;
        private UserController controller;

        [SetUp]
        public void Setup()
        {
            userService = Substitute.For<IUserService>();
            identityService = Substitute.For<IIdentityService>();
            logger = Substitute.For<ILogger<UserController>>();
            controller = new UserController(userService, identityService, logger)
            {
                ControllerContext = new ControllerContextBuilder().WithUser("userId").Build()
            };
        }

        #endregion
        
        #region GetProfile
        
        [Test]
        public async Task GetProfile_Should_ReturnOkObjectResultWithProfileResponseValue()
        {
            // Arrange
            var userInfo = new UserInfo("userId", "userName",
                1, new DateTime(2020, 1, 13));
            (Result, UserInfo) userResult = (Result.Success(), userInfo);
            userService.GetUserInformationAsync("userId")
                .Returns(userResult);

            (Result, string[]) rolesResult = (Result.Success(), new[] { Roles.User.ToString() });
            identityService.GetUserRolesAsync("userId")
                .Returns(Task.FromResult(rolesResult));

            // Act
            IActionResult result = await controller.GetProfile();
            object resultValue = (result as OkObjectResult)?.Value;

            // Assert
            using (new AssertionScope())
            {
                result.Should().BeOfType<OkObjectResult>();
                resultValue.Should().BeOfType<ProfileResponse>();
            }
        }

        [Test]
        public async Task GetProfile_Should_ReturnInternalServerErrorResult_When_IdentityServiceThrows()
        {
            // Arrange
            var userInfo = new UserInfo("userId", "userName",
                1, new DateTime(2020, 1, 13));
            (Result, UserInfo) userResult = (Result.Success(), userInfo);
            userService.GetUserInformationAsync("userId")
                .Returns(userResult);

            (Result, string[]) rolesResult = (Result.Failure(new InnerError("target", "message")), null);
            identityService.GetUserRolesAsync("userId").Returns(Task.FromResult(rolesResult));

            // Act
            IActionResult result = await controller.GetProfile();
            int? resultStatusCode = (result as ObjectResult)?.StatusCode;

            // Assert
            resultStatusCode.Should().Be(StatusCodes.Status500InternalServerError);
        }
        
        #endregion
    }
}