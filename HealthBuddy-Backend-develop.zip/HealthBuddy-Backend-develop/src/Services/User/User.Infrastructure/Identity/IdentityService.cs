﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.Application.Common.Interfaces;
using Epam.CovidResistance.Services.User.Application.Common.Models;
using Epam.CovidResistance.Services.User.Infrastructure.Extensions;
using Epam.CovidResistance.Services.User.Infrastructure.Models;
using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Domain.Model.Errors;
using Epam.CovidResistance.Shared.IdentityDbContext.Identity;
using Epam.CovidResistance.Shared.IdentityDbContext.Persistence;
using IdentityModel.Client;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.Infrastructure.Identity
{
    public class IdentityService : IIdentityService
    {
        private readonly ClientIdentityOptions clientIdentity;
        private readonly HttpClient httpClient;
        private readonly IDiscoveryCache discoveryCache;
        private readonly ILogger<IdentityService> logger;
        private readonly ApplicationDbContext applicationDbContext;
        private readonly IPasswordHasher<ApplicationUser> passwordHasher;

        //DO NOT CREATE CONTACT TRACING RELATED TABLES
        //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
        //private readonly IMedicalRegistrationRepository medicalRegistrationRepository;
        private readonly UserManager<ApplicationUser> userManager;

        /// <summary>
        /// Initializes a new instance of the <see cref="IdentityService"></see> class.
        /// </summary>
        public IdentityService(
            AspNetUserManager<ApplicationUser> userManager,
            IHttpClientFactory clientFactory,
            //DO NOT CREATE CONTACT TRACING RELATED TABLES
            //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
            //IMedicalRegistrationRepository medicalRegistrationRepository,
            IOptions<ClientIdentityOptions> clientIdentityOptions,
            IDiscoveryCache discoveryCache,
            ILogger<IdentityService> logger,
            ApplicationDbContext applicationDbContext,
            IPasswordHasher<ApplicationUser> passwordHasher)
        {
            this.userManager = userManager;
            //DO NOT CREATE CONTACT TRACING RELATED TABLES
            //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
            //this.medicalRegistrationRepository = medicalRegistrationRepository;
            this.logger = logger;
            this.applicationDbContext = applicationDbContext;
            this.passwordHasher = passwordHasher;
            httpClient = clientFactory.CreateClient();
            this.discoveryCache = discoveryCache;
            clientIdentity = clientIdentityOptions.Value;
        }

        public async Task<(Result Result, string UserId)> CreateUserIdentityAsync(
            string userName,
            string password)
        {
            logger.LogInformation("Start creating {userName} user identity.", userName);
            var user = new ApplicationUser
            {
                UserName = userName
            };

            IdentityResult identityResult = await userManager.CreateAsync(user, password);

            if (!identityResult.Succeeded)
            {
                Result result = identityResult.ToApplicationResult();

                logger.LogError("Error creating user identity for {userName} with userId {userId}. Errors: {@message}", userName, user.Id, result.Errors);

                return (result, user.Id);
            }

            logger.LogInformation("Successfully created {userName} user identity with userId {userId}. Start to assign user roles.", userName, user.Id);

            var userRoleName = Roles.User.ToString("G");

            identityResult = await userManager.AddToRoleAsync(user, userRoleName);

            if (!identityResult.Succeeded)
            {
                Result result = identityResult.ToApplicationResult();

                logger.LogError("Failed to assign role {userRoleName} for user with userId {userId}. Errors: {@message}",
                    userRoleName,
                    user.Id,
                    result.Errors);

                return (result, user.Id);
            }

            logger.LogInformation("Successfully assigned role {userRoleName} for {userName} user with userId {userId}.",
                userRoleName,
                userName,
                user.Id);

            return (Result.Success(), user.Id);
        }

        public async Task<(Result Result, IEnumerable<(string UserId, string Username)> UserInfo)> CreateUserIdentitiesAsync(
            IEnumerable<(string Username, string Password)> userCredentials)
        {
            logger.LogInformation("Start creating users identities.");

            var userRoleName = Roles.User.ToString("G");
            var roleId = await applicationDbContext.Roles
                .Where(x => x.Name == userRoleName)
                .Select(x => x.Id)
                .FirstOrDefaultAsync();

            // Create users
            var users = userCredentials.Select(x =>
            {
                var user = new ApplicationUser
                {
                    UserName = x.Username,
                    NormalizedUserName = x.Username.ToUpper(),
                    LockoutEnabled = userManager.SupportsUserLockout
                };
                user.PasswordHash = passwordHasher.HashPassword(user, x.Password);

                return user;
            }).ToList();
            applicationDbContext.Users.AddRange(users);
            var (addUsersResult, _) = await TryExecuteAsync(() => applicationDbContext.SaveChangesAsync(),
                "Error creating user identity for users.",
                ErrorTarget.UserStateFailure);
            if (!addUsersResult.Succeeded)
            {
                return (addUsersResult, null);
            }

            // Set roles for created users
            var userRoles = users.Select(x => new IdentityUserRole<string> { UserId = x.Id, RoleId = roleId }).ToList();
            applicationDbContext.UserRoles.AddRange(userRoles);
            var (setRolesResult, _) = await TryExecuteAsync(() => applicationDbContext.SaveChangesAsync(),
                "Error creating role identity for users.",
                ErrorTarget.UserStateFailure);
            if (!setRolesResult.Succeeded)
            {
                applicationDbContext.UserRoles.RemoveRange(userRoles);
                applicationDbContext.Users.RemoveRange(users);
                
                // Try to delete previously created users if roles creation is unsuccessful
                var (removeUsersResult, _) = await TryExecuteAsync(() => applicationDbContext.SaveChangesAsync(), 
                    "Error while deleting users with unsuccessfully set roles.",
                    ErrorTarget.UserStateFailure);
                if (!removeUsersResult.Succeeded)
                {
                    setRolesResult.Errors.Add(removeUsersResult.Errors.First());
                }
                
                return (setRolesResult, null);
            }

            logger.LogInformation("Users have successfully created. Start to assign users roles.");
            
            return (Result.Success(), users.Select(x => (x.Id, x.UserName)));
        }

        public async Task<Result> DeleteUserIdentityAsync(string userId)
        {
            logger.LogInformation("Start deleting the user identity for userId {userId}.", userId);

            (Result result, ApplicationUser user) = await FindUserIdentityByIdAsync(userId);

            if (!result.Succeeded)
            {
                logger.LogError("Error deleting the user identity for userId {userId}. Errors: {@message}", userId, result.Errors);

                return result;
            }

            logger.LogInformation("Start deleting the user identity for userId {userId}.", userId);

            IdentityResult deleteResult = await userManager.DeleteAsync(user);

            if (!deleteResult.Succeeded)
            {
                result = deleteResult.ToApplicationResult();

                logger.LogError("Error deleting the user identity for userId {userId}. Errors: {@message}", userId, result.Errors);

                return result;
            }

            logger.LogInformation("Successfully deleted {userName} user identity with userId {userId}.", user.UserName, userId);

            return Result.Success();
        }

        public async Task<Result> AddToMedicalRoleAsync(string userId, string healthSecurityId)
        {
            var medicalRoleName = Roles.Medical.ToString("G");

            logger.LogInformation("Start assignment of user with userId {userId} to {medicalRole} role.",
                userId,
                medicalRoleName);

            (Result searchResult, ApplicationUser user) = await FindUserIdentityByIdAsync(userId);

            if (!searchResult.Succeeded)
            {
                logger.LogError("Error on assignment user with userId {userId}. Errors: {@message}",
                    userId,
                    searchResult.Errors);

                return searchResult;
            }

            if (await userManager.IsInRoleAsync(user, medicalRoleName))
            {
                logger.LogInformation("User with userId {userId} already assignment to {medicalRole} role.",
                    userId,
                    medicalRoleName);

                return Result.Success();
            }

            //DO NOT CREATE CONTACT TRACING RELATED TABLES
            //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
            //if (!medicalRegistrationRepository.TryRegistration(healthSecurityId))
            //{
            //    Result result = Result.Failure(new InnerError(ErrorTarget.InvalidHealthSecurityId,
            //        "Health security id is already taken or expired."));

            //    logger.LogWarning("Unsuccessful result on validation of the security Id {healthSecurityId}. Errors: {@message}",
            //        healthSecurityId,
            //        result.Errors);

            //    return result;
            //}

            IdentityResult roleAssignmentResult = await userManager.AddToRoleAsync(user, medicalRoleName);

            if (!roleAssignmentResult.Succeeded)
            {
                //DO NOT CREATE CONTACT TRACING RELATED TABLES
                //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
                //medicalRegistrationRepository.RollBackRegistration(healthSecurityId);

                Result result = roleAssignmentResult.ToApplicationResult();

                logger.LogError("Error on assignment user with userId {userId} to {medicalRole} role. Errors: {@message}",
                    userId,
                    medicalRoleName,
                    result.Errors);

                return result;
            }

            logger.LogInformation("Successfully assigned {userName} user with userId {userId} to {medicalRole} role..",
                user.UserName,
                userId,
                medicalRoleName);

            return Result.Success();
        }

        public async Task<(Result Result, string[] UserRoles)> GetUserRolesAsync(string userId)
        {
            logger.LogInformation("Start to find the user identity for {userId}.", userId);

            (Result searchResult, ApplicationUser user) = await FindUserIdentityByIdAsync(userId);

            if (!searchResult.Succeeded)
            {
                logger.LogError("Failed to find the user identity for {userId}. Errors: {@message}",
                    userId,
                    searchResult.Errors);

                return (searchResult, Array.Empty<string>());
            }

            logger.LogInformation("User identity has been found. Start retrieving roles for user {userId}.", userId);

            IList<string> roles = await userManager.GetRolesAsync(user);

            logger.LogInformation("Successfully retrieved roles for {userName} with userId {userId}.",
                user.UserName,
                userId);

            return (Result.Success(), roles.ToArray());
        }

        public async Task<(Result Result, Token Tokens)> PostRegisterLoginAsync(string userName,
            string password,
            CancellationToken cancellationToken)
        {
            DiscoveryDocumentResponse discoveryDocument = await discoveryCache.GetAsync();

            if (discoveryDocument.IsError)
            {
                Result result = Result.Failure(new InnerError(ErrorTarget.DiscoveryDocument, discoveryDocument.Error));

                logger.LogInformation("Error on fetching the discovery document. Error: {error}", discoveryDocument.Error);

                return (result, (Token)null);
            }

            logger.LogInformation("Starting post-register login for {userName}.", userName);

            TokenResponse tokenResponse =
                await RequestTokenAsync(userName, password, discoveryDocument.TokenEndpoint, cancellationToken);

            if (tokenResponse.IsError)
            {
                Result result = Result.Failure(new InnerError(ErrorTarget.Token, tokenResponse.Error));

                logger.LogInformation("Error on post-register login for {userName}. Errors: {@message}", userName, result.Errors);

                return (result, (Token) null);
            }

            logger.LogInformation("Successful post-register login for {userName}.", userName);

            return (Result.Success(),
                       new Token(tokenResponse.AccessToken, tokenResponse.RefreshToken, tokenResponse.ExpiresIn));
        }

        private async Task<(Result Result, ApplicationUser User)> FindUserIdentityByIdAsync(string userId)
        {
            ApplicationUser user = await userManager.FindByIdAsync(userId);

            return user != null
                       ? (Result.Success(), user)
                       : (Result.ValidationError(new InnerError(ErrorTarget.UserIdentityNotFound, "Unable to find the user identity.")), null);
        }

        private async Task<TokenResponse> RequestTokenAsync(string user,
            string password,
            string tokenEndpoint,
            CancellationToken cancellationToken)
            => await httpClient.RequestPasswordTokenAsync(new PasswordTokenRequest
                   {
                       Address = tokenEndpoint,

                       ClientId = clientIdentity.ClientId,
                       Scope = clientIdentity.Scope,

                       UserName = user,
                       Password = password
                   },
                   cancellationToken);

        private async Task<(Result, TActionResult)> TryExecuteAsync<TActionResult>(Func<Task<TActionResult>> action, string errorMessage, string errorTarget)
        {
            try
            {
                return (Result.Success(), await action());
            }
            catch (Exception exception)
            {
                logger.LogError("{message}. Errors: {exceptionMessage}", errorMessage, exception.Message);
                return (Result.Failure(new[] { new InnerError(errorTarget, errorMessage) }), default);
            }
        }
    }
}