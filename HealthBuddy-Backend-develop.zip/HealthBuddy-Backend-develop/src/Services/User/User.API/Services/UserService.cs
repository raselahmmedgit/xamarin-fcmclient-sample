﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Interfaces;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Application.Core.Options;
using Epam.CovidResistance.Shared.Domain.Model;
using Epam.CovidResistance.Shared.Domain.Model.Errors;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.Services
{
    /// <summary>
    /// The service for user state management.
    /// </summary>
    public class UserService : IUserService
    {
        private readonly Statuses statuses;
        private readonly IUserRepository userRepository;
        private readonly ILogger<UserService> logger;
        private readonly IDateTimeService dateTimeService;
        /// <summary>
        /// Initializes a new instance of the <see cref="UserService"/> class.
        /// </summary>
        public UserService(IUserRepository userRepository, IOptions<Statuses> statusesOptions,
            ILogger<UserService> logger, IDateTimeService dateTimeService)
        {
            this.userRepository = userRepository;
            statuses = statusesOptions.Value;
            this.logger = logger;
            this.dateTimeService = dateTimeService;
        }

        /// <summary>
        /// Gets the user information by user token. 
        /// </summary>
        /// <param name="userId">The user token.</param>
        /// <returns>The user information.</returns>
        public async Task<(Result result, UserInfo userInfo)> GetUserInformationAsync(string userId)
        {
            UserInfo userInfo = await userRepository.GetUserInfoAsync(userId);

            return userInfo != null
                       ? (Result.Success(), userInfo)
                       : (Result.ValidationError(new InnerError(ErrorTarget.UserNotFound, "Unable to find the user.")), null);
        }
        

        /// <summary>
        /// Creates user information.
        /// </summary>
        /// <param name="userId">The user token.</param>
        /// <param name="username">The username.</param>
        public Task RegisterUserAsync(string userId, string username)
        {
            var userInfo = new UserInfo(userId, username, statuses.Default, dateTimeService.UtcNow);
            return userRepository.RegisterUserAsync(userInfo);
        }

        /// <summary>
        /// Creates user information.
        /// </summary>
        /// <param name="users">The tuple where Item1=userId, Item2=userName.</param>
        public Task RegisterUsersAsync(IEnumerable<(string, string)> users)
        {
            var usersInfo = users.Select(x => new UserInfo(x.Item1, x.Item2, statuses.Default, dateTimeService.UtcNow));
            return userRepository.RegisterUsersAsync(usersInfo);
        }

        public Task DeleteUserInformationAsync(string userId)
        {
            //DO NOT CREATE CONTACT TRACING RELATED TABLES
            //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
            //logger.LogInformation("Start deleting user status history with userId {userId}.", userId);
            //await userRepository.DeleteUserStatusHistoryAsync(userId);

            logger.LogInformation("Start deleting user data with userId {userId}.", userId);
            return userRepository.DeleteUserAsync(userId);
        }
    }
}