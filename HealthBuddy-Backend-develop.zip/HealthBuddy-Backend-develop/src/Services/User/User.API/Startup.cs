// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Interfaces;
using Epam.CovidResistance.Services.User.API.Services;
using Epam.CovidResistance.Services.User.Infrastructure;
using Epam.CovidResistance.Services.User.Infrastructure.Persistence;
using Epam.CovidResistance.Shared.API.Common;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Configuration.AspNetCore.Extensions;
using Epam.CovidResistance.Shared.Configuration.Extensions;
using Epam.CovidResistance.Shared.IdentityDbContext.Persistence;
using Epam.CovidResistance.Shared.Infrastructure.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Text.Json;

namespace Epam.CovidResistance.Services.User.API
{
    /// <summary>The startup class</summary>
    public class Startup
    {
        /// <summary>Initializes a new instance of the <see cref="Startup"/> class.</summary>
        /// <param name="configuration">The configuration.</param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>Gets the configuration.</summary>
        /// <value>The configuration.</value>
        public IConfiguration Configuration { get; }

        /// <summary>Configures the services.</summary>
        /// <param name="services">The services.</param>
        /// <remarks>This method gets called by the runtime. Use this method to add services to the container.</remarks>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton<IExceptionHandler, ExceptionHandler>();
            
            services.AddSerilogWithInsights<Startup>(Configuration);

            services.AddControllers()
                .AddJsonOptions(options => options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase)
                .ConfigureApiBehaviorOptions(options
                    => options.InvalidModelStateResponseFactory = ModelStateExtensions.InvalidModelStateResponseFactory);

            services.AddHealthChecks()
                .AddDbContextCheck<ApplicationDbContext>();

            services.AddInfrastructure(Configuration);
            services.AddMemoryCache();
            services.AddApplicationMetadata();

            services.AddScoped<IUserService, UserService>();
            //DO NOT CREATE CONTACT TRACING RELATED TABLES
            //BEFORE CONTACT TRACING FEATURE IS DEFINED AND CONFIRMED BY THE CUSTOMER.
            //services.AddScoped<IHealthSecurityService, HealthSecurityService>();
            services.AddScoped<IDateTimeService, DateTimeService>();
            services.AddIdentityServerAuthentication(Configuration);
            services.AddAuthorization();
        }

        /// <summary>Configures the specified application.</summary>
        /// <param name="app">The application.</param>
        /// <param name="env">The environment.</param>
        /// <remarks>This method gets called by the runtime. Use this method to configure the HTTP request pipeline.</remarks>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler(builder => builder.Run(async context =>
                {
                    var exceptionHandler = builder.ApplicationServices.GetService<IExceptionHandler>();
                    await exceptionHandler.HandleAsync(context);
                }));
                ApplicationDbContextSeed.InitializeDatabase(Configuration);
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHealthChecks("/health");
            });
        }
    }
}