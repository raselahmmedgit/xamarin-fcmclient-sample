﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Domain.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.Interfaces
{
    /// <summary>
    /// The interface for user management.
    /// </summary>
    public interface IUserService
    {
        /// <summary>
        /// Gets the user information by user token. 
        /// </summary>
        /// <param name="userId">The user token.</param>
        /// <returns>The user information.</returns>
        Task<(Result result, UserInfo userInfo)> GetUserInformationAsync(string userId);

        /// <summary>
        /// Creates user information.
        /// </summary>
        /// <param name="userId">The user token.</param>
        /// <param name="username">The username.</param>
        Task RegisterUserAsync(string userId, string username);

        /// <summary>
        /// Creates user information.
        /// </summary>
        /// <param name="users">The tuple where Item1=userId, Item2=userName.</param>
        Task RegisterUsersAsync(IEnumerable<(string, string)> users);

        Task DeleteUserInformationAsync(string userId);
    }
}