﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Shared.API.Common.Controllers;
using Epam.CovidResistance.Shared.Application.Core.Constants;
using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.Controllers
{
    /// <summary>
    /// Represents the controller for application metadata endpoints.
    /// </summary>
    [Route("api/v1/[controller]"), ApiController]
    public class ApplicationController : BaseApiController
    {
        private readonly IMetadataService metadataService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicationController"></see> class.
        /// </summary>
        public ApplicationController(IMetadataService metadataService)
        {
            this.metadataService = metadataService;
        }

        /// <summary>
        /// Gets the metadata required for running Mobile application.
        /// </summary>
        /// <returns>Application metadata.</returns>
        [HttpGet("metadata")]
        public async Task<IActionResult> GetMetadata()
        {
            IHeaderDictionary headers = HttpContext.Request.Headers;
            
            headers.TryGetValue(HeaderNames.AcceptLanguage, out StringValues languageCode);
            headers.TryGetValue(HeaderNames.CmsUrl, out StringValues cmsUrl);
            headers.TryGetValue(HeaderNames.CmsAuthorization, out StringValues authInfo);

            headers.TryGetValue(HeaderNames.FiltersCacheTtl, out StringValues filtersCacheTtlStringValue);
            var filtersCacheTtl = int.TryParse(filtersCacheTtlStringValue, out var cacheTtl) ? cacheTtl : 0;

            Metadata metadata = await metadataService.GetAsync(languageCode, cmsUrl, authInfo, filtersCacheTtl);
            return Ok(new { Metadata = metadata });
        }
    }
}