﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Extensions;
using Epam.CovidResistance.Services.User.API.Interfaces;
using Epam.CovidResistance.Services.User.API.Models;
using Epam.CovidResistance.Services.User.Application.Common.Interfaces;
using Epam.CovidResistance.Shared.API.Common.Controllers;
using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Domain.Model;
using IdentityServer4.AccessTokenValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.Controllers
{
    /// <summary>
    /// Represents the controller for user endpoints.
    /// </summary>
    [Authorize(AuthenticationSchemes = IdentityServerAuthenticationDefaults.AuthenticationScheme, Roles = "User"),
     Route("api/v1/[controller]"), ApiController]
    public class UserController : BaseApiController
    {
        private readonly IIdentityService identityService;
        private readonly IUserService userService;
        private readonly ILogger<UserController> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserController"></see> class.
        /// </summary>
        public UserController(IUserService userService,
            IIdentityService identityService,
            ILogger<UserController> logger)
        {
            this.userService = userService;
            this.identityService = identityService;
            this.logger = logger;
        }

        /// <summary>
        /// Gets the user profile which the Mobile application requires for successful running.
        /// </summary>
        /// <returns>User profile.</returns>
        [HttpGet("profile")]
        public async Task<IActionResult> GetProfile()
        {
            var userId = User.GetUserId();

            logger.LogInformation("Start to find profile for user {user}.", userId);

            (Result userResult, UserInfo userInfo) = await userService.GetUserInformationAsync(userId);

            if (!userResult.Succeeded)
            {
                logger.LogInformation("Failed to find profile for user {user}. Errors: {@message}", userId, userResult.Errors);
                return NotFound(userResult);
            }

            logger.LogInformation("Successfully found profile for user {user}.", userId);

            (Result rolesResult, string[] userRoles) = await identityService.GetUserRolesAsync(userId);

            if (!rolesResult.Succeeded)
            {
                return InternalServerError(rolesResult);
            }

            ProfileResponse response = BuildProfileResponse(userInfo, userRoles);
            
            return Ok(response);
        }

        private static ProfileResponse BuildProfileResponse(UserInfo userInfo, IEnumerable<string> userRoles)
        {
            var userAccount = new UserAccount
            {
                UserId = userInfo.UserId,
                Username = userInfo.UserName,
                Roles = userRoles
            };

            var userStatus = new UserStatus
            {
                StatusId = userInfo.StatusId,
                StatusChangedOn = userInfo.StatusChangedOn
            };

            var response = new ProfileResponse
            {
                UserAccount = userAccount,
                UserStatus = userStatus
            };

            return response;
        }
    }
}