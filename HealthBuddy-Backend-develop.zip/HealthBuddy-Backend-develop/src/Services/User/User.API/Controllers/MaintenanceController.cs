﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Interfaces;
using Epam.CovidResistance.Services.User.API.Models;
using Epam.CovidResistance.Services.User.Application.Common.Interfaces;
using Epam.CovidResistance.Shared.API.Common.Controllers;
using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Configuration.AspNetCore.Extensions;
using Epam.CovidResistance.Shared.Domain.Model.Errors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.Controllers
{
    /// <summary>
    /// Represents the controller for anonymous account endpoints.
    /// </summary>
    [Route("api/v1/[controller]"), ApiController]
    public class MaintenanceController : BaseApiController
    {
        private readonly IIdentityService identityService;
        private readonly IUserService userService;
        private readonly ILogger<MaintenanceController> logger;
        private readonly IServiceScopeFactory serviceScopeFactory;

        /// <summary>
        /// Initializes a new instance of the <see cref="MaintenanceController"></see> class.
        /// </summary>
        public MaintenanceController(IIdentityService identityService, IUserService userService, 
                                     IServiceScopeFactory serviceScopeFactory, ILogger<MaintenanceController> logger)
        {
            this.identityService = identityService;
            this.userService = userService;
            this.serviceScopeFactory = serviceScopeFactory;
            this.logger = logger;
        }

        [HttpPost("multiregister")]
        public async Task<IActionResult> MultiRegister([FromBody] RegisterRequest registerForm, int? number, int? initNumber)
        {
            if (number == null || !(number > 0))
            {
                return Ok("No users created.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(Result.Failure(ModelState.ToInnerErrors()));
            }

            var initIntNumber = initNumber is null || initNumber < 0 ? 1 : initNumber.Value;

            IEnumerable<(string, string)> userData = Enumerable.Range(initIntNumber, (int)number)
                .Select(x => (registerForm.Username + x, registerForm.Password + x));

            return await Register(userData);
        }

        private async Task<IActionResult> Register(IEnumerable<(string UserName, string Password)> usersData)
        {
            var (createResult, userInfo) = await identityService.CreateUserIdentitiesAsync(usersData);
            if (!createResult.Succeeded)
            {
                return createResult.Status == ResultStatus.Validation
                    ? BadRequest(createResult)
                    : InternalServerError(createResult);
            }

            try
            {
                await userService.RegisterUsersAsync(userInfo);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Unsuccessful attempt to save users to the database. Please clear the database manually.");
                return InternalServerError(Result.FromException(ex));
            }

            return Ok("Users were registered successfully");
        }
    }
}