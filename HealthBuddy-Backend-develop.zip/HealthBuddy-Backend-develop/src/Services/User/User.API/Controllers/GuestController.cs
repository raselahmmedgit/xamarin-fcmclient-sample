// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Interfaces;
using Epam.CovidResistance.Services.User.API.Models;
using Epam.CovidResistance.Services.User.Application.Common.Interfaces;
using Epam.CovidResistance.Services.User.Application.Common.Models;
using Epam.CovidResistance.Shared.API.Common.Controllers;
using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Configuration.AspNetCore.Extensions;
using Epam.CovidResistance.Shared.Domain.Model.Errors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.Controllers
{
    /// <summary>
    /// Represents the controller for anonymous account endpoints.
    /// </summary>
    [Route("api/v1/account"), ApiController]
    public class GuestController : BaseApiController
    {
        private readonly IIdentityService identityService;
        private readonly IUserService userService;
        private readonly ILogger<GuestController> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="GuestController"></see> class.
        /// </summary>
        public GuestController(IIdentityService identityService, IUserService userService, ILogger<GuestController> logger)
        {
            this.identityService = identityService;
            this.userService = userService;
            this.logger = logger;
        }

        /// <summary>
        /// Registers the user.
        /// </summary>
        /// <param name="registerForm">Parameters for user registration.</param>
        /// <param name="cancellationToken">The cancellation token for request.</param>
        /// <returns>User access and refresh tokens.</returns>
        [HttpPost]
        public async Task<IActionResult> Register([FromBody] RegisterRequest registerForm, CancellationToken cancellationToken)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(Result.Failure(ModelState.ToInnerErrors()));
            }

            (Result createResult, var userId) =
                await identityService.CreateUserIdentityAsync(registerForm.Username, registerForm.Password);

            if (!createResult.Succeeded)
            {
                return createResult.Status == ResultStatus.Validation
                           ? BadRequest(createResult)
                           : InternalServerError(createResult);
            }

            try
            {
                await userService.RegisterUserAsync(userId, registerForm.Username);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Unsuccessful attempt to save user {userId} to the database. Start deleting user identity for data consistency.");
                
                Result deleteResult = await identityService.DeleteUserIdentityAsync(userId);

                return InternalServerError(
                    Result.Failure(deleteResult.Errors.Append(new InnerError(ErrorTarget.UserStateFailure, "Unsuccessful attempt to save new user to the database."))));
            }

            (Result tokenResult, Token tokens) = await identityService.PostRegisterLoginAsync(registerForm.Username,
                                                     registerForm.Password,
                                                     cancellationToken);

            return tokenResult.Succeeded
                       ? Ok(tokens)
                       : InternalServerError(tokenResult);
        }        
    }
}