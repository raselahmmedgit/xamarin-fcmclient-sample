// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.User.API.Extensions;
using Epam.CovidResistance.Services.User.API.Interfaces;
using Epam.CovidResistance.Services.User.API.Models;
using Epam.CovidResistance.Services.User.Application.Common.Interfaces;
using Epam.CovidResistance.Shared.API.Common.Controllers;
using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Configuration.AspNetCore.Extensions;
using IdentityServer4.AccessTokenValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.User.API.Controllers
{
    /// <summary>
    /// Represents the controller for account endpoints.
    /// </summary>
    [Authorize(AuthenticationSchemes = IdentityServerAuthenticationDefaults.AuthenticationScheme, Roles = "User"),
     Route("api/v1/[controller]"), ApiController]
    public class AccountController : BaseApiController
    {
        private readonly IIdentityService identityService;
        private readonly IUserService userService;
        private readonly ILogger<AccountController> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="AccountController"></see> class.
        /// </summary>
        public AccountController(IIdentityService identityService, IUserService userService, ILogger<AccountController> logger)
        {
            this.identityService = identityService;
            this.userService = userService;
            this.logger = logger;
        }

        /// <summary>
        /// Nominates the user as medical.
        /// </summary>
        /// <param name="nominationRequest">Parameters for nominating the user as medical.</param>
        [HttpPost("nominateAsMedical")]
        public async Task<IActionResult> AddToRole([FromBody] MedicalNominationRequest nominationRequest)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(Result.Failure(ModelState.ToInnerErrors()));
            }

            Result changeResult =
                await identityService.AddToMedicalRoleAsync(User.GetUserId(), nominationRequest.HealthSecurityId);

            if (changeResult.Status == ResultStatus.Validation)
            {
                return BadRequest(changeResult);
            }

            return changeResult.Succeeded
                       ? Ok()
                       : InternalServerError(changeResult);
        }

        [HttpPost("delete")]
        public async Task<IActionResult> Delete()
        {
            var userId = User.GetUserId();

            Result deleteResult = 
                await GetExecutionResultAsync(async () => await userService.DeleteUserInformationAsync(userId));

            if (!deleteResult.Succeeded)
            {
                return InternalServerError(deleteResult);
            }

            Result identityDeleteResult = await identityService.DeleteUserIdentityAsync(userId);

            if (identityDeleteResult.Succeeded)
            {
                return NoContent();
            }

            logger.LogError("An unexpected exception has occurred. Errors: {@message}", identityDeleteResult.Errors);

            return InternalServerError(identityDeleteResult);
        }
    }
}