﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.Application.Common.Interfaces;
using Epam.CovidResistance.Services.Notification.Infrastructure.ServiceBus;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using Epam.CovidResistance.Shared.Infrastructure.Persistence.Cassandra;
using Epam.CovidResistance.Shared.Infrastructure.Persistence.Cassandra.Repositories;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Epam.CovidResistance.Services.Notification.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddOptions<CassandraOptions>()
                .Configure<IConfiguration>((settings, config) =>
                {
                    config.GetSection("Cassandra").Bind(settings);
                });

            services.AddSingleton<ICassandraCluster, CassandraCluster>();
            services.AddSingleton<ICassandraSession, CassandraSession>();
            services.AddTransient<IUserRepository, UserRepository>();

            services.AddSingleton<ITopicClient>(_
                => new TopicClient(
                    configuration.GetValue<string>("ServiceBus:NotificationsTopic:SendConnection"),
                    configuration.GetValue<string>("ServiceBus:NotificationsTopic:TopicName")));

            services.AddScoped<IServiceBusClient, ServiceBusClient>();

            return services;
        }
    }
}