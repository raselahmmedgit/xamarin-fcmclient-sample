﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.Application.Common.Options;
using Microsoft.Azure.NotificationHubs;
using Microsoft.Extensions.Options;
using System.Threading;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.Notification.Infrastructure.NotificationHub
{
    /// <summary>
    /// Adapter for <see cref="NotificationHubClient"/> to <see cref="IAzureNotificationHubClient"/> interface.
    /// Notification Hub client that could be mocked.
    /// </summary>
    public class AzureNotificationHubClient : IAzureNotificationHubClient
    {
        private readonly NotificationHubClient hubClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="AzureNotificationHubClient"></see> class.
        /// </summary>
        public AzureNotificationHubClient(IOptions<NotificationHubOptions> notificationHubOptions)
        {
            hubClient = NotificationHubClient.CreateClientFromConnectionString(notificationHubOptions.Value.Connection,
                notificationHubOptions.Value.Name);
        }

        /// <summary>
        /// Sends a notification directly to a deviceHandle (a valid token as expressed by the Notification type).
        /// Users of this API do not use Registrations or Installations. Instead, users of this API manage all devices
        /// on their own and use Azure Notification Hub solely as a pass through service to communicate with
        /// the various Push Notification Services.
        /// </summary>
        /// <param name="notification">A instance of a Notification, identifying which Push Notification Service to send to.</param>
        /// <param name="deviceHandle">A valid device identifier.</param>
        /// <param name="cancellationToken">A <see cref="T:System.Threading.CancellationToken" /> to observe while waiting for a task to complete.</param>
        /// <returns></returns>
        /// <exception cref="T:System.ArgumentNullException">
        /// Thrown when notification or deviceHandle object is null
        /// </exception>
        public Task<NotificationOutcome> SendDirectNotificationAsync(
            Microsoft.Azure.NotificationHubs.Notification notification,
            string deviceHandle,
            CancellationToken cancellationToken = default)
                => hubClient.SendDirectNotificationAsync(notification, deviceHandle, cancellationToken);
    }
}