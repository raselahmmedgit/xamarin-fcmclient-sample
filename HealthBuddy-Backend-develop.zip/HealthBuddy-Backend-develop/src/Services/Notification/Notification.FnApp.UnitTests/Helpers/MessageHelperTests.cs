﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.FnApp.Helpers;
using FluentAssertions;
using Microsoft.Azure.ServiceBus;
using Newtonsoft.Json;
using NUnit.Framework;
using System.Collections.Generic;
using System.Text;

namespace Notification.FnApp.UnitTests.Helpers
{
    public static class MessageHelperTests
    {
        private class MessageBody
        {
            public string Text { get; set; }
        }
        
        #region GetMessageBody

        [Test]
        public static void GetMessageBody_Should_ReturnDeserializedMessageBody()
        {
            // Arrange
            const string body = "{ Text: \"Text\" }";
            byte[] bodyBytes = Encoding.UTF8.GetBytes(body);
            var message = new Message { Body = bodyBytes };

            var expectedResult = new MessageBody { Text = "Text" };
            
            // Act
            var actualResult = MessageHelper.GetMessageBody<MessageBody>(message);

            // Assert
            actualResult.Should().BeEquivalentTo(expectedResult);
        }

        [Test]
        public static void GetMessageBody_Should_ReturnNull_When_MessageIsNull()
        {
            // Act
            var result = MessageHelper.GetMessageBody<object>(null);

            // Assert
            result.Should().BeNull();
        }

        [Test]
        public static void GetMessageBody_Should_ReturnNull_When_MessageBodyIsNull()
        {
            // Arrange
            var message = new Message { Body = null };
            
            // Act
            var result = MessageHelper.GetMessageBody<object>(message);

            // Assert
            result.Should().BeNull();
        }

        #endregion
        
        #region CreateMessageFromObject

        [Test]
        public static void CreateMessageFromObject_Should_ReturnFilledMessageForSpecifiedParameters()
        {
            // Arrange
            var payload = new MessageBody { Text = "Text" };
            byte[] payloadBytes = Encoding.UTF8.GetBytes("{\"text\":\"Text\"}");
            
            var properties = new Dictionary<string, object>
            {
                ["One"] = 1,
                ["Two"] = 2
            };
            const string sessionId = "SessionId";

            var expectedMessage = new Message(payloadBytes)
            {
                ContentType = "application/json",
                SessionId = sessionId,
                UserProperties =
                {
                    ["One"] = 1,
                    ["Two"] = 2
                }
            };

            // Act
            Message actualMessage = MessageHelper.CreateMessageFromObject(payload, properties, sessionId);

            // Assert
            actualMessage.Should().BeEquivalentTo(expectedMessage,
                c => c.Excluding(x => x.ExpiresAtUtc)
                    .Excluding(x => x.SystemProperties));
        }
        
        #endregion
    }
}