﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.Application.Common.Enums;
using Epam.CovidResistance.Services.Notification.Application.Common.Models;
using Epam.CovidResistance.Services.Notification.FnApp.Services;
using Epam.CovidResistance.Services.Notification.Infrastructure.NotificationHub;
using FluentAssertions;
using FluentAssertions.Execution;
using FluentAssertions.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.NotificationHubs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Threading.Tasks;
using HubNotification = Microsoft.Azure.NotificationHubs.Notification;
using static Notification.FnApp.UnitTests.TestHelpers;

namespace Notification.FnApp.UnitTests.Services
{
    public class NotificationsServiceTests
    {
        #region Test_Setup
        
        private IAzureNotificationHubClient azureHubClient;
        private ILogger<NotificationsService> logger;
        private NotificationsService service;
        
        private SendPushNotification request;
        private NotificationOutcome outcome;
        
        [SetUp]
        public void Setup()
        {
            azureHubClient = Substitute.For<IAzureNotificationHubClient>();
            logger = Substitute.For<ILogger<NotificationsService>>();
            service = new NotificationsService(azureHubClient, logger);
            
            request = new SendPushNotification
            {
                Token = "Token",
                TargetPlatform = "fcm",
                Purpose = NotificationPurpose.Unknown,
                Message = "Message"
            };
            outcome = new NotificationOutcome();
        }
        
        #endregion
        
        #region PushMessageAsync
        
        [Test]
        public async Task PushMessageAsync_Should_SendFcmNotification_When_TargetPlatformIsFcm()
        {
            // Arrange
            request.TargetPlatform = "fcm";
            
            string sentNotificationBody = null;
            azureHubClient
                .SendDirectNotificationAsync(Arg.Do<HubNotification>(x => sentNotificationBody = x?.Body), default)
                .ReturnsForAnyArgs(outcome);

            JToken expectedNotificationBodyJToken = JToken.Parse($"{{ \"data\": {{ \"message\": \"{request.Message}\" }} }}");

            // Act
            IActionResult result = await service.PushMessageAsync(request);
            JToken sentNotificationBodyJToken = TryParseJToken(sentNotificationBody);

            // Assert
            await azureHubClient.ReceivedWithAnyArgs(1).SendDirectNotificationAsync(default, default);
            await azureHubClient.Received(1).SendDirectNotificationAsync(Arg.Any<FcmNotification>(), request.Token);

            using (new AssertionScope())
            {
                result.Should().BeOfType<OkResult>();
                sentNotificationBodyJToken.Should().BeEquivalentTo(expectedNotificationBodyJToken);
            }
        }
        
        [Test]
        public async Task PushMessageAsync_Should_SendAppleNotification_When_TargetPlatformIsApns()
        {
            // Arrange
            request.TargetPlatform = "apns";

            string sentNotificationBody = null;
            azureHubClient
                .SendDirectNotificationAsync(Arg.Do<HubNotification>(x => sentNotificationBody = x?.Body), default)
                .ReturnsForAnyArgs(outcome);
            
            JToken expectedNotificationBodyJToken = JToken.Parse($"{{ \"aps\": {{ \"alert\": \"{request.Message}\" }} }}");

            // Act
            IActionResult result = await service.PushMessageAsync(request);
            JToken sentNotificationBodyJToken = TryParseJToken(sentNotificationBody);

            // Assert
            await azureHubClient.ReceivedWithAnyArgs(1).SendDirectNotificationAsync(default, default);
            await azureHubClient.Received(1).SendDirectNotificationAsync(Arg.Any<AppleNotification>(), request.Token);

            using (new AssertionScope())
            {
                result.Should().BeOfType<OkResult>();
                sentNotificationBodyJToken.Should().BeEquivalentTo(expectedNotificationBodyJToken);
            }
        }

        [Test]
        public async Task PushMessageAsync_Should_ThrowNotSupportedException_When_TargetPlatformIsUnknown()
        {
            // Arrange
            request.TargetPlatform = "abcdefg";

            // Act
            Func<Task> act = () => service.PushMessageAsync(request);

            // Assert
            await act.Should().ThrowAsync<NotSupportedException>();
        }

        #endregion
    }
}