﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.FnApp.Exceptions;
using Epam.CovidResistance.Services.Notification.FnApp.Options;
using Epam.CovidResistance.Services.Notification.FnApp.Services;
using FluentAssertions;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static Notification.FnApp.UnitTests.TestHelpers;

namespace Notification.FnApp.UnitTests.Services
{
    public class RetryHandlerTests
    {
        #region Test_Setup
        
        private IMessageReceiver messageReceiver;
        private ILogger logger;
        private RetryHandler retryHandler;

        [SetUp]
        public void Setup()
        {
            messageReceiver = Substitute.For<IMessageReceiver>();
            logger = Substitute.For<ILogger>();
            retryHandler = new RetryHandler();
        }
        
        #endregion
        
        #region RetryMessageAsync
        
        [TestCase(typeof(BadMessageException))]
        [TestCase(typeof(ApplicationException))]
        [TestCase(typeof(NotSupportedException))]
        public async Task RetryMessageAsync_Should_MoveMessageToDeadLetterQueueAndReturnTrue_When_ExceptionIsUnretryable(Type exceptionType)
        {
            // Arrange
            var unretryableExceptions = new Dictionary<Type, Exception>
            {
                { typeof(BadMessageException), new BadMessageException("Error") },
                { typeof(ApplicationException), new ApplicationException("Error") },
                { typeof(NotSupportedException), new NotSupportedException("Error") }
            };
            
            Message message = CreateValidMessage();
            Exception exception = unretryableExceptions[exceptionType];

            // Act
            var result = await retryHandler.RetryMessageAsync(message, exception, messageReceiver, null, logger);

            // Assert
            await messageReceiver.ReceivedWithAnyArgs(1)
                .DeadLetterAsync(default, default, default);
            await messageReceiver.Received(1)
                .DeadLetterAsync(
                    Arg.Is(message.SystemProperties.LockToken),
                    Arg.Is("Application error"),
                    exception.Message);
            result.Should().BeTrue();
        }
        
        [Test]
        public async Task RetryMessageAsync_Should_MoveMessageToDeadLetterQueueAndReturnTrue_When_MaxRetryCountExceeded()
        {
            // Arrange
            Message message = CreateValidMessage(deliveryCount: 3);
            var exception = new Exception("Error");
            var policyOptions = new RetryPolicyOptions { MaxRetryCount = message.SystemProperties.DeliveryCount };

            // Act
            var result = await retryHandler.RetryMessageAsync(message, exception, messageReceiver, policyOptions, logger);

            // Assert
            await messageReceiver.ReceivedWithAnyArgs(1)
                .DeadLetterAsync(default, default, default);
            await messageReceiver.Received(1)
                .DeadLetterAsync(
                    Arg.Is(message.SystemProperties.LockToken),
                    Arg.Is("Exceeded max retry policy"),
                    exception.Message);
            result.Should().BeTrue();
        }
        
        [Test]
        public async Task RetryMessageAsync_Should_ReturnFalse_When_NextRetryIsAllowed()
        {
            // Arrange
            Message message = CreateValidMessage();
            var exception = new Exception("Error");

            // Act
            var result = await retryHandler.RetryMessageAsync(message, exception, messageReceiver, null, logger);

            // Assert
            await messageReceiver.DidNotReceiveWithAnyArgs()
                .DeadLetterAsync(default, default, default);
            result.Should().BeFalse();
        }
        
        #endregion
    }
}