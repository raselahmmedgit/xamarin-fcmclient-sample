﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Microsoft.Azure.ServiceBus;
using Newtonsoft.Json.Linq;
using System;
using System.Reflection;

namespace Notification.FnApp.UnitTests
{
    public static class TestHelpers
    {
        public static Message CreateValidMessage(int deliveryCount = 0)
        {
            var message = new Message
            {
                Body = Array.Empty<byte>()
            };
            
            PropertyInfo lockTokenGuidProperty = typeof(Message.SystemPropertiesCollection)
                .GetProperty("LockTokenGuid", BindingFlags.NonPublic | BindingFlags.Instance);
            lockTokenGuidProperty.GetSetMethod(true).Invoke(message.SystemProperties, new object[] { Guid.NewGuid() });
            
            PropertyInfo sequenceNumberProperty = typeof(Message.SystemPropertiesCollection)
                .GetProperty(nameof(Message.SystemProperties.SequenceNumber));
            sequenceNumberProperty.GetSetMethod(true).Invoke(message.SystemProperties, new object[] { 0 });
            
            PropertyInfo deliveryCountProperty = typeof(Message.SystemPropertiesCollection)
                .GetProperty(nameof(Message.SystemProperties.DeliveryCount));
            deliveryCountProperty.GetSetMethod(true).Invoke(message.SystemProperties, new object[] { deliveryCount });

            return message;
        }

        public static JToken TryParseJToken(string json)
        {
            try
            {
                return JToken.Parse(json);
            }
            catch
            {
                return null;
            }
        }
    }
}