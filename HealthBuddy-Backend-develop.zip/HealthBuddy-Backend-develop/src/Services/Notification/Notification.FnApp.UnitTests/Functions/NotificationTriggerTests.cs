﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.Application.Common.Models;
using Epam.CovidResistance.Services.Notification.FnApp.Exceptions;
using Epam.CovidResistance.Services.Notification.FnApp.Functions;
using Epam.CovidResistance.Services.Notification.FnApp.Interfaces;
using Epam.CovidResistance.Services.Notification.FnApp.Options;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Text;
using System.Threading.Tasks;
using static Notification.FnApp.UnitTests.TestHelpers;

namespace Notification.FnApp.UnitTests.Functions
{
    public class NotificationTriggerTests
    {
        #region Test_Setup
        
        private IOptions<RetryPolicyOptions> policyOptions;
        private INotificationsService notificationsService;
        private IRetryHandler retryHandler;
        private ILogger<NotificationTrigger> logger;
        private NotificationTrigger trigger;
        private IMessageReceiver messageReceiver;

        [SetUp]
        public void Setup()
        {
            policyOptions = Substitute.For<IOptions<RetryPolicyOptions>>();
            notificationsService = Substitute.For<INotificationsService>();
            retryHandler = Substitute.For<IRetryHandler>();
            logger = Substitute.For<ILogger<NotificationTrigger>>();
            trigger = new NotificationTrigger(policyOptions, notificationsService, retryHandler, logger);
            messageReceiver = Substitute.For<IMessageReceiver>();
            trigger.ActiveMessageReceiver = messageReceiver;
        }
        
        #endregion
        
        #region Run

        [Test]
        public async Task Run_Should_ThrowBadMessageException_When_SendPushNotificationInMessageIsNotProvidedAndRetryIsAllowed()
        {
            // Arrange
            Message message = CreateValidMessage();

            retryHandler
                .RetryMessageAsync(default, default, default, default, default)
                .Returns(false);

            // Act
            Func<Task> act = async () => await trigger.Run(message, null);

            // Assert
            await act.Should().ThrowAsync<BadMessageException>();
        }
        
        [Test]
        public async Task Run_Should_ThrowBadMessageException_When_SendPushNotificationInMessageIsNull()
        {
            // Arrange
            Message message = CreateValidMessage();
            message.Body = null;
            
            retryHandler
                .RetryMessageAsync(default, default, default, default, default)
                .Returns(false);

            // Act
            Func<Task> act = async () => await trigger.Run(message, null);

            // Assert
            await act.Should().ThrowAsync<BadMessageException>();
        }
        
        [Test]
        public async Task Run_Should_ThrowBadMessageException_When_SendPushNotificationInMessageIsInvalid()
        {
            // Arrange
            Message message = CreateValidMessage();
            var invalidNotification = new SendPushNotification();
            message.Body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(invalidNotification));
            
            retryHandler
                .RetryMessageAsync(default, default, default, default, default)
                .Returns(false);

            // Act
            Func<Task> act = async () => await trigger.Run(message, null);

            // Assert
            await act.Should().ThrowAsync<BadMessageException>();
        }

        [Test]
        public async Task Run_Should_SendNotificationAndCompleteMessageProcessing_When_SendPushNotificationInMessageIsValid()
        {
            // Arrange
            Message message = CreateValidMessage();
            var expectedNotification = new SendPushNotification
            {
                Token = "token",
                TargetPlatform = "platform",
                Message = "message"
            };
            message.Body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(expectedNotification));

            SendPushNotification sentNotification = null;
            notificationsService
                .PushMessageAsync(Arg.Do<SendPushNotification>(x => sentNotification = x))
                .ReturnsForAnyArgs(new OkResult());

            // Act
            await trigger.Run(message, null);

            // Assert
            await notificationsService.ReceivedWithAnyArgs(1).PushMessageAsync(default);
            sentNotification.Should().BeEquivalentTo(expectedNotification);

            await messageReceiver.ReceivedWithAnyArgs(1).CompleteAsync(lockToken: default);
            await messageReceiver.Received(1).CompleteAsync(Arg.Is(message.SystemProperties.LockToken));
            
            await retryHandler
                .DidNotReceiveWithAnyArgs()
                .RetryMessageAsync(default,
                    default,
                    default,
                    default,
                    default);
        }
        
        #endregion
    }
}