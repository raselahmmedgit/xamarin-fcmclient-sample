﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.API.Services;
using Epam.CovidResistance.Services.Notification.Application.Common.Interfaces;
using Epam.CovidResistance.Services.Notification.Application.Common.Models;
using NSubstitute;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.Notification.API.UnitTests.Services
{
    public class ServiceBusNotificationServiceTests
    {
        #region Test_Setup
        
        private const int N = 5;

        private ServiceBusNotificationService service;
        private IServiceBusClient serviceBusClient;

        [SetUp]
        public void Setup()
        {
            serviceBusClient = Substitute.For<IServiceBusClient>();
            service = new ServiceBusNotificationService(serviceBusClient);
        }
        
        #endregion
        
        #region SendNotificationsAsync
        
        [Test]
        public async Task SendNotificationsAsync_Should_SendNothingToBus_When_NullNotificationCollectionIsProvided()
        {
            // Act
            await service.SendNotificationsAsync(null);

            // Assert
            await serviceBusClient.DidNotReceiveWithAnyArgs().SendMessageAsync(default);
        }

        [Test]
        public async Task SendNotificationsAsync_Should_SendNothingToBus_When_EmptyNotificationCollectionIsProvided()
        {
            // Arrange
            IEnumerable<SendPushNotification> notifications = Enumerable.Empty<SendPushNotification>();

            // Act
            await service.SendNotificationsAsync(notifications);

            // Assert
            await serviceBusClient.DidNotReceiveWithAnyArgs().SendMessageAsync(default);
        }

        [Test]
        public async Task SendNotificationsAsync_Should_SendMultipleMessagesToBus_When_MultipleNotificationsProvided()
        {
            // Arrange
            IEnumerable<SendPushNotification> notifications = Enumerable.Repeat(new SendPushNotification(), N);

            // Act
            await service.SendNotificationsAsync(notifications);

            // Assert
            await serviceBusClient.ReceivedWithAnyArgs(N).SendMessageAsync(default);
        }
        
        #endregion
    }
}