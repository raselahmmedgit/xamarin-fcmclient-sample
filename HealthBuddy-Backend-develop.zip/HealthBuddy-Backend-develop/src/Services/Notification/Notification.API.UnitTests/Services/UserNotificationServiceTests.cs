﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.API.Services;
using Epam.CovidResistance.Services.Notification.Application.Common.Constants;
using Epam.CovidResistance.Services.Notification.Application.Common.Enums;
using Epam.CovidResistance.Services.Notification.Application.Common.Models;
using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using FluentAssertions;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.Notification.API.UnitTests.Services
{
    public class UserNotificationServiceTests
    {
        #region Test_Setup
        
        private const string UserId = "userId";
        private const string Token = "token";
        private const string TokenWithWhitespace = "  to k en  ";
        private const string TargetPlatform = "platform";
        private const string EnglishMessageText = "text";

        private UserNotificationService service;
        private IUserRepository userRepository;

        [SetUp]
        public void Setup()
        {
            userRepository = Substitute.For<IUserRepository>();
            service = new UserNotificationService(userRepository);
        }
        
        #endregion
        
        #region SetupNotificationAsync

        [Test]
        public async Task SetupNotificationAsync_Should_SetNotificationForUser()
        {
            // Arrange
            var setupPushNotification = new SetupPushNotification
            {
                Token = TokenWithWhitespace,
                TargetPlatform = TargetPlatform
            };

            UserPushNotification argUsed = null;
            await userRepository.SetPushNotificationAsync(Arg.Do<UserPushNotification>(x => argUsed = x));

            // Act
            await service.SetupNotificationAsync(UserId, setupPushNotification);

            // Assert
            await userRepository.ReceivedWithAnyArgs().SetPushNotificationAsync(default);
            argUsed?.NotificationToken.Should().Be(Token);
        }
        
        [TestCase(null)]
        [TestCase("")]    
        public async Task SetupNotificationAsync_Should_ThrowArgumentException_When_UserIdIsNullOrEmpty(string userId)
        {
            // Arrange
            var setupPushNotification = new SetupPushNotification
            {
                Token = TokenWithWhitespace,
                TargetPlatform = TargetPlatform
            };
            
            // Act
            Func<Task> act = () => service.SetupNotificationAsync(userId, setupPushNotification);

            // Assert
            await act.Should().ThrowAsync<ArgumentException>();
            await userRepository.DidNotReceiveWithAnyArgs().SetPushNotificationAsync(default);
        }
        

        [Test]
        public async Task SetupNotificationAsync_Should_ThrowArgumentNullException_When_SetupPushNotificationIsNull()
        {
            // Act
            Func<Task> act = () => service.SetupNotificationAsync(UserId, null);

            // Assert
            await act.Should().ThrowAsync<ArgumentNullException>();
            await userRepository.DidNotReceiveWithAnyArgs().SetPushNotificationAsync(default);
        }
        
        #endregion
        
        #region GetAllPushNotificationsAsync

        [Test]
        public async Task GetAllPushNotificationsAsync_Should_GetNotifications()
        {
            // Arrange
            userRepository
                .ListPushNotificationsAsync()
                .Returns(new[]
                {
                    new UserPushNotification
                    {
                        UserId = UserId,
                        NotificationTarget = TargetPlatform,
                        NotificationToken = Token
                    }
                });

            var request = new NotificationRequest
            {
                Text = new Dictionary<string, string>
                {
                    { LanguageCodes.English, EnglishMessageText }
                }
            };

            var expectedResult = new object[]
            {
                new SendPushNotification
                {
                    Message = EnglishMessageText,
                    Token = Token,
                    TargetPlatform = TargetPlatform
                }
            };

            // Act
            IEnumerable<SendPushNotification> result = await service.GetAllPushNotificationsAsync(request);

            // Assert
            await userRepository.Received().ListPushNotificationsAsync();
            result.Should().BeEquivalentTo(expectedResult);
        }
        
        [Test]
        public async Task GetAllPushNotificationsAsync_Should_GetNotificationsInEnglish_When_LocalizedVersionForUserLanguageIsNotProvided()
        {
            // Arrange
            userRepository
                .ListPushNotificationsAsync()
                .Returns(new[]
                {
                    new UserPushNotification
                    {
                        UserId = UserId,
                        NotificationTarget = TargetPlatform,
                        NotificationToken = Token,
                        NotificationLanguage = "ru"
                    }
                });

            var request = new NotificationRequest
            {
                Text = new Dictionary<string, string>
                {
                    { LanguageCodes.English, EnglishMessageText }
                }
            };

            var expectedResult = new object[]
            {
                new SendPushNotification
                {
                    Message = EnglishMessageText,
                    Token = Token,
                    TargetPlatform = TargetPlatform
                }
            };

            // Act
            IEnumerable<SendPushNotification> result = await service.GetAllPushNotificationsAsync(request);

            // Assert
            await userRepository.Received().ListPushNotificationsAsync();
            result.Should().BeEquivalentTo(expectedResult);
        }
        
        [TestCase(null)]
        [TestCase("")]
        [TestCase(" ")]
        [TestCase("\n")]
        public async Task GetAllPushNotificationsAsync_Should_GetNotificationsInEnglish_When_LocalizedVersionForUserLanguageIsNullOrWhiteSpace(
            string localizedText)
        {
            // Arrange
            userRepository
                .ListPushNotificationsAsync()
                .Returns(new[]
                {
                    new UserPushNotification
                    {
                        UserId = UserId,
                        NotificationTarget = TargetPlatform,
                        NotificationToken = Token,
                        NotificationLanguage = "ru"
                    }
                });

            var request = new NotificationRequest
            {
                Text = new Dictionary<string, string>
                {
                    { LanguageCodes.English, EnglishMessageText },
                    { "ru", localizedText }
                }
            };

            var expectedResult = new object[]
            {
                new SendPushNotification
                {
                    Message = EnglishMessageText,
                    Token = Token,
                    TargetPlatform = TargetPlatform
                }
            };

            // Act
            IEnumerable<SendPushNotification> result = await service.GetAllPushNotificationsAsync(request);

            // Assert
            await userRepository.Received().ListPushNotificationsAsync();
            result.Should().BeEquivalentTo(expectedResult);
        }
        
        [Test]
        public async Task GetAllPushNotificationsAsync_Should_GetNotificationsInUserLanguage_When_LocalizedVersionForUserLanguageIsProvided()
        {
            // Arrange
            const string localizedText = "Localized Text";
            
            userRepository
                .ListPushNotificationsAsync()
                .Returns(new[]
                {
                    new UserPushNotification
                    {
                        UserId = UserId,
                        NotificationTarget = TargetPlatform,
                        NotificationToken = Token,
                        NotificationLanguage = "ru"
                    }
                });

            var request = new NotificationRequest
            {
                Text = new Dictionary<string, string>
                {
                    { LanguageCodes.English, EnglishMessageText },
                    { "ru", localizedText }
                }
            };

            var expectedResult = new object[]
            {
                new SendPushNotification
                {
                    Message = localizedText,
                    Token = Token,
                    TargetPlatform = TargetPlatform
                }
            };

            // Act
            IEnumerable<SendPushNotification> result = await service.GetAllPushNotificationsAsync(request);

            // Assert
            await userRepository.Received().ListPushNotificationsAsync();
            result.Should().BeEquivalentTo(expectedResult);
        }

        [Test]
        public async Task GetAllPushNotificationsAsync_Should_ThrowArgumentException_When_NotificationTextInEnglishIsNotProvided()
        {
            // Arrange
            var notificationRequest = new NotificationRequest
            {
                Text = new Dictionary<string, string>
                {
                    { "de", "Deutsch" }
                },
                Purpose = NotificationPurpose.Poll
            };
                
            userRepository
                .ListPushNotificationsAsync()
                .Returns(new[]
                {
                    new UserPushNotification
                    {
                        UserId = UserId,
                        NotificationTarget = TargetPlatform,
                        NotificationToken = Token
                    }
                });

            // Act
            Func<Task> act = async () => await service.GetAllPushNotificationsAsync(notificationRequest);

            // Assert
            await act.Should().ThrowAsync<ArgumentException>();
            await userRepository.DidNotReceive().ListPushNotificationsAsync();
        }
        
        [TestCase(null)]
        [TestCase("")]
        [TestCase(" ")]
        [TestCase("\n")]
        public async Task GetAllPushNotificationsAsync_Should_ThrowArgumentException_When_NotificationTextInEnglishIsNullOrWhiteSpace(string englishText)
        {
            // Arrange
            var notificationRequest = new NotificationRequest
            {
                Text = new Dictionary<string, string>
                {
                    { "de", "Deutsch" },
                    { "en", englishText }
                },
                Purpose = NotificationPurpose.Poll
            };
                
            userRepository
                .ListPushNotificationsAsync()
                .Returns(new[]
                {
                    new UserPushNotification
                    {
                        UserId = UserId,
                        NotificationTarget = TargetPlatform,
                        NotificationToken = Token
                    }
                });

            // Act
            Func<Task> act = async () => await service.GetAllPushNotificationsAsync(notificationRequest);

            // Assert
            await act.Should().ThrowAsync<ArgumentException>();
            await userRepository.DidNotReceive().ListPushNotificationsAsync();
        }
        
        [Test]
        public async Task GetAllPushNotificationsAsync_Should_ThrowArgumentNullException_When_NullNotificationRequestProvided()
        {
            // Arrange
            userRepository
                .ListPushNotificationsAsync()
                .Returns(new[]
                {
                    new UserPushNotification
                    {
                        UserId = UserId,
                        NotificationTarget = TargetPlatform,
                        NotificationToken = Token
                    }
                });

            // Act
            Func<Task> act = async () => await service.GetAllPushNotificationsAsync(null);

            // Assert
            await act.Should().ThrowAsync<ArgumentNullException>();
            await userRepository.DidNotReceive().ListPushNotificationsAsync();
        }
        
        #endregion

        #region ClearNotificationTokenAsync
        
        [Test]
        public async Task ClearNotificationTokenAsync_Should_RemoveUserNotificationToken()
        {
            // Arrange
            string argUsed = null;
            await userRepository.ClearNotificationTokenAsync(Arg.Do<string>(x => argUsed = x));

            const string expectedUserId = UserId;
            
            // Act
            await service.ClearNotificationTokenAsync(UserId);

            // Assert
            await userRepository.ReceivedWithAnyArgs().ClearNotificationTokenAsync(default);
            argUsed.Should().BeEquivalentTo(expectedUserId);
        }

        [TestCase(null)]
        [TestCase("")]
        [TestCase(" ")]
        public async Task ClearNotificationTokenAsync_Should_ThrowArgumentException_When_UserIdIsNullOrWhitespace(string userId)
        {
            // Act
            Func<Task> act = async () => await service.ClearNotificationTokenAsync(userId);

            // Assert
            await act.Should().ThrowAsync<ArgumentException>();
            await userRepository.DidNotReceiveWithAnyArgs().ClearNotificationTokenAsync(default);
        }

        #endregion
    }
}