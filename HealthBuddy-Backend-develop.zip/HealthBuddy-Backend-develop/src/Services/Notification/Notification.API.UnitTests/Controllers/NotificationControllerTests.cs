// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.API.Controllers;
using Epam.CovidResistance.Services.Notification.API.Interfaces;
using Epam.CovidResistance.Services.Notification.Application.Common.Constants;
using Epam.CovidResistance.Services.Notification.Application.Common.Models;
using Epam.CovidResistance.Shared.Domain.Model.Errors;
using Epam.CovidResistance.Shared.Test.Common.Builders;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.Notification.API.UnitTests.Controllers
{
    public class NotificationControllerTests
    {
        #region Test_Setup
        
        private const string UserId = "userId";
        
        private readonly NotificationRequest invalidSendRequestModel = new NotificationRequest
        {
            Text = null
        };

        private readonly NotificationRequest validSendRequestModel = new NotificationRequest
        {
            Text = new Dictionary<string, string> { { LanguageCodes.English, "Text" } }
        };

        private NotificationController controller;
        private IServiceBusNotificationService serviceBusNotificationService;
        private IUserNotificationService userNotificationService;
        private ILogger<NotificationController> logger;

        [SetUp]
        public void Setup()
        {
            serviceBusNotificationService = Substitute.For<IServiceBusNotificationService>();
            userNotificationService = Substitute.For<IUserNotificationService>();
            logger = Substitute.For<ILogger<NotificationController>>();
            controller = new NotificationController(logger, userNotificationService, serviceBusNotificationService)
            {
                ControllerContext = new ControllerContextBuilder().WithUser(UserId).Build()
            };
        }

        #endregion

        #region Send

        [Test]
        public async Task Send_Should_ReturnOkResult_When_RequestIsValid()
        {
            // Act
            IActionResult result = await controller.Send(validSendRequestModel);

            // Assert
            result.Should().BeOfType<OkResult>();
            await userNotificationService.Received().GetAllPushNotificationsAsync(validSendRequestModel);
            await serviceBusNotificationService.ReceivedWithAnyArgs().SendNotificationsAsync(default);
        }

        [Test]
        public async Task Send_Should_ReturnBadRequestObjectResult_When_RequestIsInvalid()
        {
            // Arrange
            controller.ModelState.AddModelError("TestError", "TestError");

            // Act
            IActionResult result = await controller.Send(invalidSendRequestModel);
            object resultValue = (result as BadRequestObjectResult)?.Value;

            // Assert
            using (new AssertionScope())
            {
                result.Should().BeOfType<BadRequestObjectResult>();
                resultValue.Should().BeOfType<Error>();
            }
        }

        [Test]
        public async Task Send_Should_ReturnObjectResult_When_ExceptionOccursWhileGettingNotifications()
        {
            // Arrange
            userNotificationService
                .GetAllPushNotificationsAsync(Arg.Any<NotificationRequest>())
                .ReturnsForAnyArgs(Task.FromException<IList<SendPushNotification>>(new Exception()));

            // Act
            IActionResult result = await controller.Send(validSendRequestModel);
            object resultValue = (result as ObjectResult)?.Value;
            int? resultStatusCode = (result as ObjectResult)?.StatusCode;

            // Assert
            using (new AssertionScope())
            {
                result.Should().BeOfType<ObjectResult>();
                resultStatusCode.Should().Be(StatusCodes.Status500InternalServerError);
                resultValue.Should().BeOfType<Error>();
            }
        }

        [Test]
        public async Task Send_Should_ReturnObjectResult_When_ExceptionOccursWhileSendingNotifications()
        {
            // Arrange
            serviceBusNotificationService
                .SendNotificationsAsync(default)
                .ReturnsForAnyArgs(Task.FromException(new Exception()));

            // Act
            IActionResult result = await controller.Send(validSendRequestModel);
            object resultValue = (result as ObjectResult)?.Value;
            int? resultStatusCode = (result as ObjectResult)?.StatusCode;

            // Assert
            using (new AssertionScope())
            {
                result.Should().BeOfType<ObjectResult>();
                resultStatusCode.Should().Be(StatusCodes.Status500InternalServerError);
                resultValue.Should().BeOfType<Error>();
            }
        }
        
        #endregion
    }
}