// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.API.Controllers;
using Epam.CovidResistance.Services.Notification.API.Interfaces;
using Epam.CovidResistance.Services.Notification.Application.Common.Models;
using Epam.CovidResistance.Shared.Domain.Model.Errors;
using Epam.CovidResistance.Shared.Test.Common.Builders;
using FluentAssertions;
using FluentAssertions.Execution;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.Notification.API.UnitTests.Controllers
{
    public class NotificationTokenControllerTests
    {
        #region Test_Setup
        
        private const string UserId = "userId";

        private readonly SetupPushNotification validSetupRequestModel = new SetupPushNotification
        {
            TargetPlatform = "test_platform",
            Token = "test_token"
        };

        private readonly SetupPushNotification invalidSetupRequestModel = new SetupPushNotification
        {
            TargetPlatform = null,
            Token = null
        };
        
        private NotificationTokenController controller;
        private IUserNotificationService userNotificationService;
        private ILogger<NotificationTokenController> logger;

        [SetUp]
        public void Setup()
        {
            userNotificationService = Substitute.For<IUserNotificationService>();
            logger = Substitute.For<ILogger<NotificationTokenController>>();
            controller = new NotificationTokenController(logger, userNotificationService)
            {
                ControllerContext = new ControllerContextBuilder().WithUser(UserId).Build()
            };
        }

        #endregion
        
        #region Setup
        
        [Test]
        public async Task Setup_Should_ReturnOkResult_When_RequestIsValid()
        {
            // Act
            IActionResult result = await controller.Setup(validSetupRequestModel);

            // Assert
            result.Should().BeOfType<OkResult>();
            await userNotificationService.Received().SetupNotificationAsync(UserId, validSetupRequestModel);
        }

        [Test]
        public async Task Setup_Should_ReturnBadRequestObjectResult_When_RequestIsInvalid()
        {
            // Arrange
            controller.ModelState.AddModelError("TestError", "TestError");

            // Act
            IActionResult result = await controller.Setup(invalidSetupRequestModel);
            object resultValue = (result as BadRequestObjectResult)?.Value;

            // Assert
            using (new AssertionScope())
            {
                result.Should().BeOfType<BadRequestObjectResult>();
                resultValue.Should().BeOfType<Error>();
            }
        }

        [Test]
        public async Task Setup_Should_ReturnObjectResult_When_ExceptionOccurs()
        {
            // Arrange
            userNotificationService
                .When(s => s.SetupNotificationAsync(UserId, validSetupRequestModel))
                .Do(call => throw new Exception());

            // Act
            IActionResult result = await controller.Setup(validSetupRequestModel);
            object resultValue = (result as ObjectResult)?.Value;
            int? resultStatusCode = (result as ObjectResult)?.StatusCode;

            // Assert
            using (new AssertionScope())
            {
                result.Should().BeOfType<ObjectResult>();
                resultStatusCode.Should().Be(StatusCodes.Status500InternalServerError);
                resultValue.Should().BeOfType<Error>();
            }
        }
        
        #endregion
        
        #region ClearNotificationToken
        
        [Test]
        public async Task ClearNotificationToken_Should_ReturnOkResult_When_RequestIsValid()
        {
            // Act
            IActionResult result = await controller.ClearNotificationToken();

            // Assert
            result.Should().BeOfType<OkResult>();
            await userNotificationService.Received().ClearNotificationTokenAsync(UserId);
        }

        [Test]
        public async Task ClearNotificationToken_Should_ReturnObjectResult_When_ExceptionOccurs()
        {
            // Arrange
            userNotificationService
                .When(s => s.ClearNotificationTokenAsync(UserId))
                .Do(call => throw new Exception());

            // Act
            IActionResult result = await controller.ClearNotificationToken();
            object resultValue = (result as ObjectResult)?.Value;
            int? resultStatusCode = (result as ObjectResult)?.StatusCode;

            // Assert
            using (new AssertionScope())
            {
                result.Should().BeOfType<ObjectResult>();
                resultStatusCode.Should().Be(StatusCodes.Status500InternalServerError);
                resultValue.Should().BeOfType<Error>();
            }
        }
        
        #endregion
    }
}