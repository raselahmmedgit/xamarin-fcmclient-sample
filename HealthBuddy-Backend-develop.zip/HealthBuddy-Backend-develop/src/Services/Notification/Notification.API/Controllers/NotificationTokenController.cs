﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.API.Extensions;
using Epam.CovidResistance.Services.Notification.API.Interfaces;
using Epam.CovidResistance.Services.Notification.Application.Common.Models;
using Epam.CovidResistance.Shared.API.Common.Controllers;
using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Configuration.AspNetCore.Extensions;
using IdentityServer4.AccessTokenValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.Notification.API.Controllers
{
    /// <summary>
    /// Represents the controller for notification token endpoints.
    /// </summary>
    [Authorize(AuthenticationSchemes = IdentityServerAuthenticationDefaults.AuthenticationScheme, Roles = "User"),
     Route("api/v1/notification"), ApiController]
    public class NotificationTokenController : BaseApiController
    {
        private readonly IUserNotificationService userNotificationService;
        private readonly ILogger<NotificationTokenController> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationTokenController"></see> class.
        /// </summary>
        public NotificationTokenController(
            ILogger<NotificationTokenController> logger,
            IUserNotificationService userNotificationService)
        {
            this.logger = logger;
            this.userNotificationService = userNotificationService;
        }

        /// <summary>
        /// Sets push notification information.
        /// </summary>
        /// <param name="request">Push notification parameters.</param>
        [HttpPost("setup")]
        public async Task<IActionResult> Setup([FromBody] SetupPushNotification request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(Result.Failure(ModelState.ToInnerErrors()));
            }

            var userId = User.GetUserId();

            logger.LogInformation($"Start to set up notifications for user {userId}.");

            Result setupResult = await GetExecutionResultAsync(
                () => userNotificationService.SetupNotificationAsync(userId, request));

            if (!setupResult.Succeeded)
            {
                logger.LogError("Failed to set up notifications for user {userId}. Errors: {@message}", userId, setupResult.Errors);
                
                return InternalServerError(setupResult);
            }

            logger.LogInformation("Successfully set up notifications for user {user}.", userId);

            return Ok();
        }

        /// <summary>
        /// Removes user's notification token, preventing them from receiving notifications.
        /// </summary>
        [HttpDelete("token")]
        public async Task<IActionResult> ClearNotificationToken()
        {
            logger.LogInformation("Start to clear token for user {user}.", User.GetUserId());

            Result result = await GetExecutionResultAsync(async () =>
                await userNotificationService.ClearNotificationTokenAsync(User.GetUserId()));

            if (!result.Succeeded)
            {
                logger.LogError("Failed to clear token for user {user}. Errors: {@message}", User.GetUserId(), result.Errors);
                return InternalServerError(result);
            }

            logger.LogInformation("Successfully cleared token for user {user}.", User.GetUserId());
            
            return Ok();
        }
    }
}