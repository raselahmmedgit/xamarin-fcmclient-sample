﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.API.Interfaces;
using Epam.CovidResistance.Services.Notification.Application.Common.Models;
using Epam.CovidResistance.Shared.API.Common.Controllers;
using Epam.CovidResistance.Shared.Application.Core.Models;
using Epam.CovidResistance.Shared.Configuration.AspNetCore.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.Notification.API.Controllers
{
    /// <summary>
    /// Represents the controller for notification endpoints.
    /// </summary>
    [Route("api/v1/[controller]"), ApiController]
    public class NotificationController : BaseApiController
    {
        private readonly IServiceBusNotificationService serviceBusNotificationService;
        private readonly IUserNotificationService userNotificationService;
        private readonly ILogger<NotificationController> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationController"></see> class.
        /// </summary>
        public NotificationController(
            ILogger<NotificationController> logger,
            IUserNotificationService userNotificationService,
            IServiceBusNotificationService serviceBusNotificationService)
        {
            this.logger = logger;
            this.userNotificationService = userNotificationService;
            this.serviceBusNotificationService = serviceBusNotificationService;
        }
        
        /// <summary>Sends push notification.</summary>
        /// <param name="request">The push notification parameters.</param>
        [HttpPost("send")]
        public async Task<IActionResult> Send([FromBody] NotificationRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(Result.Failure(ModelState.ToInnerErrors()));
            }
            
            logger.LogInformation("Start to get notifications with {parameter}: {parameterValue}.", nameof(request.Purpose), request.Purpose);

            (Result getResult, IList<SendPushNotification> notifications) = await GetExecutionResultAsync(
                async () => await userNotificationService.GetAllPushNotificationsAsync(request));

            if (!getResult.Succeeded)
            {
                logger.LogError("Failed to get notifications. Errors: {@message}", getResult.Errors);
                return InternalServerError(getResult);
            }
            
            logger.LogInformation("Start to send {n} notifications to Service Bus.", notifications.Count);

            Result sendResult = await GetExecutionResultAsync(
                async () => await serviceBusNotificationService.SendNotificationsAsync(notifications));

            if (!sendResult.Succeeded)
            {
                logger.LogError("Failed to send notifications to Service Bus. Errors: {@message}", getResult.Errors);
                return InternalServerError(sendResult);
            }

            logger.LogInformation("Successfully sent {n} notifications to Service Bus.", notifications.Count);
            return Ok();
        }
    }
}