﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.API.Interfaces;
using Epam.CovidResistance.Services.Notification.Application.Common.Interfaces;
using Epam.CovidResistance.Services.Notification.Application.Common.Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.Notification.API.Services
{
    /// <summary>Represents a service that sends notifications.</summary>
    public class ServiceBusNotificationService : IServiceBusNotificationService
    {
        private readonly IServiceBusClient serviceBusClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceBusNotificationService"></see> class.
        /// </summary>
        public ServiceBusNotificationService(IServiceBusClient serviceBusClient)
        {
            this.serviceBusClient = serviceBusClient;
        }

        /// <summary>Asynchronously sends notifications.</summary>
        /// <param name="notifications">The push notifications.</param>
        public async Task SendNotificationsAsync(IEnumerable<SendPushNotification> notifications)
        {
            if (notifications is null)
            {
                return;
            }

            foreach (SendPushNotification notification in notifications)
            {
                var payload = JsonConvert.SerializeObject(notification);

                await serviceBusClient.SendMessageAsync(payload);
            }
        }
    }
}