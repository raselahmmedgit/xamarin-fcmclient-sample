﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.API.Interfaces;
using Epam.CovidResistance.Services.Notification.Application.Common.Constants;
using Epam.CovidResistance.Services.Notification.Application.Common.Enums;
using Epam.CovidResistance.Services.Notification.Application.Common.Models;
using Epam.CovidResistance.Shared.Application.Core.Entities;
using Epam.CovidResistance.Shared.Application.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.Notification.API.Services
{
    /// <summary>Represents a service that gets notifications from the user repository.</summary>
    public class UserNotificationService : IUserNotificationService
    {
        private readonly IUserRepository userRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserNotificationService"></see> class.
        /// </summary>
        public UserNotificationService(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        /// <summary>Gets all push notifications.</summary>
        /// <param name="notificationRequest">The notification request.</param>
        public async Task<IList<SendPushNotification>> GetAllPushNotificationsAsync(NotificationRequest notificationRequest)
        {
            if (notificationRequest is null)
            {
                throw new ArgumentNullException(nameof(notificationRequest));
            }

            if (!notificationRequest.Text.TryGetValue(LanguageCodes.English, out var englishMessageText) || string.IsNullOrWhiteSpace(englishMessageText))
            {
                throw new ArgumentException($"{nameof(notificationRequest)} doesn't contain text in English or the English text is empty." +
                    $"Expected language code: {LanguageCodes.English}");
            }

            IEnumerable<UserPushNotification> notifications = await userRepository.ListPushNotificationsAsync();

            return notifications.Select(notification => new SendPushNotification
            {
                TargetPlatform = notification.NotificationTarget,
                Token = notification.NotificationToken,
                Purpose = notificationRequest.Purpose ?? NotificationPurpose.Unknown,
                Message = notification.NotificationLanguage is null 
                    || !notificationRequest.Text.TryGetValue(notification.NotificationLanguage, out var localizedMessage)
                    || string.IsNullOrWhiteSpace(localizedMessage)
                        ? englishMessageText
                        : localizedMessage
            }).ToList();
        }

        /// <summary>
        /// Sets push notification information for the specified user token.
        /// </summary>
        /// <param name="userId">The user token.</param>
        /// <param name="sendPushNotification">Push notification parameters.</param>
        public Task SetupNotificationAsync(string userId, SetupPushNotification sendPushNotification)
        {
            if (string.IsNullOrEmpty(userId))
            {
                throw new ArgumentException(nameof(userId));
            }

            if (sendPushNotification is null)
            {
                throw new ArgumentNullException(nameof(sendPushNotification));
            }

            var userPushNotification = new UserPushNotification
            {
                UserId = userId,
                NotificationToken = sendPushNotification.Token.Replace(" ", string.Empty).Trim(),
                NotificationTarget = sendPushNotification.TargetPlatform,
                NotificationLanguage = sendPushNotification.Language
            };

            return userRepository.SetPushNotificationAsync(userPushNotification);
        }

        public Task ClearNotificationTokenAsync(string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
            {
                throw new ArgumentException(nameof(userId));
            }

            return userRepository.ClearNotificationTokenAsync(userId);
        }
    }
}