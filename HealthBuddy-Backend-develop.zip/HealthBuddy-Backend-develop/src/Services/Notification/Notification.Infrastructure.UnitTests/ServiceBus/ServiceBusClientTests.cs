﻿// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.Infrastructure.ServiceBus;
using FluentAssertions;
using Microsoft.Azure.ServiceBus;
using NSubstitute;
using NUnit.Framework;
using System.Threading.Tasks;

namespace Notification.Infrastructure.UnitTests.ServiceBus
{
    public class ServiceBusClientTests
    {
        #region Test_Setup

        private ITopicClient topicClient;
        private ServiceBusClient serviceBusClient;

        [SetUp]
        public void Setup()
        {
            topicClient = Substitute.For<ITopicClient>();
            serviceBusClient = new ServiceBusClient(topicClient);
        }
        
        #endregion
        
        #region SendMessageAsync
        
        [Test]
        public async Task SendMessageAsync_Should_SendTopicMessage()
        {
            // Arrange
            const string message = "123";
            var expectedMessageBytes = new byte[] { 0x31, 0x32, 0x33 };

            Message actualMessage = null;
            await topicClient.SendAsync(Arg.Do<Message>(x => actualMessage = x));

            // Act
            await serviceBusClient.SendMessageAsync(message);

            // Assert
            await topicClient.SendAsync(Arg.Any<Message>());
            actualMessage?.Body.Should().BeEquivalentTo(expectedMessageBytes);
        }
        
        #endregion
    }
}