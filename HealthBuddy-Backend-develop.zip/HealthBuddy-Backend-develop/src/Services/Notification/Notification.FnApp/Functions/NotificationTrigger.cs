// =========================================================================
// Copyright 2020 EPAM Systems, Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =========================================================================

using Epam.CovidResistance.Services.Notification.Application.Common.Models;
using Epam.CovidResistance.Services.Notification.FnApp.Exceptions;
using Epam.CovidResistance.Services.Notification.FnApp.Helpers;
using Epam.CovidResistance.Services.Notification.FnApp.Interfaces;
using Epam.CovidResistance.Services.Notification.FnApp.Options;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Threading.Tasks;

namespace Epam.CovidResistance.Services.Notification.FnApp.Functions
{
    /// <summary>
    /// The service bus trigger to new message from Notification topic.
    /// </summary>
    public class NotificationTrigger
    {
        private readonly ILogger<NotificationTrigger> logger;
        private readonly INotificationsService notificationsService;
        private readonly IRetryHandler retryHandler;
        private readonly RetryPolicyOptions policyOptions;

        /// <summary>
        /// Currently used <see cref="IMessageReceiver"/>.
        /// This property is a workaround for mocking receiver in unit tests.
        /// </summary>
        public IMessageReceiver ActiveMessageReceiver { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationTrigger"/> class.
        /// </summary>
        /// <param name="policyOptions">
        /// The policy options.
        /// </param>
        /// <param name="notificationsService">
        /// The notifications service.
        /// </param>
        /// <param name="retryHandler">
        /// The retry handler.
        /// </param>
        /// <param name="logger">
        /// The logger.
        /// </param>
        public NotificationTrigger(
            IOptions<RetryPolicyOptions> policyOptions,
            INotificationsService notificationsService,
            IRetryHandler retryHandler,
            ILogger<NotificationTrigger> logger)
        {
            this.policyOptions = policyOptions.Value;
            this.notificationsService = notificationsService;
            this.retryHandler = retryHandler;
            this.logger = logger;
        }

        /// <summary>Runs the specified service bus message trigger.</summary>
        /// <param name="message">The message.</param>
        /// <param name="messageReceiver">The message receiver. Should be used through <see cref="ActiveMessageReceiver"/> property, not directly. </param>
        /// <exception cref="Epam.CovidResistance.Services.Notification.FnApp.Exceptions.BadMessageException">Invalid message received.</exception>
        [FunctionName(nameof(NotificationTrigger))]
        public async Task Run(
            [ServiceBusTrigger("%NotificationsTopicName%",
                "%StatusNotificationSubscription%",
                Connection = "NotificationsTopicListenConnection")]
            Message message,
            MessageReceiver messageReceiver)
        {
            if (messageReceiver != null)
            {
                ActiveMessageReceiver = messageReceiver;
            }
            logger.LogInformation($"C# ServiceBus topic trigger function processed message: {message}");

            try
            {
                message.UserProperties.TryGetValue(MessageHeaders.UserId, out object userIdHeader);
                var contactUserId = userIdHeader?.ToString();

                var pushNotification = MessageHelper.GetMessageBody<SendPushNotification>(message);

                if (pushNotification == null || !pushNotification.IsValid())
                {
                    throw new BadMessageException("Invalid message received.");
                }

                logger.LogInformation("ContactUserId: {contactUserId}. Sending notification...", contactUserId);
                await notificationsService.PushMessageAsync(pushNotification);

                await ActiveMessageReceiver.CompleteAsync(message.SystemProperties.LockToken);
            }
            catch (Exception ex)
            {
                // Manage retries using our message retry handler
                if (!await retryHandler.RetryMessageAsync(
                         message,
                         ex,
                         ActiveMessageReceiver,
                         policyOptions,
                         logger))
                {
                    logger.LogError(ex, $"Unhandled exception: {ex.Message}");

                    throw;
                }
            }
        }
    }
}